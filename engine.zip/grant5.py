"""Grant 5: learn vs frozen complete Grant 4 bots, with decision diagnostics."""
from grant4 import *
OUT5=ROOT/'experiments/grant5'
class View4(View3):
    @property
    def enable4(self):return True
    @property
    def leader_left(self):return bool((self.g.window_leaders-{self.p}) & self.g.left_this_window)
    def memory_reason(self,p):return self.g.memory_reason(self.ids[p])
    def preference_multiplier(self):return Grant4Game.preference_multiplier(self)
    def risk_harbor(self,boost=1.):return RuleGame.risk_harbor(self,boost*self.preference_multiplier())
    def should_harbor(self,p=0):return Grant4Game.should_harbor(self,0)

class Grant5Game(Grant4Game):
    def __init__(self,*a,**kw):
        super().__init__(*a,**kw);self.views=[View4(self,p) for p in range(len(self.ships))]
        self.left_this_window=set();self.window_leaders=set();self.other_maroon=False
        self.tracked_plan=[];self.prophecy_stats=collections.Counter();self.behavior=collections.Counter()
    def setup_round(self):
        super().setup_round();self.other_maroon=False;self.tracked_plan=[];self.left_this_window=set();self.window_leaders=set()
    def projected_lead(self):return self.gold[0]+self.harbor_value(0)>=max(self.gold[1:])
    def refuse_exit(self,p):
        return self.chest==0 or (p==0 and self.round==15 and not self.projected_lead())
    def preference_multiplier(self):
        m=Grant4Game.preference_multiplier(self)
        if 'escape' in self.held[0]:m*=1.8
        n=sum(self.status[p]=='active' and 'escape' in self.held[p] for p in range(1,len(self.ships)))
        m*=.8**n
        if self.other_maroon:m*=.85
        return m
    def should_harbor(self,p):
        if p:return self.views[p].should_harbor()
        if self.status[0]!='active' or self.safe() or self.block:return False
        if self.chest==0:return self.record_decision(False,'zero_gold_never_harbor')
        if self.round==15 and not self.projected_lead():return self.record_decision(False,'round15_not_leading_continue')
        reason=self.memory_reason(0)
        if reason:return self.record_decision(True,reason)
        if self.ships[0]==1 and self.round<15:return self.record_decision(True,'strict_one_life_harbor')
        _,_,s,w=self.odds();escape='escape' in self.held[0]
        if self.last_surge is not None:
            if self.last_surge==self.draws:
                self.surge_followup_pending=True
                return self.record_decision(False,'surge_one_more_card')
            if escape or (s>0 and s>=w):
                # Avoid the old unconditional post-followup exit; use the risk test.
                result=self.risk_harbor(1.5 if escape else 1.2)
                return self.record_decision(result,'surge_exception_harbor' if result else 'surge_exception_continue')
            return self.record_decision(self.risk_harbor(.55) or self.rng.random()<.85,'surge_followup_strong_exit_preference')
        return Grant4Game.should_harbor(self,0)
    def windows(self,current):
        self.window_id+=1;self.leader_left=False;self.left_this_window=set()
        self.window_leaders={p for p in range(len(self.ships)) if self.gold[p]==max(self.gold)}
        Game.windows(self,current)
        for p in range(len(self.ships)):
            reason=self.memory_reason(p)
            if reason and not self.safe() and not self.block and not self.refuse_exit(p):
                if p==0:self.record_decision(True,reason)
                self.harbor(p)
    def harbor(self,p,forced=False):
        if self.status[p]=='active':
            if not forced:
                assert not self.refuse_exit(p)
                self.left_this_window.add(p)
            if self.collector:self.collector.departure(self,p,forced)
        super().harbor(p,forced)
    def prophecy(self,p):
        if self.tracked_plan:self.prophecy_stats['cards_invalidated_by_prophecy']+=len(self.tracked_plan)
        self.tracked_plan=[]
        super().prophecy(p)
        if p==0:
            self.tracked_plan=list(self.known[0]);self.prophecy_stats['uses']+=1
            self.prophecy_stats['alone_uses' if self.status.count('active')==1 else 'with_others_uses']+=1
    def draw(self,p):
        safe=self.safe();c=self.deck[-1] if self.deck else None;effect=self.previous if c=='echo' else c
        pending=list(self.pending)
        for j in range(len(self.ships)):
            if self.memory_reason(j) and not safe and not self.block:
                assert self.refuse_exit(j)
                self.behavior['known_danger_continued_due_to_'+('zero_gold' if self.chest==0 else 'round15')]+=1
        if self.tracked_plan:
            planned=self.tracked_plan.pop(0);assert planned==c
            self.prophecy_stats[planned+('_drawn_by_self' if p==0 else '_drawn_by_opponent')]+=1
        if safe:self.calm_cards[c]+=1
        ExperimentGame.draw(self,p)
        if not safe and effect=='marooned' and p!=0:self.other_maroon=True
        for j in range(1,len(self.ships)):
            if not safe and effect=='surge':self.followup_exits[j]=False
            if pending[j]:self.followup_exits[j]=not(c=='echo' and not safe and effect=='surge');self.pending[j]=False
        if not safe and effect=='wave':
            self.wants=[False]*len(self.ships);self.prophecy_stats['cards_invalidated_by_wave']+=len(self.tracked_plan);self.tracked_plan=[]

class Collector5(RuleCollector):
    def __init__(self,path):
        super().__init__(path)
        self.context_writer=self.writer('decision_context.csv.gz',['game','round','draws','chest','ships','harbor','reason','own_escape','other_escapes','other_maroon','calm_whirlpool','calm_marooned','calm_surge','since_surge','p_surge','p_whirlpool','projected_lead'])
        self.departure_writer=self.writer('all_departures.csv.gz',['game','round','bot','forced','draws','chest','payout','ships','reason','projected_lead'])
        self.extra=collections.Counter();self.prophecy_stats=collections.Counter()
    def writer(self,name,header):return super().writer(name.replace('grant2','grant5'),[s.replace('grant2','grant5') for s in header])
    def decision(self,g,o,result,reason):
        super().decision(g,o,result,reason)
        self.context_writer.writerow([g.game_id,g.round,g.draws,g.chest,g.ships[0],result,reason,'escape' in g.held[0],sum(g.status[p]=='active' and 'escape' in g.held[p] for p in range(1,4)),g.other_maroon,g.calm_cards['whirlpool'],g.calm_cards['marooned'],g.calm_cards['surge'],g.draws-g.last_surge if g.last_surge is not None else -1,o[2],o[3],g.projected_lead()])
    def departure(self,g,p,forced):
        self.departure_writer.writerow([g.game_id,g.round,p,forced,g.draws,g.chest,g.harbor_value(p),g.ships[p],g.reason if p==0 else g.actor_reasons[p],g.projected_lead() if p==0 else ''])
    def finish_game(self,g,reward):
        super().finish_game(g,reward);self.extra.update(g.behavior);self.prophecy_stats.update(g.prophecy_stats)

def run(n=10000):
    OUT5.mkdir(parents=True,exist_ok=True);source=OUT4/'grant4_policy.json';original=source.read_bytes()
    bot=Adaptive.load(source);bot.training=True;bot.n={k:0 for k in bot.q};bot.rng=random.Random(50917)
    fixed=FixedGrant2(source);before=dict(fixed.q);frozen=FrozenGrant();c=Collector5(OUT5)
    bot.save(OUT5/'policy_before.json');blocks=[];credits=[0.]*4;start=time.time()
    for i in range(n):
        bot.epsilon=[.5,.35,.2,.08,.02][min(4,i*5//n)]
        g=Grant5Game(100_000_000+i,frozen,bot,fixed2=fixed,changes=RULES,collector=c,game_id=i+1)
        reward=g.play();bot.finish(reward[0])
        for p in range(4):credits[p]+=reward[p]
        if (i+1)%2000==0:
            x={'games':i+1,'win_shares':[v/2000 for v in credits],'seconds':round(time.time()-start,1)};blocks.append(x);credits=[0.]*4;print(json.dumps(x),flush=True)
    c.close();assert fixed.q==before and original==source.read_bytes()
    bot.save(OUT5/'grant5_policy.json');policy=json.loads((OUT5/'grant5_policy.json').read_text());policy.update({'epsilon_schedule':[.5,.35,.2,.08,.02],'configuration':'Grant5Game with life, prophecy, cannon'});(OUT5/'grant5_policy.json').write_text(json.dumps(policy,indent=2))
    r=c.summary();r['names']=['Grant 5.0','Grant 4.0 A','Grant 4.0 B','Grant 4.0 C'];r['blocks']=blocks;r['learning_updates']=sum(bot.n.values());r['extra']=dict(c.extra);r['prophecy_usage']=dict(c.prophecy_stats);r['opponent_sha256']=hashlib.sha256(original).hexdigest()
    r['seat_counts']={r['names'][i]:r['seat_counts'][name] for i,name in enumerate(['Grant 2.0','Grant A','Grant B','Grant C'])}
    (OUT5/'results.json').write_text(json.dumps(r,indent=2));print('DONE',flush=True)
if __name__=='__main__':run()

"""Grant 4 training against complete frozen Grant 3 policies."""
import collections,json,random,time,hashlib
from pathlib import Path
from grant3 import *
from grant2 import Adaptive,Collector
OUT4=ROOT/'experiments/grant4'
RULES={'life','prophecy','cannon'}
class View3(ActorView,RuleGame):
    def risk_harbor(self,boost=1.):return RuleGame.risk_harbor(self,boost)
    def record_decision(self,result,reason):self.reason=reason;return result
    def should_harbor(self,p=0):
        reason=self.g.memory_reason(self.p)
        if reason and not self.safe() and not self.block:return self.record_decision(True,reason)
        return RuleGame.should_harbor(self,0)

class Grant4Game(Grant3Game):
    def __init__(self,*a,enable4=True,**kw):
        super().__init__(*a,**kw);self.enable4=enable4
        self.views=[View3(self,p) for p in range(len(self.ships))]
        self.wants=[False]*len(self.ships);self.calm_cards=collections.Counter();self.leader_left=False
        self.preferences=collections.Counter();self.window_id=0;self.departures=[]
    def setup_round(self):
        super().setup_round();self.wants=[False]*len(self.ships);self.calm_cards.clear()
        # Apply Grant 3's final-round neutral-life context to every fixed opponent.
        if self.round==15:
            for p in range(1,len(self.ships)):
                if self.status[p]!='active':continue
                v=NeutralLifeView(self.views[p]);name=self.fixed2.choose('round',v,[s[0] for s in STRATEGIES])
                self.actor_strategies[p]=next(s for s in STRATEGIES if s[0]==name)
                self.appetite[p]=self.frozen.appetite(v,0)*self.actor_strategies[p][1]
    def memory_reason(self,p):
        if self.status[p]!='active':return None
        if self.wants[p]:return 'prophecy_two_bad_cards_leave'
        if self.known[p]:
            c=self.known[p][0]
            if c=='whirlpool':return 'known_whirlpool_harbor'
            if c in ('marooned','rudder') and self.next_drawer()==p:return 'remembered_'+c+'_now_for_self'
    def preference_multiplier(self):
        m=1.4 if self.round in (5,10) else .65 if self.round in (6,11) else 1.
        m*=1.4**(self.calm_cards['whirlpool']+self.calm_cards['marooned'])
        m*=.4**self.calm_cards['surge']
        if self.leader_left:m*=1.4
        return m
    def risk_harbor(self,boost=1.):
        return RuleGame.risk_harbor(self,boost*(self.preference_multiplier() if self.enable4 else 1))
    def should_harbor(self,p):
        if p:return self.views[p].should_harbor()
        if self.status[0]!='active' or self.safe() or self.block:return False
        if self.enable4 and self.chest==0:return self.record_decision(False,'zero_gold_never_harbor')
        reason=self.memory_reason(0)
        if reason:return self.record_decision(True,reason)
        if self.enable4 and 10<=self.chest<=50 and not(self.ships[0]==1 and self.round<15):
            # One coin flip per decision window; preferences temper the base 80%.
            chance=max(.35,min(.95,.8/self.preference_multiplier()))
            if self.rng.random()<chance:return self.record_decision(True,'small_chest_preference')
        if self.enable4 and self.calm_cards['surge'] and not(self.ships[0]==1 and self.round<15):
            if self.risk_harbor():return self.record_decision(True,'calm_surge_caution')
        return RuleGame.should_harbor(self,0)
    def windows(self,current):
        self.window_id+=1;self.leader_left=False
        self.window_leaders={p for p in range(1,len(self.ships)) if self.gold[p]==max(self.gold)}
        Game.windows(self,current)
        for p in range(len(self.ships)):
            reason=self.memory_reason(p)
            if reason and not self.safe() and not self.block:
                if p==0 and self.enable4 and self.chest==0:continue
                if p==0:self.record_decision(True,reason)
                self.harbor(p)
    def harbor(self,p,forced=False):
        if self.status[p]=='active':
            if p==0 and self.enable4 and not forced:assert self.chest!=0
            self.departures.append((self.round,p,self.draws,forced,self.chest,self.ships[p]))
            if not forced and p in getattr(self,'window_leaders',set()):self.leader_left=True
        super().harbor(p,forced)
    def cannon(self,p):
        # All four use Grant 3's mandatory eligible score-leader target.
        if p==0:return RuleGame.cannon(self,p)
        eligible=[j for j in self.seating if j!=p and self.status[j]=='active']
        if eligible:self.harbor(max(eligible,key=lambda j:self.gold[j]),True)
    def prophecy(self,p):
        self.plans=[];self.wants=[False]*len(self.ships)
        k=min(2,len(self.deck));cards=list(reversed(self.deck[-k:])) if k else []
        if not cards:return
        order,bottom,leave=revised_plan(cards,self.status.count('active'),self.block>0)
        del self.deck[-k:]
        if bottom:self.deck.insert(0,bottom)
        self.deck.extend(reversed(order));self.known=[[] for _ in range(len(self.ships))];self.known[p]=order.copy();self.wants[p]=leave
        if p==0 and self.collector:self.collector.prophecy_record(self,cards,order,bottom,self.status.count('active'))
    def draw(self,p):
        safe=self.safe();c=self.deck[-1] if self.deck else None;effect=self.previous if c=='echo' else c
        pending=list(self.pending)
        for j in range(len(self.ships)):
            reason=self.memory_reason(j)
            if reason and not safe and not self.block:
                assert j==0 and self.enable4 and self.chest==0,(j,reason)
        if safe:self.calm_cards[c]+=1
        ExperimentGame.draw(self,p)
        for j in range(1,len(self.ships)):
            if not safe and effect=='surge':self.followup_exits[j]=False
            if pending[j]:self.followup_exits[j]=not(c=='echo' and not safe and effect=='surge');self.pending[j]=False
        if not safe and effect=='wave':self.wants=[False]*len(self.ships)

class Collector4(RuleCollector):
    def writer(self,name,header):return super().writer(name.replace('grant2','grant4'),[s.replace('grant2','grant4') for s in header])

def run(n=10000):
    OUT4.mkdir(exist_ok=True,parents=True)
    source=OUT/'grant3_policy.json';original=source.read_bytes()
    bot=Adaptive.load(source);bot.training=True;bot.n={k:0 for k in bot.q};bot.rng=random.Random(40917)
    fixed=FixedGrant2(source);frozen=FrozenGrant();before=dict(fixed.q)
    c=Collector4(OUT4);blocks=[];counts=[0.]*4;departures=[];start=time.time()
    bot.save(OUT4/'policy_before.json')
    for i in range(n):
        bot.epsilon=[.5,.35,.2,.08,.02][min(4,i*5//n)]
        g=Grant4Game(80_000_000+i,frozen,bot,fixed2=fixed,changes=RULES,collector=c,game_id=i+1)
        reward=g.play();bot.finish(reward[0]);departures.extend(g.departures)
        for p in range(4):counts[p]+=reward[p]
        if (i+1)%2000==0:
            row={'games':i+1,'block_win_shares':[v/2000 for v in counts],'elapsed':round(time.time()-start,1)}
            blocks.append(row);print(json.dumps(row),flush=True);counts=[0.]*4
    c.close();assert fixed.q==before and source.read_bytes()==original
    bot.save(OUT4/'grant4_policy.json')
    data=json.loads((OUT4/'grant4_policy.json').read_text());data['epsilon_schedule']=[.5,.35,.2,.08,.02];data['configuration']='Grant4Game; life, prophecy, cannon; enable4=True';(OUT4/'grant4_policy.json').write_text(json.dumps(data,indent=2))
    r=c.summary();r['names']=['Grant 4.0','Grant 3.0 A','Grant 3.0 B','Grant 3.0 C'];r['blocks']=blocks;r['opponent_sha256']=hashlib.sha256(original).hexdigest();r['learning_updates']=sum(bot.n.values())
    r['departure_summary']={}
    for p in range(4):
        a=[x for x in departures if x[1]==p and not x[3]]
        r['departure_summary'][str(p)]={'voluntary':len(a),'zero_chest':sum(x[4]==0 for x in a),'small_chest':sum(10<=x[4]<=50 for x in a),'after_calm':sum(x[2]==3 for x in a)}
    (OUT4/'results.json').write_text(json.dumps(r,indent=2));print('DONE',flush=True)
if __name__=='__main__':run()

from tournament import *
DEST=ROOT/'experiments/grant5_adaptation'
def save_result(c,path,versions,seed,learning=False):
 r=c.summary();r['versions']=versions;r['seed_start']=seed;r['learning']=learning;seen=collections.Counter();names=[]
 for v in versions:
  names.append(f'Grant {v}.0'+(' '+chr(65+seen[v]) if versions.count(v)>1 else ''));seen[v]+=1
 r['names']=names;r['seat_counts']={names[p]:r['seat_counts'][name] for p,name in enumerate(['Grant 2.0','Grant A','Grant B','Grant C'])}
 (path/'results.json').write_text(json.dumps(r,indent=2));return r

def run():
 ps={v:FixedGrant2(p) for v,p in PATHS.items()};snap={v:dict(p.q) for v,p in ps.items()};f=FrozenGrant()
 for i,v in enumerate([4,3,2]):
  name=f'two5_two{v}';path=DEST/name;path.mkdir(parents=True,exist_ok=True);c=EvalCollector(path);start=time.time();vs=[5,5,v,v];seed=140_000_000+i*1_000_000
  for j in range(5000):
   TournamentGame(seed+j,vs,[ps[x] for x in vs],f,c,j+1).play()
   if (j+1)%2500==0:print(json.dumps({'case':name,'games':j+1,'win_shares':[x/c.n for x in c.credit],'seconds':round(time.time()-start,1)}),flush=True)
  c.close();save_result(c,path,vs,seed)
  assert snap=={v:dict(p.q) for v,p in ps.items()}
 print('DONE',flush=True)
if __name__=='__main__':run()

"""Frozen cross-generation evaluation; every identity uses the same actor adapter."""
from grant5 import *
from grant2 import Collector
EVAL=ROOT/'experiments/frozen_tournament'
PATHS={2:ROOT/'experiments/grant2/grant2_policy.json',3:OUT/'grant3_policy.json',4:OUT4/'grant4_policy.json',5:OUT5/'grant5_policy.json'}
class Actor( View4):
    @property
    def adaptive(self):return self.g.policies[self.p]
    @property
    def other_maroon(self):return bool(self.g.marooned_players-{self.p})
    def projected_lead(self):return self.gold[0]+self.harbor_value(0)>=max(self.gold[1:])
    def preference_multiplier(self):
        if self.g.versions[self.p]==5:return Grant5Game.preference_multiplier(self)
        return Grant4Game.preference_multiplier(self)
    def risk_harbor(self,boost=1.):
        v=self.g.versions[self.p]
        return RuleGame.risk_harbor(self,boost*(self.preference_multiplier() if v>=4 else 1))
    def record_decision(self,result,reason):self.reason=reason;return result
    def should_harbor(self,p=0):
        version=self.g.versions[self.p]
        if version==2:return ExperimentGame.should_harbor(self,0)
        if version==3:return View3.should_harbor(self,0)
        if version==4:return Grant4Game.should_harbor(self,0)
        return Grant5Game.should_harbor(self,0)

class TournamentGame(Grant5Game):
    def __init__(self,seed,versions,policies,frozen,collector=None,game_id=0):
        self.versions=versions;self.policies=policies
        super().__init__(seed,frozen,policies[0],fixed2=policies[1],changes=RULES,collector=collector,game_id=game_id,player_count=len(versions))
        self.views=[Actor(self,p) for p in range(len(self.ships))];self.marooned_players=set()
    def setup_round(self):
        Game.setup_round(self);self.physical_held=[];self.seating=list(range(len(self.ships)));self.seat_rng.shuffle(self.seating)
        self.own_draws=[0]*len(self.ships);self.harbor_gold=[0.]*len(self.ships);self.round_bonus=[0.]*len(self.ships)
        self.round_begin=list(self.gold);self.round_ships=list(self.ships);self.pending=[False]*len(self.ships);self.followup_exits=[False]*len(self.ships)
        self.last_surge=None;self.reason='';self.resolving=None;self.plans=[];self.wants=[False]*len(self.ships);self.want_leave_two_bad=False
        self.calm_cards.clear();self.marooned_players=set();self.left_this_window=set();self.window_leaders=set();self.tracked_plan=[]
        self.appetite=[1.]*len(self.ships)
        for p in range(len(self.ships)):
            v=self.views[p];context=NeutralLifeView(v) if self.round==15 and self.versions[p]>=3 else v
            name=self.policies[p].choose('round',context,[s[0] for s in STRATEGIES]) if self.status[p]=='active' else 'grant'
            self.actor_strategies[p]=next(s for s in STRATEGIES if s[0]==name)
            self.appetite[p]=self.frozen.appetite(context,0)*self.actor_strategies[p][1]
        self.strategy=self.actor_strategies[0]
    def memory_reason(self,p):
        if self.versions[p]==2:return None
        return Grant4Game.memory_reason(self,p)
    def refuse_exit(self,p):
        return (self.versions[p]>=4 and self.chest==0) or (self.versions[p]>=5 and self.round==15 and not self.views[p].projected_lead())
    def should_harbor(self,p):return self.views[p].should_harbor()
    def harbor(self,p,forced=False):
        if self.status[p]=='active':
            if not forced:assert not self.refuse_exit(p);self.left_this_window.add(p)
            self.departures.append((self.round,p,self.draws,forced,self.chest,self.ships[p]))
        # Preserve scoring, bypass generation-specific player-zero restrictions.
        ExperimentGame.harbor(self,p,forced)
    def prophecy(self,p):
        self.wants=[False]*len(self.ships)
        if self.versions[p]==2:return ExperimentGame.prophecy(self.views[p],0)
        return Grant4Game.prophecy(self,p)
    def cannon(self,p):
        if self.versions[p]==2:return ExperimentGame.cannon(self.views[p],0)
        eligible=[j for j in self.seating if j!=p and self.status[j]=='active']
        if eligible:self.harbor(max(eligible,key=lambda j:self.gold[j]),True)
    def draw(self,p):
        safe=self.safe();c=self.deck[-1] if self.deck else None;effect=self.previous if c=='echo' else c;pending=list(self.pending)
        for j in range(len(self.ships)):
            if self.memory_reason(j) and not safe and not self.block:assert self.refuse_exit(j)
        if safe:self.calm_cards[c]+=1
        ExperimentGame.draw(self,p)
        if not safe and effect=='marooned':self.marooned_players.add(p)
        for j in range(1,len(self.ships)):
            if not safe and effect=='surge':self.followup_exits[j]=False
            if pending[j]:self.followup_exits[j]=not(c=='echo' and not safe and effect=='surge');self.pending[j]=False
        if not safe and effect=='wave':self.wants=[False]*len(self.ships)

class EvalCollector(Collector):
    def __init__(self,path):
        super().__init__(path,detail_start=10**9)
        self.departure_writer=self.writer('all_departures.csv.gz',['game','round','bot','draws','forced','chest','ships'])
    def prophecy_record(self,*args):pass
    def finish_game(self,g,reward):
        super().finish_game(g,reward)
        for rd,p,d,f,c,s in g.departures:self.departure_writer.writerow([g.game_id,rd,p,d,f,c,s])
        for p in range(4):assert abs(sum(x['round_gold'] for x in g.round_data if x['bot']==p)+g.game_bonus[p]+g.sell_gold[p]-g.gold[p])<1e-7

def run():
    policies={v:FixedGrant2(p) for v,p in PATHS.items()};original={v:dict(p.q) for v,p in policies.items()};hashes={v:hashlib.sha256(p.read_bytes()).hexdigest() for v,p in PATHS.items()};frozen=FrozenGrant()
    cases=[('four_grant5',[5,5,5,5],5000),('grant5_vs_grant4',[5,4,4,4],5000),('mixed_generations',[2,3,4,5],10000)]
    for index,(name,versions,n) in enumerate(cases):
        path=EVAL/name;path.mkdir(parents=True,exist_ok=True);c=EvalCollector(path);start=time.time()
        for i in range(n):
            g=TournamentGame(120_000_000+index*1_000_000+i,versions,[policies[v] for v in versions],frozen,c,i+1);g.play()
            if (i+1)%2500==0:print(json.dumps({'case':name,'games':i+1,'win_shares':[x/c.n for x in c.credit],'seconds':round(time.time()-start,1)}),flush=True)
        c.close();r=c.summary();r['versions']=versions;r['seed_start']=120_000_000+index*1_000_000;r['learning']=False;r['policy_sha256']=hashes
        r['names']=[f'Grant {v}.0'+(f' {chr(65+p)}' if versions.count(v)>1 else '') for p,v in enumerate(versions)]
        r['seat_counts']={r['names'][p]:r['seat_counts'][name] for p,name in enumerate(['Grant 2.0','Grant A','Grant B','Grant C'])}
        (path/'results.json').write_text(json.dumps(r,indent=2))
        for v,p in policies.items():assert p.q==original[v] and hashlib.sha256(PATHS[v].read_bytes()).hexdigest()==hashes[v]
    print('DONE',flush=True)
if __name__=='__main__':run()

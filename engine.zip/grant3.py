"""Train Grant 3.0 through six batches against three frozen Grant 2.0 bots."""
import argparse,collections,hashlib,json,random,time
from pathlib import Path
from simulator import Game,TREASURE
from grant2 import Adaptive,ExperimentGame,FrozenGrant,STRATEGIES
from grant_rule_tests import RuleGame,RuleCollector,NeutralLifeView,prophecy_plan,PERSONAL,MAGIC

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'experiments/grant3'
NAMES=['Grant 3.0','Grant 2.0 A','Grant 2.0 B','Grant 2.0 C']
CASES={
 '1_last_life':{'life'},'2_prophecy':{'prophecy'},'3_cannon':{'cannon'},
 '4_escape_risk':{'escape_risk'},'5_combined':{'life','prophecy','cannon','escape_risk'},
 '6_combined_without_escape_risk':{'life','prophecy','cannon'},
}
EPS=[.60,.45,.30,.20,.08,.02]
BAD={'marooned','rudder','whirlpool'}

class FixedGrant2:
    """Exact greedy Adaptive policy lookup, with immutable weights and no updates."""
    def __init__(self,path=OUT/'starting_grant2_policy.json'):
        raw=Path(path).read_bytes();self.sha256=hashlib.sha256(raw).hexdigest()
        self.q={tuple(r['key']):r['q'] for r in json.loads(raw)['values']}
    def choose(self,kind,g,labels):
        state=(kind,)+Adaptive.context(self,g)
        if kind!='round':state+=(sum(g.chest>x for x in (100,300)),)
        return max(labels,key=lambda x:(self.q.get(state+(x,),.25),x==labels[0]))

class LearningGrant3(Adaptive):
    def save(self,path):
        super().save(path)
        data=json.loads(Path(path).read_text())
        data['epsilon_schedule']=EPS
        data['experiment']='Grant 3.0, six sequential learning phases against frozen Grant 2.0'
        data['initialization']='Grant 2.0 values transferred; visits restarted with 30-observation prior'
        Path(path).write_text(json.dumps(data,indent=2))

class MappedList:
    def __init__(self,original,ids):self.original=original;self.ids=ids
    def __len__(self):return len(self.ids)
    def __iter__(self):return (self.original[i] for i in self.ids)
    def __getitem__(self,i):
        if isinstance(i,slice):return [self.original[j] for j in self.ids[i]]
        return self.original[self.ids[i]]
    def __setitem__(self,i,value):self.original[self.ids[i]]=value
    def count(self,x):return list(self).count(x)
    def copy(self):return list(self)

class ActorView(ExperimentGame):
    """Run the original Grant 2.0 methods with a different player mapped to index 0.

    This avoids approximating opponents with their ancestor Grant 1.0. Mutable
    card-knowledge rows map back to the real player; no hidden information is added.
    """
    def __init__(self,g,p):
        self.g=g;self.p=p;self.ids=[p]+[j for j in range(len(g.ships)) if j!=p]
        self.inverse={j:i for i,j in enumerate(self.ids)}
    def __getattr__(self,name):return getattr(self.g,name)
    @property
    def gold(self):return MappedList(self.g.gold,self.ids)
    @property
    def ships(self):return MappedList(self.g.ships,self.ids)
    @property
    def status(self):return MappedList(self.g.status,self.ids)
    @property
    def held(self):return MappedList(self.g.held,self.ids)
    @property
    def appetite(self):return MappedList(self.g.appetite,self.ids)
    @property
    def known(self):return MappedList(self.g.known,self.ids)
    @known.setter
    def known(self,value):
        for i,j in enumerate(self.ids):self.g.known[j]=value[i]
    @property
    def seating(self):return [self.inverse[p] for p in self.g.seating]
    @property
    def strategy(self):return self.g.actor_strategies[self.p]
    @property
    def adaptive(self):return self.g.fixed2
    @property
    def collector(self):return None
    @property
    def choice_stats(self):return self.g.opponent_choices[self.p]
    @property
    def reason(self):return self.g.actor_reasons[self.p]
    @reason.setter
    def reason(self,value):self.g.actor_reasons[self.p]=value
    @property
    def surge_followup_pending(self):return self.g.pending[self.p]
    @surge_followup_pending.setter
    def surge_followup_pending(self,value):self.g.pending[self.p]=value
    @property
    def followup_exit(self):return self.g.followup_exits[self.p]
    @followup_exit.setter
    def followup_exit(self,value):self.g.followup_exits[self.p]=value
    def harbor(self,p,forced=False):return self.g.harbor(self.ids[p],forced)


def revised_plan(cards,active,blocked):
    """Return order, bottom, and a request to exit (still subject to harbor blocks)."""
    dangerous=[c for c in cards if c in BAD]
    if len(cards)<2:return cards.copy(),None,bool(dangerous and active==1)
    if active==1 and dangerous:
        # Always remove a bad card, even when its partner is a curse.
        priority={'whirlpool':3,'marooned':2,'rudder':1}
        bottom=max(dangerous,key=lambda c:priority[c]);order=cards.copy();order.remove(bottom)
        return order,bottom,len(dangerous)==2
    if 'whirlpool' in cards:
        # Prefer removing Whirlpool even if an unreachable personal card remains.
        order=cards.copy();order.remove('whirlpool')
        return order,'whirlpool',order[0]=='whirlpool'
    offensive=[c for c in cards if c in ('marooned','rudder')]
    if active>1 and offensive:
        top=offensive[0]
        other=cards[1] if cards[0]==top else cards[0]
        prior_order,bottom=prophecy_plan(cards,active,blocked)
        if bottom==other:return [top],bottom,False
        return [top,other],None,False
    order,bottom=prophecy_plan(cards,active,blocked)
    return order,bottom,False

class Grant3Game(RuleGame):
    def __init__(self,*args,fixed2=None,**kwargs):
        super().__init__(*args,**kwargs)
        self.fixed2=fixed2 or FixedGrant2()
        self.pending=[False]*len(self.ships);self.followup_exits=[False]*len(self.ships)
        self.actor_strategies=[STRATEGIES[0]]*len(self.ships);self.actor_reasons=['']*len(self.ships)
        self.opponent_choices=[collections.Counter() for _ in range(len(self.ships))]
        self.views=[ActorView(self,p) for p in range(len(self.ships))]
        self.want_leave_two_bad=False
    @property
    def surge_followup_pending(self):return self.pending[0]
    @surge_followup_pending.setter
    def surge_followup_pending(self,value):self.pending[0]=value
    @property
    def followup_exit(self):return self.followup_exits[0]
    @followup_exit.setter
    def followup_exit(self,value):self.followup_exits[0]=value
    def setup_round(self):
        # One real policy choice per active player; no phantom round-15 choice.
        Game.setup_round(self);self.physical_held=[]
        self.seating=list(range(len(self.ships)));self.seat_rng.shuffle(self.seating)
        self.own_draws=[0]*len(self.ships);self.harbor_gold=[0.]*len(self.ships);self.round_bonus=[0.]*len(self.ships)
        self.round_begin=list(self.gold);self.round_ships=list(self.ships)
        self.pending=[False]*len(self.ships);self.followup_exits=[False]*len(self.ships)
        self.last_surge=None;self.reason='';self.resolving=None;self.plans=[];self.want_leave_two_bad=False
        self.appetite=[self.frozen.appetite(self,p) for p in range(len(self.ships))]
        if self.ships[0]==1:self.last_life_games=True
        for p in range(len(self.ships)):
            name='grant'
            if self.status[p]=='active':
                if p==0:
                    view=NeutralLifeView(self) if 'life' in self.changes and self.round==15 else self
                    name=self.adaptive.choose('round',view,[s[0] for s in STRATEGIES])
                    self.appetite[p]=self.frozen.appetite(view,0)
                    self.choice_stats['round_policy:'+name]+=1
                else:name=self.fixed2.choose('round',self.views[p],[s[0] for s in STRATEGIES])
            self.actor_strategies[p]=next(s for s in STRATEGIES if s[0]==name)
            self.appetite[p]*=self.actor_strategies[p][1]
        self.strategy=self.actor_strategies[0]
    def next_drawer(self):
        i=self.seating.index(self.current)
        for offset in range(len(self.ships)):
            p=self.seating[(i+offset)%len(self.ships)]
            if self.status[p]=='active':return p
        return None
    def memory_exit_reason(self):
        if 'prophecy' not in self.changes or self.status[0]!='active':return None
        if self.want_leave_two_bad:return 'prophecy_two_bad_cards_leave'
        if self.known[0]:
            c=self.known[0][0]
            if c=='whirlpool':return 'known_whirlpool_harbor'
            if c in ('marooned','rudder') and self.next_drawer()==0:return 'remembered_'+c+'_now_for_self'
        return None
    def should_harbor(self,p):
        if p!=0:return ExperimentGame.should_harbor(self.views[p],0)
        reason=self.memory_exit_reason()
        if reason and not self.safe() and not self.block:return self.record_decision(True,reason)
        return super().should_harbor(p)
    def windows(self,current):
        super().windows(current)
        # A later declaration can change who draws the known card. React before
        # the actual draw, still using only legitimate remembered information.
        reason=self.memory_exit_reason()
        if reason and not self.safe() and not self.block:
            self.record_decision(True,reason);self.harbor(0)
    def cannon(self,p):
        if p==0:return super().cannon(p)
        eligible=[j for j in self.seating if j!=p and self.status[j]=='active']
        self.cannon_drawer=p;self.cannon_target=None
        ExperimentGame.cannon(self.views[p],0)
        assert not eligible or self.cannon_target in eligible
        self.cannon_drawer=None;self.cannon_target=None
    def prophecy(self,p):
        if self.plans:self.metrics['planned_cards_invalidated_by_prophecy']+=len(self.plans)
        self.plans=[];self.want_leave_two_bad=False
        if p!=0:return ExperimentGame.prophecy(self.views[p],0)
        if 'prophecy' not in self.changes:return ExperimentGame.prophecy(self,0)
        k=min(2,len(self.deck));cards=list(reversed(self.deck[-k:])) if k else []
        if not cards:return
        active=self.status.count('active');order,bottom,leave=revised_plan(cards,active,self.block>0)
        assert bottom not in TREASURE
        del self.deck[-k:]
        if bottom:self.deck.insert(0,bottom)
        self.deck.extend(reversed(order));self.known=[[] for _ in range(len(self.ships))];self.known[0]=order.copy()
        self.want_leave_two_bad=leave
        self.metrics['prophecy_activations']+=1;self.metrics['prophecy_active_players_'+str(active)]+=1
        self.metrics['prophecy_top_'+order[0]]+=1
        if len(order)>1:self.metrics['prophecy_second_'+order[1]]+=1
        if bottom:self.metrics['prophecy_bottom_'+bottom]+=1
        if active==1 and any(c in BAD for c in cards):
            self.metrics['prophecy_alone_bad_card_seen']+=1
            assert bottom in BAD or len(cards)<2
        if active==1 and sum(c in BAD for c in cards)==2:self.metrics['prophecy_alone_two_bad_cards']+=1
        if leave and self.block:self.metrics['prophecy_exit_request_blocked']+=1
        if order[0]=='whirlpool':
            self.metrics['prophecy_whirlpool_left_top']+=1
            if self.block:self.metrics['prophecy_unavoidable_whirlpool_while_blocked']+=1
        if self.block and 'whirlpool' in cards and order[0]!='whirlpool':self.metrics['prophecy_whirlpool_moved_off_top_while_blocked']+=1
        for i,c in enumerate(order):
            if c in PERSONAL or c in MAGIC:intent='self' if active==1 or (active==2 and i==1) else 'opponent'
            elif c in ('marooned','rudder'):intent='opponent' if active>1 else 'self'
            else:intent='unspecified'
            self.plans.append((c,intent))
        if self.collector:self.collector.prophecy_record(self,cards,order,bottom,active)
    def draw(self,p):
        pending=list(self.pending);safe=self.safe()
        c=self.deck[-1] if self.deck else None;effect=self.previous if c=='echo' else c
        if p==0 and 'prophecy' in self.changes and self.known[0] and self.known[0][0] in ('marooned','rudder') and not safe:
            if self.block:self.metrics['remembered_bad_self_draw_blocked']+=1
            else:raise AssertionError('Drew remembered harmful own card despite being able to harbor')
        super().draw(p)
        for j in range(1,len(self.ships)):
            if not safe and effect=='surge':self.followup_exits[j]=False
            if pending[j]:
                self.followup_exits[j]=not(c=='echo' and not safe and effect=='surge')
                self.pending[j]=False
        if not safe and effect=='wave':self.want_leave_two_bad=False

class Grant3Collector(RuleCollector):
    def writer(self,name,header):
        return super().writer(name.replace('grant2','grant3'),[s.replace('grant2','grant3') for s in header])
    def summary(self):
        s=super().summary();s['names']=NAMES
        old=['Grant 2.0','Grant A','Grant B','Grant C']
        s['seat_counts']={NAMES[i]:s['seat_counts'][name] for i,name in enumerate(old)}
        return s


def run(args):
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    frozen=FrozenGrant();fixed2=FixedGrant2()
    learner=LearningGrant3.load(OUT/'starting_grant2_policy.json');learner.training=True
    # Transfer the learned values, but restart visit counts for a new opponent
    # population. The inherited values act as a 30-observation prior.
    learner.n={k:0 for k in learner.q};learner.rng=random.Random(30817)
    fixed_before=dict(fixed2.q);summary=[]
    for phase,(case,changes) in enumerate(CASES.items()):
        path=out/case;path.mkdir(parents=True,exist_ok=True)
        c=Grant3Collector(path);learner.epsilon=EPS[phase];started=time.time()
        before_visits=sum(learner.n.values());learner.save(path/'policy_before.json')
        for i in range(args.games):
            seed=50_000_000+phase*args.games+i
            g=Grant3Game(seed,frozen,learner,fixed2=fixed2,changes=changes,collector=c,game_id=i+1)
            reward=g.play();learner.finish(reward[0])
            if (i+1)%2000==0:print(json.dumps({'case':case,'games':i+1,'win_rate':c.credit[0]/c.n,'elapsed_seconds':round(time.time()-started,1)}),flush=True)
        c.close();learner.save(path/'policy_after.json')
        r=c.summary();r.update({'case':case,'changes':sorted(changes),'learning_enabled':True,
            'exploration':learner.epsilon,'seed_start':50_000_000+phase*args.games,
            'phase_learning_updates':sum(learner.n.values())-before_visits,'frozen_grant2_sha256':fixed2.sha256,
            'elapsed_seconds':round(time.time()-started,1)})
        (path/'results.json').write_text(json.dumps(r,indent=2));summary.append(r)
        assert fixed2.q==fixed_before and fixed2.sha256==hashlib.sha256((OUT/'starting_grant2_policy.json').read_bytes()).hexdigest()
        print('COMPLETE '+json.dumps({'case':case,'win_rates':r['win_rates'],'games_zero_ships':r['games_zero_ships'],'updates':r['phase_learning_updates']}),flush=True)
    learner.save(out/'grant3_policy.json')
    (out/'batch_summary.json').write_text(json.dumps([{k:r[k] for k in ('case','games','win_rates','mean_scores','games_zero_ships','exploration','phase_learning_updates')} for r in summary],indent=2))
    print('DONE',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--games',type=int,default=10000);p.add_argument('--output',default=str(OUT));run(p.parse_args())

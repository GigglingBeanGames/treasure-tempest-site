"""Broader win-reward adaptation of Grant 5 against fixed mixed generations."""
from run_pairings import *
TUNING={
 'own_escape':{'mild':1.15,'original':1.8,'strong':3.},
 'other_escape':{'mild':.95,'original':.8,'strong':.55},
 'maroon':{'mild':.97,'original':.85,'strong':.6},
 'pre_red':{'mild':1.1,'original':1.4,'strong':2.},
 'red':{'mild':.9,'original':.65,'strong':.4},
 'calm_hazard':{'mild':1.1,'original':1.4,'strong':2.},
 'calm_surge':{'mild':.7,'original':.4,'strong':.2},
 'leader_departure':{'mild':1.1,'original':1.4,'strong':2.},
 'small_chest':{'mild':.65,'original':.8,'strong':.95},
 'surge_exit':{'mild':.65,'original':.85,'strong':.98},
 'surge_odds':{'loose':.75,'original':1.,'strict':1.5},
 'risk_scale':{'cautious':.65,'original':1.,'bold':1.6,'very_bold':2.5},
}
class BroadLearner(Adaptive):
 def choose(self,kind,g,labels):
  return super().choose(kind,g,labels)
 def save(self,path):
  super().save(path);d=json.loads(Path(path).read_text());d['experiment']='Grant 5 adapting to fixed Grant 2/3/4';d['tuning_options']=TUNING;d['epsilon_schedule']=[.6,.45,.3,.18,.08,.02];d['configuration']='AdaptGame; versions [2,3,4,5]; learner identity 3';Path(path).write_text(json.dumps(d,indent=2))
class AdaptActor(Actor):
 @property
 def settings(self):return self.g.settings
 def preference_multiplier(self):
  t=self.settings
  m=t['pre_red'] if self.round in (5,10) else t['red'] if self.round in (6,11) else 1.
  m*=t['calm_hazard']**(self.calm_cards['whirlpool']+self.calm_cards['marooned'])
  m*=t['calm_surge']**self.calm_cards['surge']
  if self.leader_left:m*=t['leader_departure']
  if 'escape' in self.held[0]:m*=t['own_escape']
  m*=t['other_escape']**sum(self.status[p]=='active' and 'escape' in self.held[p] for p in range(1,len(self.ships)))
  if self.other_maroon:m*=t['maroon']
  return m*t['risk_scale']
 def should_harbor(self,p=0):
  if self.status[0]!='active' or self.safe() or self.block:return False
  if self.chest==0:return self.record_decision(False,'zero_gold_never_harbor')
  if self.round==15 and not self.projected_lead():return self.record_decision(False,'round15_not_leading_continue')
  reason=self.memory_reason(0)
  if reason:return self.record_decision(True,reason)
  if self.ships[0]==1 and self.round<15:return self.record_decision(True,'strict_one_life_harbor')
  _,_,s,w=self.odds();escape='escape' in self.held[0]
  if self.last_surge is not None:
   if self.last_surge==self.draws:
    self.surge_followup_pending=True;return self.record_decision(False,'surge_one_more_card')
   if escape or (s>0 and s>=self.settings['surge_odds']*w):
    return self.record_decision(self.risk_harbor(1.5 if escape else 1.2),'surge_exception_risk_test')
   return self.record_decision(self.risk_harbor(.55) or self.rng.random()<self.settings['surge_exit'],'surge_followup_exit_preference')
  if 10<=self.chest<=50:
   probability=max(.35,min(.95,self.settings['small_chest']/self.preference_multiplier()))
   if self.rng.random()<probability:return self.record_decision(True,'small_chest_preference')
  if self.calm_cards['surge'] and self.risk_harbor():return self.record_decision(True,'calm_surge_caution')
  # Learn how strongly to follow the inherited risk/odds strategy vs direct risk tests.
  context=NeutralLifeView(self) if self.round==15 else self
  style=self.adaptive.choose('decision_style',context,['inherited','direct','patient','cautious'])
  if style=='inherited':return RuleGame.should_harbor(self,0)
  boost={'direct':1.,'patient':1.8,'cautious':.55}[style]
  return self.record_decision(self.risk_harbor(boost),'learned_'+style)
 def record_decision(self,result,reason):
  self.reason=reason
  if self.g.collector:self.g.collector.adaptation_decision(self,result,reason)
  return result
class AdaptGame(TournamentGame):
 def __init__(self,*args,**kw):
  super().__init__(*args,**kw);self.views[3]=AdaptActor(self,3);self.settings={k:v['original'] for k,v in TUNING.items()}
 def setup_round(self):
  super().setup_round()
  if self.status[3]=='active':
   v=self.views[3];context=NeutralLifeView(v) if self.round==15 else v
   for name,choices in TUNING.items():
    label=self.policies[3].choose('tune_'+name,context,['original']+[k for k in choices if k!='original'])
    self.settings[name]=choices[label]
    if self.collector:self.collector.tune_counts[(self.round,name,label)]+=1

class AdaptCollector(EvalCollector):
 def __init__(self,path):
  super().__init__(path);self.tune_counts=collections.Counter();self.context_writer=self.writer('learner_decisions.csv.gz',['game','round','draws','ships','chest','harbor','reason','own_escape','other_escape','other_maroon','calm_hazard','calm_surge','p_surge','p_whirlpool','projected_lead']);self.final_counts=collections.Counter()
 def adaptation_decision(self,v,result,reason):
  _,_,s,w=v.odds();g=v.g
  self.context_writer.writerow([g.game_id,v.round,v.draws,v.ships[0],v.chest,result,reason,'escape' in v.held[0],sum(v.status[p]=='active' and 'escape' in v.held[p] for p in range(1,4)),v.other_maroon,v.calm_cards['whirlpool']+v.calm_cards['marooned'],v.calm_cards['surge'],s,w,v.projected_lead()])
  if g.game_id>25000:self.final_counts[reason+(' harbor' if result else ' continue')]+=1

def run(n=30000):
 path=DEST/'mixed_learning';path.mkdir(parents=True,exist_ok=True)
 ps={v:FixedGrant2(p) for v,p in PATHS.items()};before={v:dict(x.q) for v,x in ps.items()};hashes={v:hashlib.sha256(p.read_bytes()).hexdigest() for v,p in PATHS.items()}
 learner=BroadLearner.load(PATHS[5]);learner.training=True;learner.n={k:0 for k in learner.q};learner.rng=random.Random(150517);learner.save(path/'policy_before.json')
 f=FrozenGrant();c=AdaptCollector(path);blocks=[];credit=[0.]*4;scores=[0.]*4;elim=[0]*4;start=time.time();tune_previous=collections.Counter()
 for i in range(n):
  learner.epsilon=[.6,.45,.3,.18,.08,.02][min(5,i*6//n)]
  g=AdaptGame(150_000_000+i,[2,3,4,5],[ps[2],ps[3],ps[4],learner],f,c,i+1);reward=g.play();learner.finish(reward[3])
  for p in range(4):credit[p]+=reward[p];scores[p]+=g.gold[p];elim[p]+=g.ships[p]==0
  if (i+1)%5000==0:
   block={'games':i+1,'win_shares':[x/5000 for x in credit],'mean_gold':[x/5000 for x in scores],'zero_ships':elim,'epsilon':learner.epsilon,'seconds':round(time.time()-start,1)};blocks.append(block);print(json.dumps(block),flush=True)
   learner.save(path/f'policy_{i+1}.json');counts=c.tune_counts-tune_previous;tune_previous=c.tune_counts.copy();(path/f'tuning_{i+1}.json').write_text(json.dumps([{'round':k[0],'preference':k[1],'choice':k[2],'uses':v} for k,v in counts.items()],indent=2));credit=[0.]*4;scores=[0.]*4;elim=[0]*4
 c.close();learner.save(path/'grant5_adapted_policy.json');r=save_result(c,path,[2,3,4,5],150_000_000,True);r['blocks']=blocks;r['learning_updates']=sum(learner.n.values());r['final_decision_reasons']=dict(c.final_counts);r['frozen_policy_sha256']=hashes;(path/'results.json').write_text(json.dumps(r,indent=2))
 assert before=={v:dict(x.q) for v,x in ps.items()}
 assert hashes=={v:hashlib.sha256(p.read_bytes()).hexdigest() for v,p in PATHS.items()}
 print('DONE',flush=True)
if __name__=='__main__':run()

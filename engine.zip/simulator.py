"""Treasure Tempest: no-power, four-player, public-score simulation."""
import argparse, collections, itertools, json, math, random, time
from pathlib import Path

BASE = {'rudder':2,'cannon':2,'coin_curse':8,'idol':3,'diamond':4,'echo':2,
        'key':2,'chest':2,'escape':3,'coin':12,'crown':2,'crate':6,'marooned':2,
        'prophecy':3,'siren':2,'surge':4,'trick':3,'whirlpool':4,'wave':2}
TREASURE = {'diamond':30,'coin':10,'crown':100,'crate':20}
HAZARDS = {'marooned','whirlpool'}
CURSES = {'coin_curse':10,'idol':50}
ARMS = (.38, .58, .82, 1.12, 1.55, 2.2, 3.2)

def bucket(x, limits):
    return sum(x > v for v in limits)

class Learner:
    """Monte Carlo contextual policy: choose round risk appetite; learn final win credit.

    Each arm is a card-counting harbor policy, not a fixed gold threshold. Its
    expected-risk threshold is recalculated at every legal harbor window.
    """
    def __init__(self, seed=73):
        self.q = {}
        self.n = {}
        self.rng = random.Random(seed)
        self.training = False
        self.epsilon = 0
        self.trace = []

    def context(self, g, p):
        gap = g.gold[p] - max(g.gold[j] for j in range(len(g.ships)) if j != p)
        return (bucket(g.round,(4,8,12)), bucket(g.ships[p],(1,3)),
                bucket(gap,(-250,100)), bucket(g.ships[p]-max(g.ships[j] for j in range(len(g.ships)) if j != p),(-1,0)))

    def choose(self, g, p):
        s = self.context(g,p)
        q = self.q.setdefault(s,[.25]*len(ARMS))
        n = self.n.setdefault(s,[0]*len(ARMS))
        if self.training and self.rng.random() < self.epsilon:
            a = self.rng.randrange(len(ARMS))
        else:
            # Unseen/equal states use the middle arm, without privileged information.
            a = max(range(len(ARMS)), key=lambda a:(q[a],-abs(a-3)))
        if self.training:
            self.trace.append((s,a))
        return ARMS[a]

    def finish(self, reward):
        # Every round's choice gets the full-game outcome, never gold as reward.
        for s,a in set(self.trace):
            self.n[s][a] += 1
            n = self.n[s][a]
            alpha = 1 / min(n,150)
            self.q[s][a] += alpha*(reward-self.q[s][a])
        self.trace.clear()

    def save(self,path):
        Path(path).write_text(json.dumps({'algorithm':'Monte Carlo contextual bandit over dynamic card-counting policies',
            'arms':ARMS,'states':[{'state':s,'q':q,'visits':self.n[s]} for s,q in sorted(self.q.items())]},indent=2))

class Game:
    def __init__(self, seed, learner=None, learner_seat=0, player_count=4):
        if not 3 <= player_count <= 6:raise ValueError("Treasure Tempest supports 3–6 players")
        self.rng=random.Random(seed)
        self.learner=learner
        self.learner_seat=learner_seat
        self.ships=[6]*player_count
        self.gold=[0.]*player_count
        self.round=0
        self.start=self.rng.randrange(player_count)
        self.events=collections.Counter()
        self.decisions=[]
        self.total_draws=0
        self.ended=False

    def setup_round(self):
        self.round += 1
        counts=dict(BASE)
        counts['whirlpool'] += int(self.round>=6)+int(self.round>=11)
        self.deck=[c for c,n in counts.items() for _ in range(n)]
        self.rng.shuffle(self.deck)
        self.remaining=collections.Counter(self.deck)
        self.discard=[]
        self.held=[[] for _ in range(len(self.ships))]
        self.status=['active' if n else 'out' for n in self.ships]
        self.chest=10*self.round
        self.draws=0
        self.safe_next=False
        self.block=0
        self.previous=None
        self.known=[[] for _ in range(len(self.ships))]
        self.appetite=[self.rng.uniform(.5,1.8) for _ in range(len(self.ships))]
        if self.learner and self.status[self.learner_seat] == 'active':
            self.appetite[self.learner_seat]=self.learner.choose(self,self.learner_seat)
        self.initial_counts=collections.Counter(self.deck)

    def safe(self):
        return self.draws < 3 or self.safe_next

    def desperate(self,p):
        gap=max(self.gold[j] for j in range(len(self.ships)) if j!=p)-self.gold[p]
        # A substantial deficit, relative to rounds remaining. Visible scores only.
        return gap > max(300,65*(16-self.round))

    def expected_card(self,c,p):
        if c=='echo':
            c=self.previous or 'echo'
        t=self.chest
        if c in TREASURE: return TREASURE[c],0.,0.
        if c in CURSES: return -min(t,CURSES[c]),0.,0.
        if c=='surge': return t if t else 100,0.,0.
        if c=='trick': return 20-min(t,20),0.,0.
        if c=='whirlpool': return 0.,1.,1.
        if c=='marooned': return 0.,0.,1.
        return 0.,0.,0.

    def harbor_value(self,p):
        return self.chest + (20 if 'escape' in self.held[p] else 0)

    def should_harbor(self,p):
        if self.status[p]!='active' or self.safe() or self.block: return False
        desperate=self.desperate(p)
        if self.ships[p]==1 and not desperate:
            self.events['one_ship_default_harbors']+=1
            return True
        counts=self.remaining
        if self.known[p]: counts=collections.Counter([self.known[p][0]])
        n=sum(counts.values())
        if not n: return True
        gain=loss=shiprisk=0.
        for c,k in counts.items():
            d,w,s=self.expected_card(c,p)
            gain+=k*d/n
            loss+=k*w/n
            shiprisk+=k*s/n
        protected='escape' in self.held[p]
        lost_gold=self.chest*(.5 if protected else 1)
        # Low remaining ships make every chance of sinking more expensive.
        ship_value=30+22*(16-self.round)/max(1,self.ships[p])
        if self.ships[p]<=3: ship_value*=1.55
        if self.ships[p]==1: ship_value*=2
        risk=loss*lost_gold+shiprisk*ship_value
        # Positive option value captures future draws, safe cards, and waiting.
        opportunity=max(4,gain+8)
        appetite=self.appetite[p]
        if desperate: appetite*=1.8
        if self.ships[p]==1 and desperate:
            self.events['one_ship_desperate_decisions']+=1
        return risk > opportunity*appetite

    def harbor(self,p,forced=False):
        if self.status[p]!='active': return
        self.gold[p]+=self.harbor_value(p)
        self.status[p]='harbor'
        self.events['forced_harbors' if forced else 'voluntary_harbors']+=1
        self.events['harbor_chest_total']+=self.chest

    def sink(self,p,maroon=False):
        if self.status[p]!='active': return
        self.ships[p]-=1
        self.status[p]='sunk'
        if maroon:self.gold[p]+=self.chest
        if 'escape' in self.held[p]:self.gold[p]+=self.chest/2
        self.events['sinkings']+=1
        if not self.ships[p]:self.events['eliminations']+=1

    def check_end(self):
        alive=[p for p,n in enumerate(self.ships) if n]
        if len(alive)>1:return False
        if alive:
            p=alive[0]
            # Only a player still in the storm harbors; no second payout after sinking.
            self.harbor(p,True)
            self.gold[p]+=100*(16-self.round)
        self.ended=True
        return True

    def windows(self,current):
        # Random declaration order avoids deterministic seat priority.
        order=list(range(len(self.ships))); self.rng.shuffle(order)
        for p in order:
            if self.should_harbor(p):self.harbor(p)

    def prophecy(self,p):
        k=min(2,len(self.deck))
        if not k:return
        cards=self.deck[-k:][::-1]
        # Fixed heuristic: discard an imminent dangerous card to bottom; put useful
        # treasure/surge first. No inspection beyond the legal top two cards.
        def value(c):
            if c=='whirlpool':return -1000
            if c=='marooned':return -300
            if c=='siren':return -150
            if c=='rudder':return -40
            if c in CURSES:return -CURSES[c]
            if c=='surge':return self.chest or 100
            return TREASURE.get(c,5)
        cards.sort(key=value,reverse=True)
        bottom=None
        if len(cards)>1 and value(cards[-1])<0:bottom=cards.pop()
        del self.deck[-k:]
        if bottom:self.deck.insert(0,bottom)
        self.deck.extend(reversed(cards))
        self.known=[[] for _ in range(len(self.ships))]
        self.known[p]=cards.copy()

    def cannon(self,p):
        targets=[j for j in range(len(self.ships)) if j!=p and self.status[j]=='active']
        if targets:
            target=max(targets,key=lambda j:self.gold[j]+30*self.ships[j])
            self.harbor(target,True)

    def draw(self,p):
        if not self.deck:
            if not self.discard:raise RuntimeError('No drawable cards')
            self.deck=self.discard; self.discard=[]; self.rng.shuffle(self.deck)
            self.remaining=collections.Counter(self.deck);self.known=[[] for _ in range(len(self.ships))]
            self.events['deck_exhaustions']+=1
        safe=self.safe()
        self.safe_next=False
        c=self.deck.pop();self.remaining[c]-=1
        for known in self.known:
            if known:known.pop(0)
        self.draws+=1;self.total_draws+=1
        self.events['cards_drawn']+=1
        self.block=max(0,self.block-1)
        effect=(self.previous or 'echo') if c=='echo' else c
        self.previous=effect
        hold=False
        if safe:
            self.chest+=TREASURE.get(c,50 if c in HAZARDS else 0 if c in CURSES else 10)
        elif effect in TREASURE:self.chest+=TREASURE[effect]
        elif effect in CURSES:self.chest=max(0,self.chest-CURSES[effect])
        elif effect=='surge':self.chest=self.chest*2 if self.chest else 100
        elif effect in ('key','chest'):self.safe_next=True
        elif effect=='siren':self.block+=4
        elif effect=='whirlpool':
            for j in range(len(self.ships)):self.sink(j)
        elif effect=='marooned':self.sink(p,True);hold=True
        elif effect=='rudder':self.harbor(p,True);self.gold[p]-=30;hold=True
        elif effect=='escape':
            if 'escape' not in self.held[p]:hold=True
        elif effect=='trick':self.chest=max(0,self.chest-20);self.gold[p]+=20;hold=True
        elif effect=='wave':
            self.deck.extend(self.discard);self.discard=[];self.rng.shuffle(self.deck)
            self.remaining=collections.Counter(self.deck);self.known=[[] for _ in range(len(self.ships))]
            self.safe_next=True;self.gold[p]+=10;hold=True
        elif effect=='prophecy':self.prophecy(p)
        elif effect=='cannon':self.cannon(p)
        if hold:
            # Keep physical identity separately from the copied effect.
            self.held[p].append(effect)
            self.physical_held.append(c)
        else:self.discard.append(c)
        if self.chest>=9999:
            self.chest=9999
            for j in range(len(self.ships)):self.harbor(j,True)
        self.check_end()

    def play(self):
        while self.round<15 and not self.ended:
            self.setup_round();self.physical_held=[]
            p=self.start
            while 'active' in self.status and not self.ended:
                self.windows(p)
                if 'active' not in self.status:break
                if self.status[p]=='active':self.draw(p)
                p=(p+1)%len(self.ships)
                if self.draws>10000:raise RuntimeError('Round exceeded safety limit')
            assert collections.Counter(self.deck+self.discard+self.physical_held)==self.initial_counts
            self.start=(self.start+1)%len(self.ships)
        if not self.ended:
            most=max(self.ships)
            if self.ships.count(most)==1:self.gold[self.ships.index(most)]+=100
        for p in range(len(self.ships)):self.gold[p]+=30*self.ships[p]
        best=max(self.gold)
        winners=[p for p,x in enumerate(self.gold) if abs(x-best)<1e-9]
        return [1/len(winners) if p in winners else 0 for p in range(len(self.ships))]

def evaluate(learner,n,seed):
    learner.training=False
    credit=0.;sq=0.;scores=[];ships=[];rounds=[];events=collections.Counter();seat_credit=[0.]*4;seat_n=[0]*4
    for i in range(n):
        seat=i%4
        g=Game(seed+i,learner,seat);r=g.play()[seat]
        credit+=r;sq+=r*r;scores.append(g.gold[seat]);ships.append(g.ships[seat]);rounds.append(g.round)
        events.update(g.events);seat_credit[seat]+=r;seat_n[seat]+=1
    mean=credit/n
    se=math.sqrt(max(0,sq/n-mean*mean)/n)
    return {'games':n,'win_credit_rate':mean,'approx_95_ci':[mean-1.96*se,mean+1.96*se],
            'mean_final_gold':sum(scores)/n,'mean_remaining_ships':sum(ships)/n,'mean_rounds':sum(rounds)/n,
            'seat_win_rates':[seat_credit[i]/seat_n[i] for i in range(4)],'all_players_events':dict(events)}

def run(args):
    out=Path(args.output);out.mkdir(exist_ok=True)
    model=Learner()
    print('Evaluating untrained middle-arm policy...',flush=True)
    baseline=evaluate(model,args.evaluation,2_000_000)
    model.training=True
    start=time.time();batch=0;history=[]
    for i in range(args.games):
        model.epsilon=.45-.35*(i/max(1,args.games-1))
        seat=i%4
        g=Game(10000+i,model,seat);reward=g.play()[seat]
        model.finish(reward);batch+=reward
        if (i+1)%10000==0:
            row={'games':i+1,'training_win_credit_last_10000':batch/10000,'elapsed_seconds':round(time.time()-start,2)}
            history.append(row);print(json.dumps(row),flush=True);batch=0
    model.save(out/'trained_policy.json')
    print('Evaluating frozen learned policy on held-out seeds...',flush=True)
    final=evaluate(model,args.evaluation,2_000_000)
    # Matchup symmetry check: all four random opponents should average 25% each.
    random_credit=[0.]*4
    for i in range(2000):
        r=Game(4_000_000+i).play()
        random_credit=[a+b for a,b in zip(random_credit,r)]
    results={'training_games':args.games,'training_seed_start':10000,'evaluation_seed_start':2000000,
             'baseline':baseline,'trained':final,'history':history,
             'all_random_sanity_win_rates':[v/2000 for v in random_credit],
             'learned_states':len(model.q),'training_seconds':round(time.time()-start,2)}
    (out/'results.json').write_text(json.dumps(results,indent=2))
    print(json.dumps(results,indent=2),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--games',type=int,default=100000)
    p.add_argument('--evaluation',type=int,default=10000);p.add_argument('--output',default='results')
    run(p.parse_args())

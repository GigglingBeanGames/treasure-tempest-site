"""Five controlled 10,000-game tests of requested changes to frozen Grant 2.0."""
import argparse,collections,csv,gzip,hashlib,itertools,json,math,time
from pathlib import Path
from simulator import TREASURE,CURSES,BASE
from grant2 import Adaptive,FrozenGrant,ExperimentGame,Collector,STRATEGIES

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'experiments/grant2_rule_tests'
CASES={
    '1_last_life':{'life'},
    '2_prophecy':{'prophecy'},
    '3_cannon':{'cannon'},
    '4_escape_risk':{'escape_risk'},
    '5_combined':{'life','prophecy','cannon','escape_risk'},
}
PERSONAL={'escape','trick'}
MAGIC={'key','chest','prophecy','wave','surge'}
SHIP_APPETITE={1:.35,2:.55,3:.8,4:1.,5:1.2,6:1.4}

class NeutralLifeView:
    """Read-only policy view: round-15 own life count is a constant, not game state."""
    def __init__(self,g):self.g=g
    @property
    def ships(self):
        x=self.g.ships.copy();x[0]=6;return x
    def __getattr__(self,name):return getattr(self.g,name)

def prophecy_plan(cards,active,blocked):
    """Choose among all legal top-two reorder / one-card-bottom outcomes.

    Explicit priority scores resolve conflicting requests without inspecting any
    unobserved cards. No treasure can go to the bottom. When blocked, avoid a top
    Whirlpool whenever any legal alternative exists.
    """
    if len(cards)<2:return cards.copy(),None
    options=[]
    for order in (cards,cards[::-1]):options.append((list(order),None))
    for bottom_i in range(2):
        if cards[bottom_i] not in TREASURE:
            options.append(([cards[1-bottom_i]],cards[bottom_i]))
    if blocked:
        safe_options=[o for o in options if o[0][0]!='whirlpool']
        if safe_options:options=safe_options
    def value(option):
        order,bottom=option;score=0.
        if bottom in PERSONAL and active>=3:score+=600
        if bottom in CURSES:score+=400+CURSES[bottom]
        if bottom=='siren':score+=180
        if bottom=='whirlpool':score+=600 if active==1 else 100
        if active==1:
            if bottom=='marooned':score+=350
            if bottom=='rudder':score+=300
        for i,c in enumerate(order):
            if c in PERSONAL:
                if active==1:score+=250 if i==0 else 100
                elif active==2:score+=250 if i==1 else -50
                else:score-=200
            if c in ('marooned','rudder'):
                if active>1:score+=350 if i==0 else 0
                elif i==0:score-=350 if c=='marooned' else 300
            if c=='whirlpool' and i==0:
                score+=60 if active>1 and not blocked else -1000
            if c in MAGIC:
                score+=80 if i==1 else 0
        return (score,len(order))
    return max(options,key=value)

class RuleGame(ExperimentGame):
    def __init__(self,*args,changes=(),**kwargs):
        super().__init__(*args,**kwargs)
        self.changes=set(changes);self.metrics=collections.Counter();self.plans=[]
        self.cannon_drawer=None;self.cannon_target=None
        self.exits_detail=[];self.decision_counts=collections.Counter()
        self.last_life_games=False
    def setup_round(self):
        super().setup_round();self.plans=[]
        if self.ships[0]==1:self.last_life_games=True
        if 'life' in self.changes and self.round==15 and self.status[0]=='active':
            view=NeutralLifeView(self);old=self.strategy[0]
            name=self.adaptive.choose('round',view,[s[0] for s in STRATEGIES])
            self.strategy=next(s for s in STRATEGIES if s[0]==name)
            self.appetite[0]=self.frozen.appetite(view,0)*self.strategy[1]
            self.choice_stats['round_policy:'+old]-=1
            self.choice_stats['round_policy:'+name]+=1
    def record_decision(self,result,reason):
        self.reason=reason;self.choice_stats[reason]+=1
        self.decision_counts[(self.ships[0],'harbor' if result else 'continue')]+=1
        if self.ships[0]==1:
            stage='round15' if self.round==15 else 'rounds1to14'
            self.metrics['one_life_'+stage+('_harbor_decisions' if result else '_continue_decisions')]+=1
        if self.collector:self.collector.decision(self,self.odds(),result,reason)
        return result
    def risk_harbor(self,boost=1.):
        counts=collections.Counter(self.known[0][:1]) if self.known[0] else self.remaining
        n=sum(counts.values())
        if not n:return True
        gain=loss=shiprisk=0.
        for c,k in counts.items():
            d,w,s=self.expected_card(c,0);gain+=k*d/n;loss+=k*w/n;shiprisk+=k*s/n
        life_neutral='life' in self.changes and self.round==15
        ships=self.ships[0]
        ship_value=0. if life_neutral else 30+22*(16-self.round)/ships
        if not life_neutral:
            if ships<=3:ship_value*=1.55
            if ships==1:ship_value*=2
        protected='escape' in self.held[0]
        risk=loss*self.chest*(.5 if protected else 1)+shiprisk*ship_value
        opportunity=max(4,gain+8)
        appetite=self.appetite[0]*(1.8 if self.desperate(0) else 1.)
        if 'escape_risk' in self.changes and not life_neutral:appetite*=SHIP_APPETITE[ships]
        return risk>opportunity*appetite*boost
    def should_harbor(self,p):
        if p!=0:return super().should_harbor(p)
        if not self.changes:return super().should_harbor(p)
        if self.status[0]!='active' or self.safe() or self.block:return False
        if 'prophecy' in self.changes and self.known[0] and self.known[0][0]=='whirlpool':
            return self.record_decision(True,'known_whirlpool_harbor')
        life_neutral='life' in self.changes and self.round==15
        if self.ships[0]==1 and not life_neutral:
            if 'life' in self.changes:return self.record_decision(True,'strict_one_life_harbor')
            if not self.desperate(0):return self.record_decision(True,'one_ship_default')
        _,_,prefer_surge,prefer_escape,echo=self.strategy
        _,_,s,w=self.odds()
        risk_patch='escape_risk' in self.changes
        cautious=risk_patch and self.ships[0]<=3 and not life_neutral
        if echo and self.last_surge==self.draws:
            leave=self.risk_harbor(2.) if cautious else False
            if not leave:self.surge_followup_pending=True
            return self.record_decision(leave,'life_caution_after_surge' if leave else 'one_more_after_surge')
        if echo and self.followup_exit:return self.record_decision(True,'leave_after_surge_followup')
        if 'escape' in self.held[0]:
            if risk_patch:
                if s>0 and w<=1.5*s:
                    result=self.risk_harbor(2.5)
                    return self.record_decision(result,'escape_1_5_risk_harbor' if result else 'escape_1_5_continue')
            elif prefer_escape and s>0 and w<=2*s:
                return self.record_decision(False,'escape_odds_continue')
        if prefer_surge and s>w:
            result=self.risk_harbor(1.75) if cautious else False
            return self.record_decision(result,'life_caution_surge_odds' if result else 'surge_odds_continue')
        result=self.risk_harbor()
        return self.record_decision(result,'grant_risk_harbor' if result else 'grant_risk_continue')
    def harbor(self,p,forced=False):
        if self.status[p]!='active':return
        if self.cannon_drawer is not None:self.cannon_target=p
        if p==0:
            self.exits_detail.append({'round':self.round,'type':'forced' if forced else 'voluntary','draws':self.draws,
                'own_draws':self.own_draws[0],'ships':self.ships[0],'escape':'escape' in self.held[0],'chest':self.chest,'reason':self.reason})
        super().harbor(p,forced)
    def sink(self,p,maroon=False):
        if p==0 and self.status[p]=='active':
            self.exits_detail.append({'round':self.round,'type':'sunk','draws':self.draws,'own_draws':self.own_draws[0],
                'ships':self.ships[0],'escape':'escape' in self.held[0],'chest':self.chest,'reason':str(self.resolving)})
            if self.known[0] and self.known[0][0]=='whirlpool':self.metrics['sank_before_known_whirlpool_draw']+=1
        super().sink(p,maroon)
        if p==0 and self.ships[0]==1:self.last_life_games=True
    def cannon(self,p):
        eligible=[j for j in self.seating if j!=p and self.status[j]=='active']
        eligible_gold={j:self.gold[j] for j in eligible}
        self.cannon_drawer=p;self.cannon_target=None
        if p==0 and 'cannon' in self.changes:
            if eligible:
                target=max(eligible,key=lambda j:self.gold[j]);self.harbor(target,True)
                self.choice_stats['cannon:score_leader']+=1
            else:self.choice_stats['cannon:no_target']+=1
        else:super().cannon(p)
        assert (not eligible) or (self.cannon_target in eligible), 'Cannon failed to choose eligible opponent'
        if p==0:
            self.metrics['cannon_effects']+=1
            if not eligible:self.metrics['cannon_no_eligible_opponent']+=1
            else:
                self.metrics['cannon_targeted_opponent']+=1
                if eligible_gold[self.cannon_target]==max(eligible_gold.values()):self.metrics['cannon_target_was_highest_scoring_eligible']+=1
                # All eligible targets were active at entry; scores at target time
                # are captured by the chosen strategy, not by post-harbor ranking.
        self.cannon_drawer=None;self.cannon_target=None
    def prophecy(self,p):
        if self.plans:self.metrics['planned_cards_invalidated_by_prophecy']+=len(self.plans)
        self.plans=[]
        if p!=0 or 'prophecy' not in self.changes:return super().prophecy(p)
        k=min(2,len(self.deck));cards=list(reversed(self.deck[-k:])) if k else []
        if not cards:return
        active=self.status.count('active')
        order,bottom=prophecy_plan(cards,active,self.block>0)
        assert bottom not in TREASURE
        del self.deck[-k:]
        if bottom:self.deck.insert(0,bottom)
        self.deck.extend(reversed(order));self.known=[[] for _ in range(4)];self.known[0]=order.copy()
        self.metrics['prophecy_activations']+=1
        self.metrics['prophecy_active_players_'+str(active)]+=1
        self.metrics['prophecy_top_'+order[0]]+=1
        if len(order)>1:self.metrics['prophecy_second_'+order[1]]+=1
        if bottom:self.metrics['prophecy_bottom_'+bottom]+=1
        if order[0]=='whirlpool':
            self.metrics['prophecy_whirlpool_left_top']+=1
            if self.block:self.metrics['prophecy_unavoidable_whirlpool_while_blocked']+=1
        if self.block and 'whirlpool' in cards and order[0]!='whirlpool':self.metrics['prophecy_whirlpool_moved_off_top_while_blocked']+=1
        for i,c in enumerate(order):
            if c in PERSONAL or c in MAGIC:
                intent='self' if (active==1 or (active==2 and i==1)) else 'opponent'
                self.plans.append((c,intent))
            elif c in ('marooned','rudder'):
                self.plans.append((c,'opponent' if active>1 else 'self'))
            else:self.plans.append((c,'unspecified'))
        if self.collector:self.collector.prophecy_record(self,cards,order,bottom,active)
    def draw(self,p):
        planned=self.plans.pop(0) if self.plans else None
        c=self.deck[-1] if self.deck else None;safe=self.safe();effect=self.previous if c=='echo' else c
        if self.known[0] and self.known[0][0]=='whirlpool' and self.status[0]=='active':
            self.metrics['known_whirlpool_drawn_while_active']+=1
            if self.block:self.metrics['known_whirlpool_drawn_blocked']+=1
            elif safe:self.metrics['known_whirlpool_drawn_safe']+=1
            elif 'prophecy' in self.changes:raise AssertionError('Failed to harbor before known fatal Whirlpool')
        super().draw(p)
        if planned:
            card,intent=planned
            assert card==c,'Tracking a reordered or shuffled plan'
            actual='self' if p==0 else 'opponent'
            self.metrics['planned_'+card+'_drawn_by_'+actual]+=1
            if intent!='unspecified':self.metrics['planned_recipient_'+('correct' if actual==intent else 'changed')]+=1
        if not safe and effect=='wave':
            self.metrics['planned_cards_invalidated_by_wave']+=len(self.plans);self.plans=[]

class RuleCollector(Collector):
    def __init__(self,path=None):
        super().__init__(path,detail_start=1)
        self.metrics=collections.Counter();self.decisions_by_ship=collections.Counter()
        self.zero_ships=[0]*4;self.eliminated_win_credit=[0.]*4
        self.final_score_hist=[collections.Counter() for _ in range(4)]
        self.round_exit=collections.Counter();self.one_life_games=0
        if self.path:
            self.prophecy_writer=self.writer('prophecy_choices.csv.gz',['game','round','active_players','harbor_block','seen','top','second','bottom'])
            self.exit_writer=self.writer('grant2_exits.csv.gz',['game','round','type','draws','own_draws','ships','escape','chest','reason'])
    def prophecy_record(self,g,cards,order,bottom,active):
        if self.path:self.prophecy_writer.writerow([g.game_id,g.round,active,g.block,'+'.join(cards),order[0],order[1] if len(order)>1 else '',bottom or ''])
    def finish_game(self,g,reward):
        super().finish_game(g,reward)
        self.metrics.update(g.metrics);self.decisions_by_ship.update(g.decision_counts)
        self.one_life_games+=g.last_life_games
        for p in range(4):
            self.final_score_hist[p][g.gold[p]]+=1
            if g.ships[p]==0:
                self.zero_ships[p]+=1;self.eliminated_win_credit[p]+=reward[p]
        for row in g.exits_detail:
            if self.path:self.exit_writer.writerow([g.game_id,*row.values()])
            stage='round15' if row['round']==15 else 'rounds1to14'
            if row['ships']==1:self.round_exit[(stage,row['type'])]+=1
        for p in range(4):
            earned=sum(r['round_gold'] for r in g.round_data if r['bot']==p)
            assert abs(earned+g.game_bonus[p]+g.sell_gold[p]-g.gold[p])<1e-7
    def summary(self):
        s=super().summary()
        s.update({'rule_metrics':dict(self.metrics),'games_zero_ships':self.zero_ships,
            'eliminated_win_credit':self.eliminated_win_credit,'games_reaching_one_ship_grant2':self.one_life_games,
            'final_score_distribution':[self.hist_stats(h) for h in self.final_score_hist],
            'decisions_by_ships':{str(n):{'continue':self.decisions_by_ship[(n,'continue')],
                'harbor':self.decisions_by_ship[(n,'harbor')]} for n in range(1,7)},
            'one_life_round_outcomes':{a+'_'+b:v for (a,b),v in self.round_exit.items()}})
        return s

def run_case(case,n,output,seed):
    path=Path(output)/case;path.mkdir(parents=True,exist_ok=True)
    frozen=FrozenGrant();model=Adaptive.load(OUT/'starting_grant2_policy.json')
    c=RuleCollector(path);started=time.time()
    model_hash=hashlib.sha256((OUT/'starting_grant2_policy.json').read_bytes()).hexdigest()
    for i in range(n):
        g=RuleGame(seed+i,frozen,model,collector=c,game_id=i+1,changes=CASES[case])
        g.play()
        if (i+1)%2000==0:print(json.dumps({'case':case,'games':i+1,'win_rate':c.credit[0]/c.n,'elapsed_seconds':round(time.time()-started,1)}),flush=True)
    c.close();result=c.summary()
    result.update({'case':case,'changes':sorted(CASES[case]),'seed_start':seed,'learning_enabled':False,
                   'starting_model_sha256':model_hash,'fixed_opponents_sha256':frozen.sha256,
                   'elapsed_seconds':round(time.time()-started,1)})
    (path/'results.json').write_text(json.dumps(result,indent=2))
    print('COMPLETE '+json.dumps({'case':case,'win_rates':result['win_rates'],'games_zero_ships':result['games_zero_ships']}),flush=True)
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--case',choices=['all',*CASES],default='all')
    p.add_argument('--games',type=int,default=10000);p.add_argument('--seed',type=int,default=40000000)
    p.add_argument('--output',default=str(OUT));a=p.parse_args()
    cases=CASES if a.case=='all' else [a.case]
    for case in cases:run_case(case,a.games,a.output,a.seed)

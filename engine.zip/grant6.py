"""Five-player Grant 6 lead-protection training."""
from adapt_grant5 import *
OUT6=ROOT/'experiments/grant6'
PARENT=DEST/'mixed_learning/grant5_adapted_policy.json'
NAMES6=['Grant 2.0','Grant 3.0','Grant 4.0','Grant 5.0','Grant 6.0']
TUNING6={**TUNING,'lead_risk':{'strong':.15,'original':.25,'moderate':.4},'lead_harbor':{'moderate':.55,'original':.75,'strong':.9},'alone_lead_harbor':{'moderate':.97,'original':.99,'always':1.}}
class Learner6(BroadLearner):
 def choose(self,kind,g,labels):
  state=(kind,)+self.context(g)
  if kind!='round':state+=(sum(g.chest>x for x in (100,300)),)
  for label in labels:self.q.setdefault(state+(label,),.2);self.n.setdefault(state+(label,),0)
  return Adaptive.choose(self,kind,g,labels)
 def save(self,path):
  Adaptive.save(self,path);d=json.loads(Path(path).read_text());d.update({'experiment':'Grant 6 five-player lead protection','parent':str(PARENT),'tuning_options':TUNING6,'epsilon_schedule':[.6,.5,.4,.3,.22,.16,.10,.06,.03,.01],'configuration':'Grant6Game, learner identity 4, [2,3,4,5,6]','initial_value_scaling':.8});Path(path).write_text(json.dumps(d,indent=2))
class Actor6(AdaptActor):
 def leading(self):return self.gold[0]>max(self.gold[1:])
 def others_harbored(self):return all(s=='harbor' for s in self.status[1:])
 def preference_multiplier(self):
  return AdaptActor.preference_multiplier(self)*(self.settings['lead_risk'] if self.leading() else 1.)
 def should_harbor(self,p=0):
  if self.status[0]!='active' or self.safe() or self.block:return False
  if self.chest==0:return self.record_decision(False,'zero_gold_never_harbor')
  if self.round==15 and not self.projected_lead():return self.record_decision(False,'round15_not_leading_continue')
  reason=self.memory_reason(0)
  if reason:return self.record_decision(True,reason)
  if self.ships[0]==1 and self.round<15:return self.record_decision(True,'strict_one_life_harbor')
  if self.leading():
   if self.others_harbored() and self.rng.random()<self.settings['alone_lead_harbor']:
    return self.record_decision(True,'protect_lead_all_others_harbored')
   if self.risk_harbor() or self.rng.random()<self.settings['lead_harbor']:
    return self.record_decision(True,'protect_current_lead')
  return AdaptActor.should_harbor(self,0)
class Grant6Game(TournamentGame):
 def __init__(self,*a,**kw):
  super().__init__(*a,**kw);self.views[-1]=Actor6(self,len(self.ships)-1);self.settings={k:v['original'] for k,v in TUNING6.items()}
 def windows(self,current):
  p=len(self.ships)-1;was_all_harbored=self.views[p].others_harbored()
  super().windows(current)
  # React before a card is drawn when later declarations leave a leader alone.
  v=self.views[p]
  if not was_all_harbored and v.others_harbored() and v.leading() and self.status[p]=='active' and not self.safe() and not self.block:
   if v.should_harbor():self.harbor(p)
 def setup_round(self):
  super().setup_round()
  p=len(self.ships)-1
  if self.status[p]=='active':
   v=self.views[p];context=NeutralLifeView(v) if self.round==15 else v
   for name,choices in TUNING6.items():
    label=self.policies[p].choose('tune_'+name,context,['original']+[k for k in choices if k!='original']);self.settings[name]=choices[label]
    if self.collector:self.collector.tune_counts[(self.round,name,label)]+=1

class Collector6(Collector):
 def __init__(self,path):
  super().__init__(path,detail_start=10**9,player_count=5,names=NAMES6)
  self.tune_counts=collections.Counter();self.lead_counts=collections.Counter();self.outcome_counts=collections.Counter()
  self.dep=self.writer('all_departures.csv.gz',['game','round','bot','draws','forced','chest','ships'])
  self.context_writer=self.writer('grant6_decisions_final10000.csv.gz',['game','round','draws','chest','ships','harbor','reason','leading','all_others_harbored','own_escape','p_surge','p_whirlpool','projected_lead'])
  self.score_rows=[[] for _ in range(5)];self.round_lengths=[];self.game_rounds=[]
 def prophecy_record(self,*args):pass
 def adaptation_decision(self,v,result,reason):
  g=v.g;lead=v.leading();alone=v.others_harbored();p=int(g.game_id>40000)
  for period in ['all']+(['final10000'] if p else []):
   self.lead_counts[(period,'leading' if lead else 'not_leading','decisions')]+=1
   self.lead_counts[(period,'leading' if lead else 'not_leading','harbor')]+=result
   if lead and alone:self.lead_counts[(period,'lead_all_others_harbored','decisions')]+=1;self.lead_counts[(period,'lead_all_others_harbored','harbor')]+=result
   if v.chest==0:self.lead_counts[(period,'zero_gold','decisions')]+=1;assert not result
   if v.round==15 and not v.projected_lead():self.lead_counts[(period,'round15_behind','decisions')]+=1;assert not result
   self.lead_counts[(period,'reason',reason+(' harbor' if result else ' continue'))]+=1
  if p:
   _,_,s,w=v.odds();self.context_writer.writerow([g.game_id,v.round,v.draws,v.chest,v.ships[0],result,reason,lead,alone,'escape' in v.held[0],s,w,v.projected_lead()])
 def finish_game(self,g,reward):
  super().finish_game(g,reward);self.game_rounds.append(g.round)
  for rd,p,d,f,c,s in g.departures:self.dep.writerow([g.game_id,rd,p,d,f,c,s])
  for p in range(5):
   assert abs(sum(x['round_gold'] for x in g.round_data if x['bot']==p)+g.game_bonus[p]+g.sell_gold[p]-g.gold[p])<1e-7
   self.score_rows[p].append(g.gold[p]);self.outcome_counts[(p,'zero_ships')]+=g.ships[p]==0
  for x in g.round_data:
   if x['bot']==4:self.round_lengths.append(x['round_draws'])

def run(n=50000):
 OUT6.mkdir(parents=True,exist_ok=True);ps={v:FixedGrant2(p) for v,p in PATHS.items()};before={v:dict(p.q) for v,p in ps.items()};hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [*PATHS.values(),PARENT]}
 learner=Learner6.load(PARENT);learner.q={k:v*.8 for k,v in learner.q.items()};learner.n={k:0 for k in learner.q};learner.training=True;learner.rng=random.Random(160617);learner.save(OUT6/'policy_before.json')
 f=FrozenGrant();c=Collector6(OUT6);blocks=[];credit=[0.]*5;score=[0.]*5;elim=[0]*5;start=time.time();prev=collections.Counter()
 for i in range(n):
  learner.epsilon=[.6,.5,.4,.3,.22,.16,.10,.06,.03,.01][min(9,i*10//n)]
  g=Grant6Game(160_000_000+i,[2,3,4,5,6],[ps[2],ps[3],ps[4],ps[5],learner],f,c,i+1);reward=g.play();learner.finish(reward[4])
  for p in range(5):credit[p]+=reward[p];score[p]+=g.gold[p];elim[p]+=g.ships[p]==0
  if (i+1)%5000==0:
   b={'games':i+1,'win_shares':[v/5000 for v in credit],'mean_gold':[v/5000 for v in score],'zero_ships':elim,'epsilon':learner.epsilon,'seconds':round(time.time()-start,1)};blocks.append(b);print(json.dumps(b),flush=True)
   learner.save(OUT6/f'policy_{i+1}.json');t=c.tune_counts-prev;prev=c.tune_counts.copy();(OUT6/f'tuning_{i+1}.json').write_text(json.dumps([{'round':k[0],'preference':k[1],'choice':k[2],'uses':v} for k,v in t.items()],indent=2));credit=[0.]*5;score=[0.]*5;elim=[0]*5
 c.close();learner.save(OUT6/'grant6_policy.json');r=c.summary();r.update({'names':NAMES6,'blocks':blocks,'learning_updates':sum(learner.n.values()),'lead_behavior':[{'period':k[0],'situation':k[1],'metric':k[2],'count':v} for k,v in c.lead_counts.items()],'zero_ships':[c.outcome_counts[(p,'zero_ships')] for p in range(5)],'source_hashes':hashes,'seed_start':160000000,'parent':str(PARENT),'learning_player':4,'mean_game_rounds':sum(c.game_rounds)/n,'early_ends':sum(x<15 for x in c.game_rounds),'mean_round_draws':sum(c.round_lengths)/len(c.round_lengths)})
 (OUT6/'results.json').write_text(json.dumps(r,indent=2));assert before=={v:p.q for v,p in ps.items()};assert hashes=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [*PATHS.values(),PARENT]};print('DONE',flush=True)
if __name__=='__main__':run()

"""Interactive adapter over the locked revision-28 engine. No bot policy reimplementation."""
import collections, copy, itertools, json, random, threading, time, uuid
from pathlib import Path
from powers.revision28 import Revision28Game
from powers.engine import ExperimentGame, load_opponents, CURSES, TREASURE, HAZARDS
from powers.current import POWER_NAMES
import hashlib
def load_current_bot(power):
    root=Path(__file__).resolve().parent.parent
    slug=power.lower().replace(" ","_")
    bot=json.loads((root/"experiments/power_bots_revision28"/slug/(slug+"_bot.json")).read_text())
    parent=root/"experiments"/Path(bot["parent_policy"]).relative_to(Path(bot["parent_policy"]).parents[1])
    if hashlib.sha256(parent.read_bytes()).hexdigest()!=bot["parent_sha256"]:raise ValueError("Saved bot policy has changed")
    return bot
from powers.multi import MultiPowerGame
ROOT=Path(__file__).resolve().parent
CATALOG=json.loads((ROOT/'static/catalog.json').read_text())
CARD_NAMES={'coin':'Glimmering Coin','crate':'Loot Crate','diamond':'Diamond Necklace','crown':'Golden Crown','coin_curse':'Cursed Coin','idol':'Cursed Idol','surge':'Storm Surge','whirlpool':'Whirlpool','marooned':'Marooned','rudder':'Broken Rudder','escape':'Escape Ship','trick':'Tempest Trick','prophecy':"Parrot’s Prophecy",'wave':'Wild Wave','siren':"Siren’s Song",'key':'Enchanted Key','chest':'Enchanted Chest','echo':'Echo of the Deep','cannon':'Cannon Fire'}
class Stopped(Exception):pass

class FixedSeating:
    """Shuffle once, then reuse the same neighbors for the whole voyage."""
    def __init__(self,rng):self.rng=rng;self.order=None
    def shuffle(self,seats):
        if self.order is None:
            self.rng.shuffle(seats);self.order=tuple(seats)
        else:seats[:]=self.order

class HumanView:
    def __init__(self,original,game,player=0):self.original=original;self.game=game;self.player=player
    def __getattr__(self,key):return getattr(self.original,key)
    def should_harbor(self,p=None):
        if self.game.session.fast():return self.original.should_harbor(p)
        return False

class Session:
    def __init__(self,name,powers,seed=None,auto=False,names=None,humans=None):
        self.names=list(names or [name]+list(powers[1:]));self.human_players=tuple(humans if humans is not None else [0]);self.viewer=self.human_players[0] if self.human_players else 0
        self.id=uuid.uuid4().hex;self.name=self.names[0].strip()[:24] or powers[0];self.condition=threading.Condition();self.request=None;self.answer=None;self.revision=0;self.saved={};self.events=[];self.logs=[];self.stopped=False;self.error=None;self.complete=False;self.skip_through=0;self.auto=auto;self.game=None;self.created=time.time()
        self.seed=seed if seed is not None else random.SystemRandom().randrange(2**31)
        self.powers=powers;self.thread=threading.Thread(target=self.run,daemon=True)
    def start(self):self.thread.start();self.wait_update(0,1);return self
    def fast(self):return self.auto or bool(self.game and self.game.round<=self.skip_through)
    def event(self,kind,**data):self.events.append({'id':len(self.events)+1,'kind':kind,**data})
    def log(self,text,kind='normal'):self.logs.append({'text':text,'kind':kind,'round':getattr(self.game,'round',0)})
    def is_human(self,player):return player in self.human_players
    def player_name(self,player):return self.names[player].strip()[:24] or self.powers[player]
    def ask(self,kind,title,options,detail='',**extra):
        if self.stopped:raise Stopped()
        if self.fast():return options[0]['value']
        self.viewer=extra.get('player',self.viewer)
        with self.condition:
            self.request={'id':uuid.uuid4().hex,'kind':kind,'title':title,'detail':detail,'options':options,**extra};self.answer=None;self.publish()
            while self.answer is None and not self.stopped:self.condition.wait()
            if self.stopped:raise Stopped()
            answer=self.answer;self.request=None;self.answer=None;return answer
    def submit(self,request_id,value,skip=False):
        with self.condition:
            if self.complete:return
            if not self.request or self.request['id']!=request_id:raise ValueError('That choice has already been resolved.')
            valid=[o['value'] for o in self.request['options']]
            if skip:self.skip_through=self.game.round;value=valid[0]
            if value not in valid:raise ValueError('Choose one of the available actions.')
            self.answer=value;self.condition.notify_all()
    def publish(self):
        self.revision+=1
        self.saved={'id':self.id,'revision':self.revision,'request':copy.deepcopy(self.request),'game':self.game.public_state() if self.game else None,'events':self.events[-40:],'log':self.logs[-80:],'complete':self.complete,'error':self.error}
        self.condition.notify_all()
    def wait_update(self,after,timeout=.3):
        with self.condition:
            self.condition.wait_for(lambda:self.revision>after or self.complete,timeout)
            return copy.deepcopy(self.saved or {'id':self.id,'revision':0,'request':None,'game':None,'events':[],'log':[]})
    def run(self):
        try:
            configs=[load_current_bot(p)['config'] for p in self.powers]
            self.game=InteractiveGame(self,self.seed,self.powers,load_opponents(),configs)
            credit=self.game.play();self.complete=True;self.request=None
            self.event('finish',winners=[i for i,r in enumerate(credit) if r>0]);self.log('The voyage is over. Ships, tokens, and final bonuses have been counted.','gold')
        except Stopped:return
        except Exception as e:
            import traceback;traceback.print_exc();self.error=str(e);self.complete=True
        finally:
            with self.condition:self.publish()

class InteractiveGame(Revision28Game):
    def __init__(self,session,*args,**kwargs):
        self.session=session;self.ui_last=None;self.ui_phase='setup';self.ui_held=[];self.queen_inventory=[];self.current_draw=None;self.human_parrot_at={};self.human_tide_placed_at={};self.last_resolution=None;self.harbor_receipts={};self.ui_cause=None;self.cannon_source=None;self.round_seating=None;self.known_exiting=None
        super().__init__(*args,**kwargs)
        self.seat_rng=FixedSeating(self.seat_rng);self.smooth_sailor=None
        self.bot_views={p:self.views[p] for p in self.session.human_players}
        for p,view in self.bot_views.items():self.views[p]=HumanView(view,self,p)
        self.bot_human=self.bot_views.get(0,self.views[0]);self.ui_held=[[] for _ in self.powers]
    def is_human(self,p):return self.session.is_human(p) and not self.session.fast()
    def pname(self,p):return self.session.player_name(p) if self.session.is_human(p) else self.powers[p]
    def public_state(self):
        ready=hasattr(self,'status');players=[]
        for p,power in enumerate(self.powers):
            s=self.states[p];held=copy.deepcopy(self.ui_held[p]) if ready else []
            if power=='Siren Queen':held=[x for x in held if x['effect'] not in ('key','chest')]+copy.deepcopy(self.queen_inventory)
            viewer=self.session.viewer
            players.append({'id':p,'name':self.pname(p),'human':self.session.is_human(p),'power':power,'ships':self.ships[p],'gold':self.gold[p],'tokens':s['tokens'],'protection':s['protection'],'status':self.status[p] if ready else 'active','held':held,'secret':s['secret'] if p==viewer else bool(s['secret']),'targets':sorted(s['targets'] or []) if power=='Blood Sailor' else [],'harborGold':self.harbor_receipts.get(p),'necklaces':self.queen_necklace_total if power=='Siren Queen' else 0,'powerResults':self.power_results(p)})
        viewer=self.session.viewer
        return {'smoothSailor':self.smooth_sailor,'round':self.round,'maxRounds':15,'pot':getattr(self,'chest',0),'draws':getattr(self,'draws',0),'safe':self.safe() if ready else True,'safeRemaining':max(0,3-getattr(self,'draws',0)),'song':getattr(self,'lock_remaining',0),'lockKind':getattr(self,'lock_kind',None),'blocked':self.blocks[viewer] if ready else 0,'players':players,'seating':list(self.round_seating or getattr(self,'seating',list(range(len(players))))),'current':getattr(self,'current',0),'viewer':viewer,'humanPlayers':list(self.session.human_players),'sharedDevice':bool(getattr(self.session,'shared_device',False)),'deckCount':len(getattr(self,'deck',[])),'discard':list(getattr(self,'discard',[])),'known':list(self.known[viewer]) if ready else [],'last':self.ui_last,'phase':self.ui_phase,'totalDraws':self.total_draws,'resolution':self.last_resolution}
    def power_results(self,p):
        stats=self.states[p]['power_stats'];power=self.powers[p]
        # Purchases from Mechanic are spending, not negative income from one's own power.
        gold=self.power_gold[p]-stats['repair_purchase_gold']
        pending=30*self.queen_necklace_total-stats['queen_necklace_gold'] if power=='Siren Queen' else 0
        return {'gold':gold,'pendingGold':pending,
                'livesGained':stats['queen_ship_gained']+stats['blood_ship_gained'],
                'livesSaved':stats['hazards_ignored']+stats['self_repairs'],
                'othersSaved':stats['sold_repairs'],
                'potAdded':stats['cannoneer_extra_pot_gold'],
                'potPenaltyPrevented':stats['pot_penalty_prevented'],
                'rudderGoldSaved':30*stats['rudder_ignored']}
    def insert_tide(self,p):
        card=super().insert_tide(p)
        text=f'{self.pname(p)} places their secret card face down on top of the draw pile.'
        self.session.log(text,'power');self.session.event('tide_placed',player=p,text=text)
        if self.is_human(p):
            self.human_tide_placed_at[p]=self.draws
            self.tide_bot_harbor_window()
        return card
    def tide_bot_harbor_window(self,urgent=False):
        """Let rivals reassess a public human Tide placement before the card is drawn."""
        for p in self.seating:
            if self.session.is_human(p) or self.status[p]!='active' or self.safe() or self.blocks[p]:continue
            leave=self.should_harbor(p)
            if urgent and not leave:
                # Tide placing a mystery card and immediately leaving is a stronger
                # warning, but the normal pot/ship risk calculation still decides.
                leave=self.views[p].risk_harbor(.72)
            if leave:self.harbor(p)
    def should_harbor(self,p):
        if self.is_human(p):return False
        if self.status[p]!='active' or self.safe() or self.blocks[p]:return False
        if self.powers[p]=='Tempest King' and self.states[p]['protection']:return False
        view=self.bot_views.get(p,self.views[p])
        _,_,surge,whirlpool=ExperimentGame.odds(view,0)
        behind=self.gold[p]<max(self.gold)
        # A deficit is not a reason to ignore a depleted Surge supply before the last round.
        terrible=whirlpool>=.06 and (surge==0 or whirlpool>3*surge)
        if behind and self.round<15 and self.chest>=50 and terrible and not self.hazard_immune(p):
            lost=.5 if 'escape' in self.held[p] else 1.
            if self.powers[p]=='Storm Warden' and self.use_warden_token(p):lost=max(0,lost-.5)
            counts=collections.Counter(self.known[p][:1]) if self.known[p] else view.remaining
            n=max(1,sum(counts.values()))
            gain=sum(count*view.expected_card(card,0)[0] for card,count in counts.items())/n
            ship_value=30+22*(16-self.round)/max(1,self.ships[p])
            risk=whirlpool*(self.chest*lost+ship_value)
            if risk>max(4,gain+8)*min(1.3,self.appetite[p]):
                self.states[p]['power_stats']['poor_odds_harbors']+=1
                return True
        if self.powers[p]=='Siren Queen' and behind and self.ships[p]>=4:
            # Extra patience while healthy and trailing, without overriding known traps.
            if self.known[p] and self.dangerous_known_card(p,self.known[p][0],self.next_drawer()):return True
            before=self.appetite[p];self.appetite[p]*=1.65
            try:return ExperimentGame.should_harbor(view,0)
            finally:self.appetite[p]=before
        return view.should_harbor()
    def setup_round(self):
        self.harbor_receipts={};self.last_resolution=None;self.human_tide_placed_at={}
        carried=copy.deepcopy(self.queen_inventory);self.ui_held=[[] for _ in self.powers];self.ui_last=None;self.human_parrot_at={}
        super().setup_round()
        self.round_seating=tuple(self.seating)
        # The user explicitly requires the Queen's unmatched physical cards to stay out.
        # Older simulation keeps markers but recreates the full deck; correct only this adapter.
        queen=self.power_index.get('Siren Queen')
        for item in carried:
            card=item['physical']
            if card not in self.deck:
                tide=self.power_index.get('Tide Watcher')
                if tide is not None and self.states[tide]['secret']==card:
                    self.states[tide]['secret']=self.deck.pop()
                else:raise AssertionError('Persistent Queen card unavailable in new deck')
            else:self.deck.remove(card)
            self.physical_held.append(card)
            if queen is not None:self.held[queen].append(item['effect'])
        self.remaining=collections.Counter(self.deck+self.hidden_cards())
        # Held setup treasures belong face up to Tide Watcher.
        tide=self.power_index.get('Tide Watcher')
        if tide is not None:
            for card in self.held[tide]:
                if card in TREASURE:self.ui_held[tide].append({'physical':card,'effect':card})
        self.current=self.seating[self.round_start_cursor()]
        self.ui_phase='round';self.session.event('round',round=self.round,extraWhirlpool=self.round in (6,11));self.session.log(f'Round {self.round}. The pot opens at {self.chest} gold. Three Calm Waters draws.','round')
        if self.round in (6,11):self.session.log('Another Whirlpool joins the deck. The storm grows stronger.','danger')
        controller=next((p for p in self.seating if self.session.is_human(p)),self.session.viewer)
        self.session.ask('round',f'Round {self.round} — set sail',[{'value':'begin','label':'Start game' if self.round==1 else f'Start round {self.round}'}], 'The fleet regroups. Three safe draws before the storm.',player=controller,private=True)
        if tide is not None and self.session.is_human(tide):
            secret=self.states[tide]['secret']
            setup_treasure=next((card for card in self.held[tide] if card in TREASURE),None)
            card=secret or setup_treasure
            if card:
                title=f'Your secret card · {CARD_NAMES[card]}' if secret else f'Tide Watcher found {CARD_NAMES[card]}'
                detail='Keep it hidden until you choose to place it on top of the deck.' if secret else f'This treasure is revealed and immediately earns {TREASURE[card]} gold.'
                self.session.ask('tide-secret',title,[{'value':'continue','label':'Continue'}],detail,cards=[card],player=tide,private=True)
    def refuse_exit(self,p):
        if self.known_exiting==p:return False
        if self.is_human(p):return False
        return super().refuse_exit(p)
    def memory_reason(self,p):
        if self.is_human(p):return None
        return super().memory_reason(p)
    def power_window(self):
        if self.is_human(self.owner):return
        return super().power_window()
    def parrot_window(self,p):
        if self.is_human(p):return
        return super().parrot_window(p)
    def cannon_token_window(self):
        if self.is_human(self.power_index.get('Cannoneer')):return
        return super().cannon_token_window()
    def tide_window(self,p):
        if self.is_human(p):return
        return super().tide_window(p)
    def windows(self,current):
        self.ui_phase='sailing';self.current=current
        before_tokens=[x['tokens'] for x in self.states]
        # Commit bot decisions, then privately visit every local human who may
        # harbor or activate a power before the next card is drawn.
        super().windows(current)
        self.report_tokens(before_tokens)
        self.known_hazard_exits()
        assert tuple(self.seating)==self.round_seating, 'Seats changed within the round'
        if 'active' not in self.status or self.ended:return
        current=self.ready_drawer(current);self.current=current
        if self.session.fast():return
        while True:
            self.known_hazard_exits()
            if 'active' not in self.status or self.ended:return
            current=self.ready_drawer(current);self.current=current
            humans=[p for p in self.seating if self.session.is_human(p)]
            controller=current if current in humans else next((p for p in humans if self.status[p]=='active'),humans[0])
            restart=False
            if getattr(self.session,'shared_device',False) or getattr(self.session,'networked',False):
                options=[{'value':'stay','label':f'{self.pname(current)} draws','primary':True}]
                if not self.safe():
                    for p in humans:
                        if self.status[p]!='active':continue
                        s=self.states[p];power=self.powers[p]
                        if not self.blocks[p]:options.append({'value':f'harbor:{p}','label':f'{self.pname(p)} Harbor','player':p,'action':'harbor'})
                        if power=='Navigator' and s['tokens'] and not s['used_round']:options.append({'value':f'protect:{p}','label':'Use Navigator token','player':p,'action':'protect'})
                        if power=='Parrot Whisperer' and s['tokens'] and self.human_parrot_at.get(p)!=self.draws:options.append({'value':f'parrot:{p}','label':'Use Parrot token','player':p,'action':'parrot'})
                        if power=='Cannoneer' and s['tokens'] and any(self.status[j]=='active' and self.powers[j]!='Cannoneer' for j in range(self.player_count) if j!=p):options.append({'value':f'fire:{p}','label':'Fire cannon token','player':p,'action':'fire'})
                        if power=='Tide Watcher' and s['secret']:options.append({'value':f'tide:{p}','label':'Place secret card','player':p,'action':'tide'})
                networked=getattr(self.session,'networked',False);kind='online-turn' if networked else 'shared-turn'
                answer=self.session.ask(kind,f'{self.pname(current)} draws next',options,'Every captain may harbor or use an available power before the draw.',drawer=current,player=current if networked else controller,private=False)
                if answer=='stay':break
                action,p_text=answer.split(':',1);p=int(p_text);s=self.states[p]
                tokens_before_action=[x['tokens'] for x in self.states]
                if action=='harbor':self.harbor(p)
                elif action=='protect':s['tokens']-=1;s['protection']=3;s['used_round']=True;s['power_stats']['navigator_tokens']+=1;self.session.log(f'{self.pname(p)} activates three draws of Navigator protection.','safe')
                elif action=='parrot':s['tokens']-=1;self.human_parrot_at[p]=self.draws;self.prophecy(p,token=True)
                elif action=='tide':self.insert_tide(p)
                elif action=='fire':
                    targets=[j for j in range(self.player_count) if j!=p and self.status[j]=='active' and self.powers[j]!='Cannoneer']
                    target=self.session.ask('target','Choose a cannon target',[{'value':j,'label':self.pname(j)} for j in targets],player=p,private=True)
                    self.fire_cannon_token(p,target)
                self.report_tokens(tokens_before_action)
                continue
            for p in humans:
                active=self.status[p]=='active';s=self.states[p];power=self.powers[p]
                needs_decision=active and not self.safe()
                if p!=controller and not needs_decision:continue
                draw_label=('Draw your card' if current==p else
                            f'Ready · {self.pname(current)} draws' if p==controller else
                            'Continue sailing')
                options=[{'value':'stay','label':draw_label,'primary':True}]
                if active and not self.safe() and not self.blocks[p]:
                    options.append({'value':'harbor','label':f'Harbor · collect {self.harbor_value(p):g} gold'})
                if active and not self.safe():
                    if power=='Navigator' and s['tokens'] and not s['used_round']:options.append({'value':'protect','label':'Use Navigator token'})
                    if power=='Parrot Whisperer' and s['tokens'] and self.human_parrot_at.get(p)!=self.draws:options.append({'value':'parrot','label':'Use Parrot token'})
                    if power=='Cannoneer' and s['tokens'] and any(self.status[j]=='active' and self.powers[j]!='Cannoneer' for j in range(self.player_count) if j!=p):options.append({'value':'fire','label':'Fire cannon token'})
                    if power=='Tide Watcher' and s['secret']:options.append({'value':'tide','label':'Place your secret card on top'})
                title='Calm Waters' if self.safe() else ('You are in harbor' if not active else 'Your draw' if current==p else 'Your decision')
                detail='No harboring during safe waters.' if self.safe() else ('Cannon Fire: stay for one more draw before harboring.' if self.cannon_blocks[p] else f'Siren’s Song: {self.blocks[p]} draws before you may harbor.' if self.blocks[p] else ('Stay for the next card, or take your share of the pot.' if active else 'You have left this round.'))
                tokens_before_action=[x['tokens'] for x in self.states]
                answer=self.session.ask('turn',title,options,detail,drawer=current,player=p,private=len(humans)>1)
                if answer=='stay':continue
                if answer=='harbor':
                    self.harbor(p)
                    if p==current:restart=True;break
                elif answer=='protect':s['tokens']-=1;s['protection']=3;s['used_round']=True;s['power_stats']['navigator_tokens']+=1;self.session.log(f'{self.pname(p)} activates three draws of Navigator protection.','safe')
                elif answer=='parrot':s['tokens']-=1;self.human_parrot_at[p]=self.draws;self.prophecy(p,token=True)
                elif answer=='tide':self.insert_tide(p)
                elif answer=='fire':
                    targets=[j for j in range(self.player_count) if j!=p and self.status[j]=='active' and self.powers[j]!='Cannoneer']
                    target=self.session.ask('target','Choose a cannon target',[{'value':j,'label':self.pname(j)} for j in targets],player=p,private=len(humans)>1)
                    self.fire_cannon_token(p,target)
                self.report_tokens(tokens_before_action)
            if restart:continue
            if getattr(self.session,'bot_action_gates',False) and not getattr(self.session,'networked',False) and current not in humans:
                self.session.ask('bot-turn',f'{self.pname(current)} draws next',[{'value':'stay','label':f'Draw for {self.pname(current)}','primary':True}],
                                 'All captains can see the five-second harbor window before the bot acts.',drawer=current,player=current,private=False)
            break
    def harbor(self,p,forced=False):
        before=self.status[p];gold=self.gold[p]
        if self.is_human(p) and self.powers[p] in ('Tide Watcher','Tempest King'):
            # Human choices do not inherit the bot's forced secret-card placement policy.
            result=MultiPowerGame.harbor(self,p,forced)
        else:result=super().harbor(p,forced)
        if self.is_human(p) and before=='active' and self.status[p]=='harbor' and self.powers[p]=='Tide Watcher' and self.human_tide_placed_at.get(p)==self.draws:
            self.tide_bot_harbor_window(urgent=True)
        if before=='active' and self.status[p]=='harbor':
            amount=self.gold[p]-gold;self.harbor_receipts[p]=amount
            cause=self.ui_cause or ('Forced harbor' if forced else 'Voluntary harbor')
            self.session.log(f'{self.pname(p)} — {cause}: leaves the storm and collects {amount:g} gold.','gold')
            self.session.event('harbor',player=p,gold=amount,forced=forced,cause=cause)
            if forced and self.cannon_source is not None:self.session.event('cannon_shot',source=self.cannon_source,target=p,gold=amount)
        return result
    def prophecy(self,p,token=False):
        if not self.is_human(p):return self.bot_prophecy(p,token)
        k=min(2,len(self.deck))
        if not k:return
        cards=list(reversed(self.deck[-k:]));plans=[]
        for perm in itertools.permutations(range(k)):plans.append((list(perm),[]))
        if k==2:plans.extend([([0],[1]),([1],[0])])
        options=[]
        for i,(order,bottom) in enumerate(plans):
            label=' → '.join(CARD_NAMES[cards[j]] for j in order)
            if bottom:label+=f' · bottom {CARD_NAMES[cards[bottom[0]]]}'
            options.append({'value':i,'label':label,'cards':[cards[j] for j in order],'bottom':[cards[j] for j in bottom]})
        chosen=self.session.ask('prophecy','Chart the next two cards',options,'Choose their order. You may send one card to the bottom.',cards=cards,player=p,private=True)
        order,bottom=plans[chosen];del self.deck[-k:];self.deck[0:0]=[cards[j] for j in bottom];self.deck.extend(reversed([cards[j] for j in order]));self.known=[[] for _ in self.ships];self.known[p]=[cards[j] for j in order];self.wants=[False]*self.player_count
        self.session.log(f'You inspect {k} cards, return {len(order)} to the top and place {len(bottom)} on the bottom. Only you know their identities.','power')
        self.session.event('prophecy',player=p,token=token,count=k,bottom=len(bottom))
    def echo_effect(self,p):
        navigator=self.power_index.get('Navigator')
        if navigator is not None and self.is_human(navigator) and self.status[navigator]=='active':
            choices=list(dict.fromkeys(reversed(self.history[-2:]))) or [self.previous or 'echo']
            choice=self.session.ask('echo','Navigate the Echo',[{'value':c,'label':CARD_NAMES.get(c,c),'cards':[c]} for c in choices],f'{self.pname(p)} drew Echo of the Deep. Choose which effect it copies.',player=navigator,private=True)
            self.session.log(f'{self.pname(navigator)} steers Echo into {CARD_NAMES.get(choice,choice)}.','power');return choice
        return super().echo_effect(p)
    def cannon(self,p):
        if not self.is_human(p) or self.powers[p]=='Cannoneer':
            self.cannon_source=p;self.ui_cause=f'Cannon Fire from {self.pname(p)}'
            try:return super().cannon(p)
            finally:self.ui_cause=None;self.cannon_source=None
        targets=[j for j in self.seating if j!=p and self.status[j]=='active' and self.powers[j]!='Cannoneer']
        if not targets:return
        target=self.session.ask('target','Choose a cannon target',[{'value':j,'label':self.pname(j)} for j in targets],'This captain must harbor.',player=p,private=True);self.cannon_source=p;self.ui_cause=f'Cannon Fire from {self.pname(p)}';self.harbor(target,True);self.ui_cause=None;self.cannon_source=None
    def use_warden_token(self,p,ships_before=None):
        ships=self.ships[p] if ships_before is None else ships_before
        if self.states[p]['tokens'] and self.states[p]['tokens']>=ships and not self.is_human(p):return True
        if not self.is_human(p) or ships_before is None:return super().use_warden_token(p,ships_before)
        if not self.states[p]['tokens'] or self.chest<=0:return False
        return self.session.ask('insurance','Save half your treasure?',[{'value':True,'label':f'Spend Warden token · save {self.chest/2:g}'},{'value':False,'label':'Save the token'}],'The token saves gold, not a ship.',player=p,private=True)
    def sink(self,p,maroon=False):
        # Same revision-28 resolution, with human choices at repair / plunder hooks.
        if self.status[p]!='active':return
        power=self.powers[p];state=self.states[p]
        if self.hazard_immune(p,maroon):
            state['power_stats']['hazards_ignored']+=1;self.session.event('blocked',player=p,category='hazard',reason=self.powers[p]+' protection');self.session.log(f'{self.pname(p)} is protected from {"Marooned" if maroon else "the Whirlpool"}.','safe');return
        repair=False;mechanic=self.power_index.get('Mechanic')
        if mechanic is not None and self.states[mechanic]['tokens']:
            s=self.states[mechanic];c=self.configs[mechanic]
            if p==mechanic:
                repair=self.ships[p]<=c['repair_self_max_ships']
                if self.is_human(p):repair=self.session.ask('repair','Repair your ship?',[{'value':True,'label':'Spend a repair token'},{'value':False,'label':'Lose one ship'}],'You still leave this round.',player=p,private=True)
            elif self.repair_sales:
                mode=c['sell'];offer=mode=='always' or(mode=='balanced' and(self.ships[mechanic]>=3 or s['tokens']>1))or(mode=='reserve_two' and s['tokens']>2)
                if self.is_human(mechanic):offer=self.session.ask('repair',f'Offer {self.pname(p)} a repair?',[{'value':True,'label':f'Offer for {self.repair_price} gold'},{'value':False,'label':'Keep the token'}],player=mechanic,private=True)
                value=30+60*(15-self.round)/max(1,self.ships[p]);repair=offer and self.gold[p]>=self.repair_price and value>=self.repair_price
                if self.is_human(p) and offer and self.gold[p]>=self.repair_price:repair=self.session.ask('repair','Buy a repair from Mechanic?',[{'value':True,'label':f'Pay {self.repair_price} gold'},{'value':False,'label':'Decline repair'}],'Save one ship. You still leave this round.',player=p,private=True)
                if offer:s['power_stats']['repair_offers']+=1
                if repair:self.award(mechanic,self.repair_price,'repair_sale');self.award(p,-self.repair_price,'repair_purchase')
            if repair:s['tokens']-=1;s['power_stats']['self_repairs' if p==mechanic else 'sold_repairs']+=1
        old=self.ships[p];gold=self.gold[p];ExperimentGame.sink(self,p,maroon)
        if maroon:self.gold[p]-=self.chest/2
        if repair:self.ships[p]=old
        if power=='Storm Warden' and not(maroon and 'escape' in self.held[p]) and self.use_warden_token(p,ships_before=old):state['tokens']-=1;self.award(p,self.chest/2,'warden_insurance');state['power_stats']['warden_insured_chest_total']+=self.chest
        elif power=='Storm Warden':state['power_stats']['warden_uninsured_sinkings']+=1
        self.session.log(f'{self.pname(p)} {"is marooned" if maroon else "sinks"}. {"Ship repaired." if repair else "One ship lost."} {self.gold[p]-gold:g} gold recovered.','danger')
        self.session.event('sink',player=p,maroon=maroon,repaired=repair)
        blood=self.power_index.get('Blood Sailor')
        if blood is not None:
            s=self.states[blood]
            if p in s['targets']:
                self.award(blood,self.blood_payment,'blood_sink')
                if self.ships[p]==0 and p not in s['rewarded_targets']:s['rewarded_targets'].add(p);self.ships[blood]+=1;s['power_stats']['blood_ship_gained']+=1
        admiral=self.power_index.get('Undead Admiral')
        if admiral is not None and p!=admiral:
            s=self.states[admiral];c=self.configs[admiral]
            available=s['tokens'] and s['plunders_used']<1
            use=available and(self.chest>=c['plunder_min_gold']or(self.round>=c['plunder_late']and self.chest>100))
            if self.is_human(admiral) and available:use=self.session.ask('plunder',f'Plunder {self.pname(p)}?',[{'value':True,'label':f'Spend token · gain {self.plunder_value(self.chest):g} gold'},{'value':False,'label':'Keep the token'}],'One plunder token per round. You may plunder after harboring.',player=admiral,private=True)
            if use:s['tokens']-=1;s['plunders_used']+=1;self.award(admiral,self.plunder_value(self.chest),'plunder')
    def draw(self,p):
        self.ui_phase='resolving';self.draw_log_start=len(self.session.logs);self.draw_pot_before=self.chest;self.draw_tokens_before=[x['tokens'] for x in self.states];self.draw_ships_before=list(self.ships);before=[len(x) for x in self.held];before_physical=len(self.physical_held)
        if self.deck:
            self.ui_last={'card':self.deck[-1],'effect':self.previous if self.deck[-1]=='echo' else self.deck[-1],'player':p,'safe':self.safe(),'draw':self.total_draws+1}
        self.before_hold=before;self.before_physical=before_physical
        if self.deck:
            self.session.event('reveal',**self.ui_last,potBefore=self.chest)
            self.session.log(f'{self.pname(p)} draws {CARD_NAMES[self.deck[-1]]}{" in Calm Waters" if self.safe() else ""}.','safe' if self.safe() else 'normal')
        self.ui_cause='Broken Rudder' if self.ui_last and not self.ui_last['safe'] and self.ui_last['effect']=='rudder' else None
        try:super().draw(p)
        finally:self.ui_cause=None
    def resolved_card(self,p,card,effect,safe):
        # Record physical collections without exposing any private deck contents.
        if len(self.physical_held)>self.before_physical:
            for j in range(self.player_count):
                for e in self.held[j][self.before_hold[j]:]:
                    item={'physical':card,'effect':e,'draw':self.total_draws};self.ui_held[j].append(item)
                    self.session.log(f'{self.pname(j)} keeps {CARD_NAMES.get(e,e)} face up beside their power.','power')
                    if self.powers[j]=='Siren Queen' and e in ('key','chest'):self.queen_inventory.append(item)
        while any(x['effect']=='key' for x in self.queen_inventory) and any(x['effect']=='chest' for x in self.queen_inventory):
            for effect_name in ('key','chest'):self.queen_inventory.remove(next(x for x in self.queen_inventory if x['effect']==effect_name))
        super().resolved_card(p,card,effect,safe)
        self.ui_last={'card':card,'effect':effect,'player':p,'safe':safe,'draw':self.total_draws}
        if safe:
            value=TREASURE.get(card,50 if card in HAZARDS else 0 if card in CURSES else 10)
            self.session.log(f'Calm Waters: +{value} gold. No normal card effect or power activates.','safe')
        else:
            if card=='echo':self.session.log(f'Echo copies {CARD_NAMES.get(effect,effect)}.','power')
            delta=self.chest-self.draw_pot_before
            if effect in TREASURE or effect in CURSES or effect in ('surge','trick'):
                self.session.log(f'{CARD_NAMES[effect]}: pot {self.draw_pot_before:g} → {self.chest:g} gold ({delta:+g}).','gold' if delta>=0 else 'danger')
            if effect in CURSES and p==self.power_index.get('Cursed Captain'):
                prevented=min(self.draw_pot_before,CURSES[effect]+(10 if self.admiral_curse_active() else 0))
                self.states[p]['power_stats']['pot_penalty_prevented']+=prevented
                self.session.event('blocked',player=p,category='curse',reason='Cursed Captain immunity')
                self.session.log('Cursed Captain drew this curse personally: the pot penalty is prevented.','power')
            if effect=='siren':self.session.log('Siren’s Song locks the fleet in for 4 draws. Siren Queen can still harbor.','danger')
            if effect in ('key','chest','wave'):self.session.log('The next draw is safe. No harboring during that safe draw.','safe')
            if effect=='wave':self.session.log(f'{self.pname(p)} earns 10 gold. Discarded cards shuffle back into the deck; held cards stay out.','gold');self.session.event('shuffle')
            if effect=='trick':self.session.log(f'{self.pname(p)} keeps 20 gold from Tempest Trick.','gold')
            if effect=='escape':self.session.log(f'{self.pname(p)} has an Escape Ship: half the pot if sunk, +20 gold if harbored.','power')
            if effect=='prophecy':self.session.log(f'{self.pname(p)} privately charts the next cards.','power')
            if effect=='rudder' and self.powers[p]=='Mechanic':self.session.event('blocked',player=p,category='event',reason='Mechanic immunity');self.session.log('Mechanic ignores Broken Rudder.','safe')
            elif effect=='rudder':self.session.log(f'{self.pname(p)} pays the 30-gold Broken Rudder penalty.','danger')
            if effect=='cannon' and not any(self.status[j]=='active' and j!=p and self.powers[j]!='Cannoneer' for j in range(self.player_count)):
                if not any('Cannon Fire from' in x['text'] for x in self.session.logs[self.draw_log_start:]):self.session.log('No eligible cannon target remains. No one is forced out.','normal')
        for j,ships in enumerate(self.ships):
            if ships>self.draw_ships_before[j]:self.session.log(f'{self.pname(j)} gains {ships-self.draw_ships_before[j]} ship. Now at {ships} ships.','safe')
        if not safe and effect=='surge':
            king=self.power_index.get('Tempest King')
            if king is not None and self.states[king]['protection']:self.session.log('Tempest King is protected against hazards for the next two draws.','safe')
        self.report_tokens(self.draw_tokens_before)
        self.last_resolution={'card':card,'effect':effect,'safe':safe,'player':p,'before':self.draw_pot_before,'after':self.chest,'lines':[x['text'] for x in self.session.logs[self.draw_log_start:]],'draw':self.total_draws}
        self.session.event('draw',**self.ui_last,pot=self.chest,summary=self.last_resolution)
        self.ui_phase='sailing'
    def dangerous_known_card(self,p,card,drawer):
        effect=(self.previous or 'echo') if card=='echo' else card
        if effect=='whirlpool':return not self.hazard_immune(p,False)
        if effect=='marooned':return drawer==p and not self.hazard_immune(p,True)
        return effect=='rudder' and drawer==p and self.powers[p]!='Mechanic'
    def known_hazard_exits(self):
        # Later departures can redirect a remembered trap to its owner. Recheck
        # until stable, before publishing the committed next-draw request.
        if self.safe():return
        for _ in range(self.player_count):
            changed=False;drawer=self.next_drawer()
            for p in self.seating:
                if self.is_human(p):continue
                if self.status[p]!='active' or self.blocks[p] or not self.known[p]:continue
                if self.powers[p]=='Tempest King' and self.states[p]['protection']:continue
                if self.dangerous_known_card(p,self.known[p][0],drawer):
                    before=self.status[p]
                    # A private known hazard overrides aggressive bot preferences.
                    self.known_exiting=p
                    try:MultiPowerGame.harbor(self,p)
                    finally:self.known_exiting=None
                    if before!=self.status[p]:
                        self.harbor_receipts[p]=self.harbor_gold[p]
                        text=f'{self.pname(p)} remembers danger on top and harbors for {self.harbor_gold[p]:g} gold.'
                        self.session.log(text,'gold');self.session.event('harbor',player=p,gold=self.harbor_gold[p],forced=False,cause='Remembered danger')
                        changed=True;drawer=self.next_drawer()
            if not changed:break
    def parrot_rearrange(self,p,token=False):
        return self.bot_prophecy(p,token)
    def bot_prophecy(self,p,token=False):
        k=min(2,len(self.deck))
        if not k:return
        cards=list(reversed(self.deck[-k:]));saved=self.views[p]
        if self.session.is_human(p):self.views[p]=self.bot_views[p]
        try:
            if self.powers[p]=='Parrot Whisperer':super().parrot_rearrange(p,token)
            else:super().prophecy(p)
        finally:self.views[p]=saved
        order=list(self.known[p]);bottom_count=k-len(order)
        # Do not lay a known unavoidable trap when a safe alternative was peeked.
        if token:drawer=self.next_drawer()
        else:
            at=self.seating.index(p)
            drawer=next((self.seating[(at+i)%self.player_count] for i in range(1,self.player_count+1) if self.status[self.seating[(at+i)%self.player_count]]=='active'),p)
        if order and self.dangerous_known_card(p,order[0],drawer):
            safe_cards=[c for c in cards if not self.dangerous_known_card(p,c,drawer)]
            if safe_cards:
                keep=max(safe_cards,key=lambda c:(c=='surge',TREASURE.get(c,0),c not in CURSES))
                # Parent just put its bottom selection at index zero, and its
                # top selection at the tail. Restore only the two peeked cards.
                del self.deck[-len(order):]
                if bottom_count:del self.deck[:bottom_count]
                rest=list(cards);rest.remove(keep);self.deck[0:0]=rest;self.deck.append(keep)
                order=[keep];bottom_count=len(rest);self.known=[[] for _ in self.ships];self.known[p]=order;self.wants=[False]*self.player_count
        self.session.log(f'{self.pname(p)} {"uses a Parrot token to inspect" if token else "uses Parrot’s Prophecy to inspect"} {k} cards; returns {len(order)} on top and places {bottom_count} on the bottom.','power')
        self.session.event('prophecy',player=p,token=token,count=k,bottom=bottom_count)
    def ready_drawer(self,current):
        at=self.seating.index(current)
        for offset in range(self.player_count):
            p=self.seating[(at+offset)%self.player_count]
            if self.status[p]=='active':return p
        return current
    def report_tokens(self,before):
        for p,s in enumerate(self.states):
            delta=s['tokens']-before[p]
            if delta:
                purpose={'Navigator':'protect against hazards for three draws','Parrot Whisperer':'inspect and rearrange the next two cards','Cannoneer':'force another captain to harbor','Storm Warden':'recover half the pot','Mechanic':'repair a sinking ship','Undead Admiral':'plunder another captain’s sinking ship'}.get(self.powers[p],'activate their power')
                text=f'{self.pname(p)} '+(f'gains {delta} token(s)' if delta>0 else f'spends {abs(delta)} token(s) to {purpose}')+f'. {s["tokens"]} remaining.'
                self.session.log(text,'power');self.session.event('token',player=p,delta=delta,text=text)
    def fire_cannon_token(self,p,target):
        self.cannon_source=p;self.ui_cause=f'Cannon token from {self.pname(p)}'
        try:return super().fire_cannon_token(p,target)
        finally:self.ui_cause=None;self.cannon_source=None
    def award(self,p,amount,reason):
        super().award(p,amount,reason)
        labels={'repair_sale':'repair sale','repair_purchase':'repair purchase','blood_sink':'Blood Sailor target sinking','warden_insurance':'Warden protection','plunder':'plunder','tide_treasure':'setup treasure','cursed_captain':'collected curse'}
        if reason in labels:self.session.log(f'{self.pname(p)}: {amount:+g} gold ({labels[reason]}).','gold' if amount>=0 else 'normal')
    def finish_round_rewards(self):
        super().finish_round_rewards();self.ui_phase='round-end'
        self.session.log(f'Round {self.round} ends. The fleet returns to harbor.','round')
        self.session.ask('round-end',f'Round {self.round} complete',[{'value':'continue','label':'See final scores' if self.round==15 or self.ended else 'Prepare the next round'}],'Held round cards return to the deck. Queen’s unmatched enchanted cards remain with her.')

    def round_start_cursor(self):
        return 0

    def play(self):
        while self.round < 15 and not self.ended:
            self.setup_round(); cursor = self.round_start_cursor()
            while 'active' in self.status and not self.ended:
                while self.status[self.seating[cursor]] != 'active': cursor = (cursor+1)%self.player_count
                self.current = self.seating[cursor]; self.windows(self.current)
                if 'active' not in self.status: break
                if self.status[self.current] == 'active': self.draw(self.current)
                cursor = (self.seating.index(self.current)+1)%self.player_count
                if self.draws > 10000: raise RuntimeError('Round safety bound')
            self.finish_round_rewards()
            assert collections.Counter(self.deck+self.discard+self.physical_held+self.hidden_cards()) == self.initial_counts
            for p in range(self.player_count):
                self.round_data.append({'game':self.game_id,'round':self.round,'bot':p,'seat':self.seating.index(p),
                    'round_gold':self.gold[p]-self.round_begin[p]-self.round_bonus[p], 'harbor_gold':self.harbor_gold[p],
                    'additional_gold':self.gold[p]-self.round_begin[p]-self.round_bonus[p]-self.harbor_gold[p],
                    'ships_start':self.round_ships[p], 'ships_end':self.ships[p], 'status':self.status[p],
                    'round_draws':self.draws,'own_draws':self.own_draws[p]})
        if not self.ended:
            most = max(self.ships)
            if self.ships.count(most) == 1:
                p = self.ships.index(most); self.gold[p] += 100; self.game_bonus[p] += 100
                self.smooth_sailor={'player':p,'ships':most,'gold':100}
                self.session.log(f'{self.pname(p)} wins Smooth Sailor: {most} ships, +100 gold.','gold')
            else:self.smooth_sailor={'player':None,'ships':most,'gold':0}
            self.session.event('smooth_sailor',**self.smooth_sailor)
        for p,power in enumerate(self.powers):
            self.sell_gold[p] = self.ships[p]*(60 if power == 'Merchant' else 30)
            self.gold[p] += self.sell_gold[p]
            if power == 'Merchant':
                premium = self.ships[p]*30
                self.power_gold[p] += premium; self.states[p]['power_stats']['merchant_ship_premium_gold'] += premium
            token_value = {'Mechanic':30,'Parrot Whisperer':10,'Undead Admiral':10,'Navigator':10,'Cannoneer':10,'Tide Watcher':5}.get(power,0)
            if token_value:
                amount = self.states[p]['tokens']*token_value; self.gold[p] += amount; self.game_bonus[p] += amount
                self.power_gold[p] += amount; self.states[p]['power_stats']['token_sale_gold'] += amount
            if power == 'Siren Queen':
                amount = 30*self.queen_necklace_total
                self.gold[p] += amount; self.game_bonus[p] += amount; self.power_gold[p] += amount
                self.states[p]['power_stats']['queen_necklace_gold'] += amount
            assert abs(sum(r['round_gold'] for r in self.round_data if r['bot'] == p)+self.game_bonus[p]+self.sell_gold[p]-self.gold[p]) < 1e-6
        best = max(self.gold); winners = [p for p,x in enumerate(self.gold) if abs(x-best) < 1e-8]
        return [1/len(winners) if p in winners else 0. for p in range(self.player_count)]

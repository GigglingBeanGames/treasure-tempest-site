"""Treasure Tempest local play client."""

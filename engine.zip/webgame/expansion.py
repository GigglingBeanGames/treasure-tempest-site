"""Human/browser presentation over the locked expansion v6 simulator.

Historical simulation classes and saved strategies are unchanged. UI choices use
the same physical deck, private knowledge, and reward hooks as the trained bots.
"""
import collections
from powers.expansion_v6_20260926 import ExpansionGameV6
from powers.expansion_20260926 import defaults, TREASURE, CARD_NAMES
from webgame.game import InteractiveGame, load_current_bot as load_original_bot
from powers.current import POWER_NAMES as ORIGINAL_POWERS

POWER_NAMES=tuple(ORIGINAL_POWERS)+('Sea Witch','Ghost Captain','Marooned Monarch','Storm Swindler')
def load_current_bot(power):
    return load_original_bot(power) if power in ORIGINAL_POWERS else {'config':defaults(power)}

class BrowserExpansionGame(ExpansionGameV6):
    def setup_round(self):
        self.public_spyglass_treasure=False
        return super().setup_round()

    def round_start_cursor(self):
        if getattr(self,'starter_round',None)!=self.round:
            last=getattr(self,'round_starter',None)
            start=0 if last is None else (self.seating.index(last)+1)%self.player_count
            cursor=next(((start+i)%self.player_count for i in range(self.player_count)
                         if self.status[self.seating[(start+i)%self.player_count]]=='active'),start)
            self.round_starter=self.seating[cursor];self.starter_round=self.round
            self.session.log(f'{self.pname(self.round_starter)} goes first this round. The starting turn passes left each round; seats stay fixed.','round')
        return self.seating.index(self.round_starter)

    def should_harbor(self,p):
        if p==0 and not self.session.fast():return False
        if getattr(self,'public_spyglass_treasure',False):return False
        return super().should_harbor(p)

    def draw(self,p):
        # This public promise expires when the prepared top card is drawn.
        self.public_spyglass_treasure=False
        self.ui_draw_event_start=len(self.session.events)
        return super().draw(p)

    def insert_tide(self,p):
        self.public_spyglass_treasure=False
        return super().insert_tide(p)

    def bot_prophecy(self,p,token=False):
        self.public_spyglass_treasure=False
        return super().bot_prophecy(p,token)

    def cannon(self,p):
        before=list(self.status)
        result=super().cannon(p)
        if any(old=='active' and self.status[j]=='harbor' for j,old in enumerate(before)):
            for j in range(self.player_count):
                if self.status[j]=='active':self.cannon_blocks[j]=max(self.cannon_blocks[j],1)
            self.sync_blocks()
            self.session.log('Cannon Fire forces the remaining captains to stay for one more draw. Cannon tokens do not cause this restriction.','normal')
        return result

    def harbor(self,p,forced=False):
        if not forced and self.cannon_blocks[p]:return

        # Cover secondary strategy exits as well as should_harbor. Forced
        # Cannon/Rudder exits still resolve; humans keep their own choice.
        if not forced and getattr(self,'public_spyglass_treasure',False) and (p!=0 or self.session.fast()):return
        # Song protection is a bot preference, not a restriction on human choice.
        if p==0 and not self.session.fast() and self.powers[p]=='Siren Queen':
            return InteractiveGame.harbor(self,p,forced)
        return super().harbor(p,forced)

    def public_state(self):
        state=super().public_state()
        state['expansion']=True
        state['cannonBlocked']=self.cannon_blocks[0] if self.cannon_blocks else 0
        state['roundStarter']=getattr(self,'round_starter',state['current'])
        state['deckComposition']=dict(self.initial_counts) if hasattr(self,'initial_counts') else {}
        for player in state['players']:
            p=player['id'];power=player['power']
            # No Queen carry-over in the expansion: all current-round cards stay
            # face up, including completed pairs, until round settlement.
            player['held']=[dict(item) for item in self.ui_held[p]]
            player['necklaces']=0
            player['heartTokens']=self.witch_hearts if power=='Sea Witch' else 0
            player['hexTokens']=self.hexes if power=='Sea Witch' else 0
            player['songProtected']=power=='Siren Queen' and self.queen_safe(p) and player['status']=='active'
            player['immortal']=power=='Ghost Captain'
            if power=='Siren Queen':player['pairs']=min(self.queen_markers['key'],self.queen_markers['chest'])
        # Public draw-order guide: real discards plus placeholders for held cards.
        # Never include the Tide Watcher's unrevealed secret card.
        held=[dict(c,owner=player['id'],ghost=True) for player in state['players'] for c in player['held'] if 'draw' in c]
        held_draws={c.get('draw') for c in held if c.get('draw') is not None}
        draws=[e for e in self.session.events if e['kind']=='draw' and e.get('draw') not in held_draws]
        cursor=len(draws)-1; gallery=[]
        for card in reversed(state['discard']):
            match=next((i for i in range(cursor,-1,-1) if draws[i].get('card')==card),None)
            entry={'physical':card,'effect':card,'ghost':False,'draw':-1}
            if match is not None:
                entry['draw']=draws[match]['draw'];cursor=match-1
            gallery.append(entry)
        state['discardView']=sorted(list(reversed(gallery))+held,key=lambda c:c.get('draw',-1))
        return state

    def power_results(self,p):
        result=super().power_results(p);stats=self.states[p]['power_stats'];power=self.powers[p]
        result['pendingGold']=0
        result['goldSaved']=stats['ui_gold_saved']
        result['livesSaved']+=stats['ghost_ship_losses_prevented']+stats['heart_token_ship_saves']
        if power=='Sea Witch':
            settled=stats['hex_endgame_gold']
            result['pendingGold']=max(0,10*self.hexes-settled)
            result['hexPenalty']=10*self.hexes
            result['pendingLabel']='Hex gold at game end'
        if power=='Storm Swindler':
            result['pendingGold']=self.swindler_treasure_pending/2
            result['pendingLabel']='Collected treasure at round end'
        return result

    def sink(self,p,maroon=False):
        old_ships=self.ships[p];before=self.status[p];hearts=self.witch_hearts
        pot_before=self.chest;ignored_before=self.states[p]['power_stats']['hazards_ignored']
        stats_before=[dict(s['power_stats']) for s in self.states]
        decline=False
        if p==0 and self.powers[p]=='Sea Witch' and hearts and 'heart' not in self.held[p] and before=='active' and not self.hazard_immune(p,maroon) and not self.session.fast():
            use=self.session.ask('heart','Save your ship with a Heart token?',[
                {'value':True,'label':'Spend one Heart token · save your ship'},
                {'value':False,'label':'Keep the token · lose one ship'}],
                'You still leave the round. This token saves a ship, not gold.')
            decline=not use
            if decline:self.witch_hearts=0
        start=len(self.session.logs)
        result=super().sink(p,maroon)
        if before=='active' and self.status[p]=='active' and self.states[p]['power_stats']['hazards_ignored']>ignored_before:
            self.states[p]['power_stats']['ui_gold_saved']+=pot_before
        if decline:self.witch_hearts=hearts
        if before=='active' and self.status[p]=='sunk' and self.ships[p]==old_ships:
            label=('Your ghost ship cannot be destroyed.' if self.powers[p]=='Ghost Captain' else
                   'A Heart token saves the ship.' if self.witch_hearts<hearts else
                   'Heart of the Sea saves the ship.' if 'heart' not in self.held[p] and any(x['effect']=='heart' for x in self.ui_held[p]) else 'The ship is repaired.')
            for entry in self.session.logs[start:]:
                if 'One ship lost.' in entry['text']:entry['text']=entry['text'].replace('One ship lost.',label)
            self.session.log(f'{self.pname(p)} keeps their ship but is out of this round.','power')
        for j,state in enumerate(self.states):
            stats=state['power_stats'];previous=stats_before[j]
            if stats['sold_repairs']>previous.get('sold_repairs',0):
                self.session.log(f'{self.pname(j)} spends a repair token on {self.pname(p)} for {self.repair_price:g} gold; {self.pname(p)} saves one ship but leaves the round.','power')
            if stats['self_repairs']>previous.get('self_repairs',0):
                self.session.log(f'{self.pname(j)} spends a repair token to save their own ship, then leaves the round.','power')
            if stats['plunder_gold']>previous.get('plunder_gold',0):
                gain=stats['plunder_gold']-previous.get('plunder_gold',0)
                self.session.log(f'{self.pname(j)} spends a plunder token on {self.pname(p)} and gains {gain:g} gold.','power')
        if self.witch_hearts<hearts:
            text=f'{self.pname(p)} spends a Heart token to save a ship. {self.witch_hearts} remain.'
            self.session.log(text,'power');self.session.event('token',player=p,delta=-1,text=text)
        return result

    def prophecy(self,p,token=False):
        self.public_spyglass_treasure=False
        if p!=0 or self.session.fast():return super().prophecy(p,token)
        length=len(self.deck);k=min(2,length)
        result=super().prophecy(p,token)
        bottom=k-len(self.known[p])
        self.bottom_memory=[{i+bottom:c for i,c in m.items() if i<length-k} for m in self.bottom_memory]
        if bottom:self.bottom_memory[p].update({i:self.deck[i] for i in range(bottom)})
        return result

    def spyglass(self,p):
        if p!=0 or self.session.fast():
            before=self.states[p]['power_stats']['spyglass_treasures_lifted']
            result=super().spyglass(p)
            self.public_spyglass_treasure=self.states[p]['power_stats']['spyglass_treasures_lifted']>before
            outcome='one treasure moves to the top' if self.public_spyglass_treasure else 'no treasure found'
            self.session.log(f'{self.pname(p)} uses Spyglass: privately inspects up to ten bottom cards; {outcome}. The remaining inspected cards return to the bottom.','power')
            self.session.event('spyglass',player=p)
            return result
        k=min(10,len(self.deck));cards=list(self.deck[:k]);treasures=[i for i,c in enumerate(cards) if c in TREASURE]
        chosen=None
        if treasures:
            index=self.session.ask('spyglass','Spyglass · bring one treasure to the top',[
                {'value':i,'label':f'{CARD_NAMES[cards[i]]} · {TREASURE[cards[i]]} gold','cards':[cards[i]]} for i in treasures],
                'These are the bottom cards. You must choose one treasure if any are present. Only you see this information.',cards=cards)
            chosen=cards.pop(index)
        elif cards:
            self.session.ask('spyglass','Spyglass · no treasure found',[{'value':'next','label':'Arrange the bottom cards'}],
                'No card moves to the top. You may arrange all these cards on the bottom.',cards=cards)
        order=[]
        while len(cards)>1:
            index=self.session.ask('spyglass-order','Arrange the bottom · next to be reached',[
                {'value':i,'label':CARD_NAMES[c],'cards':[c]} for i,c in enumerate(cards)],
                'Choose the order these cards will be drawn after the rest of the deck. The last chosen will be deepest.',cards=cards)
            order.append(cards.pop(index))
        order+=cards;bottom=list(reversed(order));del self.deck[:k];self.deck[:0]=bottom
        if chosen:self.deck.append(chosen)
        shift=k-len(bottom)
        self.bottom_memory=[{i-shift:c for i,c in m.items() if i>=k} for m in self.bottom_memory]
        self.bottom_memory[p].update(dict(enumerate(bottom)))
        self.known=[[] for _ in self.ships]
        if chosen:self.known[p]=[chosen]
        self.public_spyglass_treasure=bool(chosen)
        stats=self.states[p]['power_stats'];stats['spyglass_uses']+=1;stats['spyglass_treasures_lifted']+=bool(chosen)
        self.session.log(f'You use Spyglass: {"one treasure moves to the top" if chosen else "no treasure found"}; {len(bottom)} cards return to the bottom in your chosen order.','power')
        self.session.event('spyglass',player=p)

    def resolved_card(self,p,card,effect,safe):
        if not safe:
            if effect=='heart':self.session.log(f'{self.pname(p)} receives Heart of the Sea: save a ship if sunk, or gain 10 gold if harbored.','power')
            if effect in ('coin_curse','idol','spoils') and 'Sea Witch' in self.power_index:
                witch=self.power_index['Sea Witch']
                if self.status[witch]=='active':self.session.log(f'{self.pname(witch)} gains a Hex token: {self.hexes} total. Each is +10 gold to the Witch and −10 to every rival at game end.','power')
            if effect=='heart' and 'Sea Witch' in self.power_index:
                witch=self.power_index['Sea Witch'];self.session.log(f'{self.pname(witch)} receives a Heart token (maximum 3 held).','power')
        result=super().resolved_card(p,card,effect,safe)
        if not safe and effect=='whirlpool':
            sinks=[dict(e) for e in self.session.events[getattr(self,'ui_draw_event_start',0):] if e['kind']=='sink' and not e.get('maroon')]
            self.session.event('whirlpool_resolved',draw=self.total_draws,sinks=sinks)
        return result

    def award(self,p,amount,reason):
        result=super().award(p,amount,reason)
        label={'monarch_marooned':'another captain marooned','swindler_treasure':'first treasure collected','ghost_sinking_bonus':'Ghost Captain sinking reward'}.get(reason)
        if label:
            actual=60 if reason=='monarch_marooned' else amount/2 if reason=='swindler_treasure' else amount
            self.session.log(f'{self.pname(p)} earns {actual:g} gold: {label}.','gold')
        return result

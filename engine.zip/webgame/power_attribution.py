"""Presentation-only power attribution; never changes payouts or bot decisions."""
import collections
from simulator import TREASURE, CURSES, HAZARDS

class SourcedCard(str):
    def __new__(cls,value,owner=None,origin='tide'):
        obj=super().__new__(cls,value);obj.owner=owner;obj.origin=origin;obj.used=False;return obj

class PowerAttribution:
    def __init__(self,*args,**kwargs):
        self.attribution=[];self.credit_context=None
        super().__init__(*args,**kwargs)
        self.attribution=[collections.Counter() for _ in self.powers]
        self._reset_credit()

    def _reset_credit(self):
        self.shadow_pots={};self.credit_context=None;self.tide_equipment={};self.tide_safe=None

    def setup_round(self):
        self._reset_credit()
        return super().setup_round()

    def _harm(self,owner,gold=0,lives=0):
        n=max(1,self.player_count-1)
        self.attribution[owner]['goldTaken']+=gold/n
        self.attribution[owner]['livesTaken']+=lives/n

    def _lost_fraction(self,p,maroon=False):
        return max(0,1-(.5 if maroon else 0)-(.5 if 'escape' in self.held[p] else 0))

    def insert_tide(self,p):
        result=super().insert_tide(p)
        if self.deck:self.deck[-1]=SourcedCard(self.deck[-1],p)
        return result

    def draw(self,p):
        card=self.deck[-1] if self.deck else None
        tagged=isinstance(card,SourcedCard) and not card.used
        self.credit_context={'drawer':p,'before':self.chest,'active':list(self.status),
            'owner':card.owner if tagged else None,'origin':card.origin if tagged else None,
            'safe':self.safe(),'equipment':list(self.held[p]),'updated':False,
            'stolen':self.states[self.power_index['Storm Swindler']]['stolen_treasure'] if 'Storm Swindler' in self.power_index else 1,
            'safe_owner':self.tide_safe,'immune':[(self.hazard_immune(j),self.hazard_immune(j,True)) for j in range(self.player_count)]}
        if tagged:card.used=True
        self.tide_safe=None
        try:return super().draw(p)
        finally:self.credit_context=None

    def _credit_pot(self,effect=None):
        c=self.credit_context
        if not c or c['updated']:return
        c['updated']=True;effect=effect or self.resolving
        before=c['before'];p=c['drawer'];owner=c['owner'];safe=c['safe']
        intercepted=not safe and effect in TREASURE and c['stolen']==0
        doubled=not safe and effect in TREASURE and not intercepted and self.powers[p]=='Cannoneer' and c['active'].count('active')==1
        source=owner if owner is not None and (effect=='surge' or c['origin']=='spyglass' and effect in TREASURE) and not safe and not intercepted else p if doubled else None
        if source is not None:self.shadow_pots.setdefault(source,before)
        for who,shadow in list(self.shadow_pots.items()):
            if safe:
                physical=self.ui_last['card'] if self.ui_last else effect
                shadow+=TREASURE.get(physical,50 if physical in HAZARDS else 0 if physical in CURSES else 10)
            elif effect in TREASURE and not intercepted:
                addition=TREASURE[effect]*(2 if doubled else 1)
                if who==source:addition-=TREASURE[effect]
                shadow+=addition
            elif effect=='surge':
                if who!=source:shadow=shadow*2 if shadow else 100
            elif effect in CURSES:
                captain=self.power_index.get('Cursed Captain')
                if p!=captain or not self.captain_immune:shadow=max(0,shadow-CURSES[effect]-(10 if self.admiral_curse_active() else 0))
            elif effect=='trick':shadow=max(0,shadow-20)
            self.shadow_pots[who]=min(9999,shadow)
        if doubled:
            from webgame.game import CARD_NAMES
            self.session.log(f'Cannoneer is alone in the storm: {CARD_NAMES[effect]} adds {TREASURE[effect]*2:g} gold instead of {TREASURE[effect]:g}. The extra gold counts toward power earnings when recovered.','power')

    def _settle_credit(self,p,fraction):
        if p in self.shadow_pots:
            self.attribution[p]['gold']+=max(0,self.chest-self.shadow_pots.pop(p))*fraction

    def harbor(self,p,forced=False):
        before=self.status[p]
        self._credit_pot()
        result=super().harbor(p,forced)
        if before=='active' and self.status[p]=='harbor':
            self._harbor_credit(p)
        return result

    def _harbor_credit(self,p):
        self._settle_credit(p,1)
        for effect,value in [('escape',20),('heart',10)]:
            if self.tide_equipment.get(effect)==p and effect in self.held[p]:
                self.attribution[p]['gold']+=value
                del self.tide_equipment[effect]

    def known_hazard_exits(self):
        # The existing engine deliberately bypasses harbor() for remembered traps.
        before=list(self.status)
        result=super().known_hazard_exits()
        for p,status in enumerate(before):
            if status=='active' and self.status[p]=='harbor':self._harbor_credit(p)
        return result

    def sink(self,p,maroon=False):
        self._credit_pot()
        before=self.status[p];ships=self.ships[p];pot=self.chest;fraction=self._lost_fraction(p,maroon)
        saved_before=self.states[p]['power_stats']['ui_gold_saved'];heart='heart' in self.held[p]
        result=super().sink(p,maroon)
        if before!='active':return result
        if self.status[p]=='active':
            # Only the gold that would actually have been lost was protected.
            self.states[p]['power_stats']['ui_gold_saved']=saved_before+pot*fraction
        else:
            self._settle_credit(p,1-fraction)
            if self.tide_equipment.get('escape')==p and 'escape' in self.held[p]:self.attribution[p]['goldSaved']+=pot*.5
            if self.tide_equipment.get('heart')==p and heart and self.ships[p]==ships:self.attribution[p]['livesSaved']+=1
            c=self.credit_context
            if c and c['owner'] is not None and c['origin']=='tide' and not c['safe'] and c['owner']!=p:
                self._harm(c['owner'],pot*fraction,max(0,ships-self.ships[p]))
        return result

    def _prophecy_before(self,p,token):
        if self.powers[p]!='Parrot Whisperer' or self.status[p]!='active' or not self.deck or self.safe():return None
        drawer=self.next_drawer() if token else next((self.seating[(self.seating.index(p)+i)%self.player_count] for i in range(1,self.player_count+1) if self.status[self.seating[(self.seating.index(p)+i)%self.player_count]]=='active'),p)
        card=self.deck[-1];effect=self.previous if card=='echo' else card
        if effect not in ('whirlpool','marooned') or effect=='marooned' and drawer!=p:return None
        if self.hazard_immune(p,effect=='marooned'):return None
        return card,effect,self.chest*self._lost_fraction(p,effect=='marooned'),int('heart' not in self.held[p])

    def _prophecy_after(self,p,before):
        if before and (not self.deck or self.deck[-1]!=before[0]):
            self.attribution[p]['goldSaved']+=before[2];self.attribution[p]['livesSaved']+=before[3]

    def bot_prophecy(self,p,token=False):
        before=self._prophecy_before(p,token);result=super().bot_prophecy(p,token);self._prophecy_after(p,before);return result

    def prophecy(self,p,token=False):
        # Bot calls are counted by bot_prophecy, exactly once.
        before=self._prophecy_before(p,token) if p==0 and not self.session.fast() else None
        result=super().prophecy(p,token);self._prophecy_after(p,before);return result

    def spyglass(self,p):
        k=min(10,len(self.deck));before=self.states[p]['power_stats']['spyglass_treasures_lifted']
        result=super().spyglass(p)
        top=int(self.states[p]['power_stats']['spyglass_treasures_lifted']>before)
        for event in reversed(self.session.events):
            if event['kind']=='spyglass' and event['player']==p:
                event.update(count=k,bottom=k-top,top=top);break
        c=self.credit_context
        if top and c and c['owner']==p and c['origin']=='tide':self.deck[-1]=SourcedCard(self.deck[-1],p,'spyglass')
        return result

    def resolved_card(self,p,card,effect,safe):
        self._credit_pot(effect)
        c=self.credit_context
        if c:
            owner=c['owner'];others=lambda who:sum(status=='active' for j,status in enumerate(c['active']) if j!=who)
            if not safe:
                if p==self.power_index.get('Cursed Captain') and effect in CURSES:self.attribution[p]['goldSaved']+=CURSES[effect]
                admiral=self.power_index.get('Undead Admiral')
                if admiral is not None and effect in CURSES and c['active'][admiral]=='harbor' and p!=self.power_index.get('Cursed Captain'):
                    self._harm(admiral,10*others(admiral))
                swindler=self.power_index.get('Storm Swindler')
                if swindler is not None and effect in TREASURE and c['stolen']==0:
                    self._harm(swindler,TREASURE[effect]*others(swindler))
                    if c['active'][swindler]!='active':self.attribution[swindler]['gold']+=TREASURE[effect]
                if owner is not None and c['origin']=='tide':
                    if owner==p:
                        if effect in ('escape','heart') and effect not in c['equipment'] and effect in self.held[p]:self.tide_equipment[effect]=p
                        if effect in ('wave','trick'):self.attribution[p]['gold']+=10 if effect=='wave' else 20
                    if effect in ('key','chest'):self.tide_safe=owner
                    if effect=='trick':self._harm(owner,20*others(owner))
                    if effect in CURSES and p!=self.power_index.get('Cursed Captain'):
                        self._harm(owner,CURSES[effect]*others(owner))
                    if effect=='rudder' and p!=owner and self.powers[p]!='Mechanic':self._harm(owner,30)
            elif c['safe_owner'] is not None:
                who=c['safe_owner'];hazard=card if card!='echo' else None
                if c['active'][who]=='active' and (hazard=='whirlpool' or hazard=='marooned' and p==who) and not c['immune'][who][int(hazard=='marooned')]:
                    self.attribution[who]['goldSaved']+=c['before']*self._lost_fraction(who,hazard=='marooned')
                    self.attribution[who]['livesSaved']+=int('heart' not in self.held[who])
        return super().resolved_card(p,card,effect,safe)

    def power_results(self,p):
        result=super().power_results(p)
        if not self.attribution:return result
        credit=self.attribution[p]
        for key in ('gold','goldSaved','livesSaved'):result[key]=result.get(key,0)+credit[key]
        result['goldTaken']=credit['goldTaken'];result['livesTaken']=credit['livesTaken']
        if self.powers[p]=='Sea Witch':
            result['gold']+=25*self.hexes
            result['goldTaken']=10*self.hexes;result['pendingGold']=0
        if self.powers[p]=='Storm Swindler':
            result['gold']-=self.states[p]['power_stats']['swindler_treasure_gold'];result['pendingGold']=0
        return result

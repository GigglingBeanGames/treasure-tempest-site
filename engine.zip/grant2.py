"""Grant 2.0: learn vs three immutable Grant policies; shuffle seats every round."""
import argparse, collections, csv, gzip, hashlib, itertools, json, math, random, time
from pathlib import Path
from simulator import Game, Learner, ARMS, TREASURE, CURSES, HAZARDS, bucket

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'experiments/grant2'
NAMES=['Grant 2.0','Grant A','Grant B','Grant C']
# The first policy is exactly Grant. Others are explicit testable hypotheses.
STRATEGIES=[
    ('grant',1.,False,False,False),
    ('cautious',.6,False,False,False),
    ('bold',1.6,False,False,False),
    ('very_bold',2.8,False,False,False),
    ('surge_odds',1.,True,False,False),
    ('escape_odds',1.,False,True,False),
    ('both_odds',1.,True,True,False),
    ('surge_echo',1.,False,False,True),
    ('all_three',1.,True,True,True),
    ('cautious_all_three',.6,True,True,True),
    ('bold_all_three',1.6,True,True,True),
    ('very_cautious',.3,False,False,False),
]
EPSILON=[.85,.75,.65,.55,.45,.35,.25,.15,.05,.02]

class FrozenGrant:
    def __init__(self,path=OUT/'grant_frozen/policy.json'):
        raw=Path(path).read_bytes();self.sha256=hashlib.sha256(raw).hexdigest()
        self.q={tuple(row['state']):tuple(row['q']) for row in json.loads(raw)['states']}
    def appetite(self,g,p):
        state=Learner.context(self,g,p)
        q=self.q.get(state,(.25,)*len(ARMS))
        a=max(range(len(ARMS)),key=lambda a:(q[a],-abs(a-3)))
        return ARMS[a]

class Adaptive:
    """Terminal-win Monte Carlo action values with broad early exploration.

    Round policy choice plus actual Cannon/Prophecy decisions learn independently.
    Grant is the initial greedy/default action in every context.
    """
    def __init__(self,seed=9941):
        self.rng=random.Random(seed);self.q={};self.n={};self.trace=[]
        self.training=True;self.epsilon=.85
        self.selection=collections.Counter()
    def context(self,g):
        gap=g.gold[0]-max(g.gold[1:])
        return (bucket(g.round,(5,10)),bucket(g.ships[0],(1,3)),bucket(gap,(-300,100)))
    def choose(self,kind,g,labels):
        state=(kind,)+self.context(g)
        if kind!='round':state+=(bucket(g.chest,(100,300)),)
        # Labels are stable strategies, so availability filtering doesn't change meaning.
        for label in labels:
            key=state+(label,)
            self.q.setdefault(key,.25);self.n.setdefault(key,0)
        if self.training and self.rng.random()<self.epsilon:
            action=self.rng.choice(labels)
        else:
            action=max(labels,key=lambda x:(self.q[state+(x,)],x==labels[0]))
        if self.training:self.trace.append(state+(action,))
        self.selection[(kind,action)]+=1
        return action
    def finish(self,reward):
        for key in set(self.trace):
            self.n[key]+=1
            # Modest common prior avoids declaring an arm perfect after one win.
            alpha=1/(30+min(self.n[key],1500))
            self.q[key]+=alpha*(reward-self.q[key])
        self.trace=[]
    def save(self,path):
        Path(path).write_text(json.dumps({'algorithm':'terminal-win Monte Carlo round and event action values',
            'epsilon_schedule':EPSILON,'actions':[s[0] for s in STRATEGIES],
            'values':[{'key':k,'q':v,'visits':self.n[k]} for k,v in sorted(self.q.items())]},indent=2))
    @classmethod
    def load(cls,path):
        m=cls();d=json.loads(Path(path).read_text())
        for row in d['values']:
            k=tuple(row['key']);m.q[k]=row['q'];m.n[k]=row['visits']
        m.training=False;return m

class ExperimentGame(Game):
    def __init__(self,seed,frozen,adaptive=None,fixed_strategy=None,collector=None,game_id=0,player_count=4):
        super().__init__(seed,player_count=player_count)
        self.frozen=frozen;self.adaptive=adaptive;self.fixed_strategy=fixed_strategy
        self.collector=collector;self.game_id=game_id
        # Separate seat randomness from deck/decision randomness.
        self.seat_rng=random.Random(seed ^ 0x591BF)
        self.seating=[];self.strategy=STRATEGIES[0];self.current=0
        self.round_data=[];self.exit_rows=[];self.event_stats=collections.Counter()
        self.probability_stats=collections.Counter();self.choice_stats=collections.Counter()
        self.game_bonus=[0.]*len(self.ships);self.sell_gold=[0.]*len(self.ships)
    def setup_round(self):
        super().setup_round()
        self.physical_held=[]
        self.seating=list(range(len(self.ships)));self.seat_rng.shuffle(self.seating)
        self.appetite=[self.frozen.appetite(self,p) for p in range(len(self.ships))]
        if self.fixed_strategy is not None:
            name=self.fixed_strategy
        elif self.adaptive and self.status[0]=='active':
            name=self.adaptive.choose('round',self,[s[0] for s in STRATEGIES])
        else:name='grant'
        self.strategy=next(s for s in STRATEGIES if s[0]==name)
        self.appetite[0]*=self.strategy[1]
        self.own_draws=[0]*len(self.ships);self.harbor_gold=[0.]*len(self.ships);self.round_bonus=[0.]*len(self.ships)
        self.round_begin=list(self.gold);self.round_ships=list(self.ships)
        self.last_surge=None;self.reason='';self.resolving=None
        self.surge_followup_pending=False;self.followup_exit=False
        self.choice_stats['round_policy:'+name]+=1
    def odds(self,p=0):
        counts=self.remaining
        if self.known[p]:counts={self.known[p][0]:1}
        n=sum(counts.values())
        if n==0:return (0.,0.,0.,0.)
        raw_s=counts.get('surge',0)/n;raw_w=counts.get('whirlpool',0)/n
        echo=counts.get('echo',0)/n
        s=raw_s+(echo if self.previous=='surge' else 0)
        w=raw_w+(echo if self.previous=='whirlpool' else 0)
        if self.safe():s=w=0.
        return raw_s,raw_w,s,w
    def should_harbor(self,p):
        if p!=0:return super().should_harbor(p)
        odds=self.odds(0)
        if self.status[p]!='active' or self.safe() or self.block:return False
        if self.ships[p]==1 and not self.desperate(p):
            self.reason='one_ship_default';self.choice_stats[self.reason]+=1
            if self.collector:self.collector.decision(self,odds,True,self.reason)
            return True
        name,mult,prefer_surge,prefer_escape,echo=self.strategy
        _,_,s,w=odds
        if echo and self.last_surge==self.draws:
            self.reason='one_more_after_surge';result=False
            self.surge_followup_pending=True
        elif echo and self.followup_exit:
            # A copied Surge resets last_surge; otherwise leave after exactly one
            # extra global draw at the first legal window, unless another rule below
            # explicitly applies (here this hypothesis takes priority).
            self.reason='leave_after_surge_followup';result=True
        elif prefer_escape and 'escape' in self.held[0] and s>0 and w<=2*s:
            self.reason='escape_odds_continue';result=False
        elif prefer_surge and s>w:
            self.reason='surge_odds_continue';result=False
        else:
            result=super().should_harbor(0)
            self.reason='grant_risk_harbor' if result else 'grant_risk_continue'
        self.choice_stats[self.reason]+=1
        if self.collector:self.collector.decision(self,odds,result,self.reason)
        return result
    def harbor(self,p,forced=False):
        if self.status[p]!='active':return
        amount=self.harbor_value(p)
        if p==0 and 'escape' in self.held[p]:
            self.event_stats['escape_harbor_count']+=1;self.event_stats['escape_harbor_gold']+=20
        self.harbor_gold[p]+=amount
        self.exit_rows.append((p,'forced' if forced else 'voluntary',self.draws,self.own_draws[p],self.chest,
                               self.ships[p],self.reason if p==0 and not forced else str(self.resolving)))
        super().harbor(p,forced)
    def sink(self,p,maroon=False):
        if self.status[p]!='active':return
        if p==0 and 'escape' in self.held[p]:
            self.event_stats['escape_sink_count']+=1;self.event_stats['escape_sink_gold']+=self.chest/2
        self.exit_rows.append((p,'sunk',self.draws,self.own_draws[p],self.chest,self.ships[p],str(self.resolving)))
        super().sink(p,maroon)
    def check_end(self):
        before=list(self.gold);harbor_before=list(self.harbor_gold)
        ended=super().check_end()
        for p in range(len(self.ships)):
            bonus=self.gold[p]-before[p]-(self.harbor_gold[p]-harbor_before[p])
            self.round_bonus[p]+=bonus;self.game_bonus[p]+=bonus
        return ended
    def cannon(self,p):
        targets=[j for j in self.seating if j!=p and self.status[j]=='active']
        if p!=0 or not self.adaptive:
            if targets:self.harbor(max(targets,key=lambda j:self.gold[j]+30*self.ships[j]),True)
            return
        if not targets:
            self.choice_stats['cannon:no_target']+=1;return
        labels=['grant_target','score_leader','fewest_ships','most_ships','random_target']
        action=self.adaptive.choose('cannon',self,labels)
        if action=='grant_target':target=max(targets,key=lambda j:self.gold[j]+30*self.ships[j])
        elif action=='score_leader':target=max(targets,key=lambda j:self.gold[j])
        elif action=='fewest_ships':target=min(targets,key=lambda j:self.ships[j])
        elif action=='most_ships':target=max(targets,key=lambda j:self.ships[j])
        else:target=self.rng.choice(targets)
        self.choice_stats['cannon:'+action]+=1
        self.choice_stats['cannon_target:'+(NAMES[target] if target<len(NAMES) else f'Player {target+1}')]+=1
        self.harbor(target,True)
    def prophecy(self,p):
        if p!=0 or not self.adaptive:return super().prophecy(p)
        k=min(2,len(self.deck))
        if not k:return
        cards=self.deck[-k:][::-1]
        action=self.adaptive.choose('prophecy',self,['grant_order','seek_surge','safe_first','hazard_first','keep_order'])
        self.choice_stats['prophecy:'+action]+=1
        if action=='grant_order':
            before=cards.copy();super().prophecy(p)
            if len(self.known[p])<k:
                self.choice_stats['prophecy_bottom:'+self.deck[0]]+=1
            return
        def rank(c):
            if action=='keep_order':return 0
            if action=='hazard_first':return 1000 if c in HAZARDS else 0
            if c in HAZARDS:return -1000
            if c=='surge':return 2000 if action=='seek_surge' else 200
            if c=='siren':return -100
            if c in CURSES:return -CURSES[c]
            return TREASURE.get(c,10)
        ordered=sorted(cards,key=rank,reverse=True)
        bottom=None
        if action in ('safe_first','seek_surge') and len(ordered)>1 and rank(ordered[-1])<0:
            bottom=ordered.pop()
        del self.deck[-k:]
        if bottom:
            self.deck.insert(0,bottom);self.choice_stats['prophecy_bottom:'+bottom]+=1
        self.deck.extend(reversed(ordered));self.known=[[] for _ in range(len(self.ships))];self.known[p]=ordered.copy()
    def draw(self,p):
        # Track the public next-card odds immediately before EVERY draw, whether
        # Grant 2.0 is blocked or voluntarily continuing. Never pass deck order to it.
        odds=self.odds(0)
        if self.collector:self.collector.odds(self,p,odds)
        c=self.deck[-1] if self.deck else None # engine instrumentation only
        safe=self.safe();effect=self.previous if c=='echo' else c
        self.resolving=effect
        self.own_draws[p]+=1
        old_gold=self.gold[0];old_chest=self.chest
        self.event_stats['all_draws']+=1
        if p==0:
            self.event_stats['own_draws']+=1
            self.event_stats['drawn:'+str(c)]+=1
            self.event_stats[('calm:' if safe else 'normal:')+str(c)]+=1
            if not safe:self.event_stats['effect:'+str(effect)]+=1
            if c=='echo' and not safe:self.event_stats['echo_copy:'+str(effect)]+=1
        super().draw(p)
        if not safe and effect=='surge':
            self.last_surge=self.draws;self.followup_exit=False
        if self.surge_followup_pending:
            self.choice_stats['surge_followup_draws']+=1
            self.choice_stats['surge_followup_result:'+str(c)]+=1
            if c=='echo' and not safe and effect=='surge':self.choice_stats['surge_followup_echo_doubles']+=1
            else:self.followup_exit=True
            self.surge_followup_pending=False
        if self.collector:self.collector.card(self,p,c,effect,safe,old_chest,old_gold)
    def play(self):
        while self.round<15 and not self.ended:
            self.setup_round()
            cursor=0
            while 'active' in self.status and not self.ended:
                while self.status[self.seating[cursor]]!='active':cursor=(cursor+1)%len(self.ships)
                self.current=self.seating[cursor]
                self.windows(self.current)
                if 'active' not in self.status:break
                if self.status[self.current]=='active':self.draw(self.current)
                cursor=(cursor+1)%len(self.ships)
                if self.draws>10000:raise RuntimeError('Round safety bound')
            assert collections.Counter(self.deck+self.discard+self.physical_held)==self.initial_counts
            for p in range(len(self.ships)):
                row={'game':self.game_id,'round':self.round,'bot':p,'seat':self.seating.index(p),
                     'round_gold':self.gold[p]-self.round_begin[p]-self.round_bonus[p],
                     'harbor_gold':self.harbor_gold[p],
                     'additional_gold':self.gold[p]-self.round_begin[p]-self.round_bonus[p]-self.harbor_gold[p],
                     'bonus_gold':self.round_bonus[p],'cumulative_gold':self.gold[p],
                     'ships_start':self.round_ships[p],'ships_end':self.ships[p],
                     'status':self.status[p],'round_draws':self.draws,'own_draws':self.own_draws[p]}
                self.round_data.append(row)
                if self.collector:self.collector.round_row(row)
        if not self.ended:
            most=max(self.ships)
            if self.ships.count(most)==1:
                p=self.ships.index(most);self.gold[p]+=100;self.game_bonus[p]+=100
        for p in range(len(self.ships)):
            self.sell_gold[p]=30*self.ships[p];self.gold[p]+=self.sell_gold[p]
        best=max(self.gold);winners=[p for p,x in enumerate(self.gold) if abs(x-best)<1e-9]
        reward=[1/len(winners) if p in winners else 0. for p in range(len(self.ships))]
        if self.collector:self.collector.finish_game(self,reward)
        return reward

class Collector:
    def __init__(self,path=None,detail_start=90001,player_count=4,names=None):
        self.player_count=player_count;self.names=names or (NAMES if player_count==4 else [f"Player {i+1}" for i in range(player_count)])
        self.path=Path(path) if path else None;self.detail_start=detail_start
        self.n=0;self.credit=[0.]*self.player_count;self.sq=[0.]*self.player_count;self.scores=[0.]*self.player_count;self.ships=[0.]*self.player_count
        self.wins=[0]*self.player_count;self.ties=[0]*self.player_count;self.rounds=collections.defaultdict(lambda:[0,0.,0.,0.,0.,0.])
        self.round_hist=collections.defaultdict(collections.Counter)
        self.last_round_hist=collections.defaultdict(collections.Counter)
        self.exits=collections.defaultdict(collections.Counter);self.last_events=collections.Counter();self.last_choices=collections.Counter()
        self.last_strategy=collections.Counter();self.seats=collections.Counter();self.blocks=[]
        self.block_credit=[0.]*self.player_count;self.block_scores=[0.]*self.player_count;self.block_wins=[0]*self.player_count;self.block_ties=[0]*self.player_count
        self.files=[]
        if self.path:
            self.path.mkdir(parents=True,exist_ok=True)
            self.round_writer=self.writer('round_scores.csv.gz',['game','round','bot','seat','round_gold','harbor_gold','additional_gold','bonus_gold','cumulative_gold','ships_start','ships_end','status','round_draws','own_draws'])
            self.game_writer=self.writer('game_scores.csv.gz',['game','bot','win_credit','final_gold','ships','smooth_sailor_gold','ship_sale_gold','rounds'])
            self.odds_writer=self.writer('last_10000_odds.csv.gz',['game','round','draw_before','drawing_bot','grant2_active','known_top','p_surge_card','p_whirlpool_card','p_surge_effect','p_whirlpool_effect','safe','harbor_block'])
            self.dec_writer=self.writer('last_10000_decisions.csv.gz',['game','round','draws','own_draws','chest','ships','escape_ship','strategy','reason','harbor','p_surge_effect','p_whirlpool_effect'])
            self.card_writer=self.writer('last_10000_events.csv.gz',['game','round','draw','drawing_bot','card','effect','calm','chest_before','chest_after','grant2_gold_delta'])
    def writer(self,name,header):
        f=gzip.open(self.path/name,'wt',newline='',compresslevel=1);self.files.append(f)
        w=csv.writer(f);w.writerow(header);return w
    def detail(self,g):return bool(self.path and g.game_id>=self.detail_start)
    def odds(self,g,p,o):
        if self.detail(g):self.odds_writer.writerow([g.game_id,g.round,g.draws,p,g.status[0]=='active',g.known[0][0] if g.known[0] else '',*o,g.safe(),g.block])
    def decision(self,g,o,result,reason):
        if self.detail(g):self.dec_writer.writerow([g.game_id,g.round,g.draws,g.own_draws[0],g.chest,g.ships[0],'escape' in g.held[0],g.strategy[0],reason,result,o[2],o[3]])
    def card(self,g,p,c,effect,safe,old_chest,old_gold):
        if self.detail(g):self.card_writer.writerow([g.game_id,g.round,g.draws,p,c,effect,safe,old_chest,g.chest,g.gold[0]-old_gold])
    def round_row(self,row):
        if self.path:self.round_writer.writerow(list(row.values()))
        key=(row['round'],row['bot']);a=self.rounds[key]
        a[0]+=1;a[1]+=row['round_gold'];a[2]+=row['harbor_gold'];a[3]+=row['additional_gold'];a[4]+=row['ships_end'];a[5]+=row['round_gold']**2
        self.round_hist[key][row['round_gold']]+=1
        if row['game']>=self.detail_start:self.last_round_hist[key][row['round_gold']]+=1
        self.seats[(row['bot'],row['seat'])]+=1
    def finish_game(self,g,reward):
        self.n+=1
        for p in range(self.player_count):
            self.credit[p]+=reward[p];self.sq[p]+=reward[p]**2;self.scores[p]+=g.gold[p];self.ships[p]+=g.ships[p]
            sole=int(reward[p]==1);tie=int(0<reward[p]<1)
            self.wins[p]+=sole;self.ties[p]+=tie
            self.block_credit[p]+=reward[p];self.block_scores[p]+=g.gold[p];self.block_wins[p]+=sole;self.block_ties[p]+=tie
            if self.path:self.game_writer.writerow([g.game_id,p,reward[p],g.gold[p],g.ships[p],g.game_bonus[p],g.sell_gold[p],g.round])
        if g.game_id>=self.detail_start:
            self.last_events.update(g.event_stats);self.last_choices.update(g.choice_stats)
            for p,kind,draws,own,chest,ships,reason in g.exit_rows:
                if p==0:
                    self.exits[(kind,'global_draws')][draws]+=1
                    self.exits[(kind,'own_draws')][own]+=1
                    self.exits[(kind,'chest')][chest]+=1
                    self.exits[(kind,'reason')][reason]+=1
        if self.n%10000==0:
            row={'games_start':self.n-9999,'games_end':self.n,'win_rates':[x/10000 for x in self.block_credit],
                 'win_credits':self.block_credit[:],'outright_wins':self.block_wins[:],'tied_games':self.block_ties[:],
                 'mean_scores':[x/10000 for x in self.block_scores]}
            self.blocks.append(row)
            self.block_credit=[0.]*self.player_count;self.block_scores=[0.]*self.player_count;self.block_wins=[0]*self.player_count;self.block_ties=[0]*self.player_count
    @staticmethod
    def hist_stats(hist):
        n=sum(hist.values())
        if not n:return {}
        vals=sorted(hist);out={'n':n,'mean':sum(x*c for x,c in hist.items())/n}
        for label,q in [('p10',.1),('median',.5),('p90',.9)]:
            total=0
            for x in vals:
                total+=hist[x]
                if total>=q*n:out[label]=x;break
        return out
    def summary(self):
        ci=[]
        for p in range(self.player_count):
            mean=self.credit[p]/self.n;se=math.sqrt(max(0,self.sq[p]/self.n-mean*mean)/self.n)
            ci.append([mean-1.96*se,mean+1.96*se])
        return {'games':self.n,'names':self.names,'win_rates':[x/self.n for x in self.credit],
                'ci95':ci,'outright_wins':self.wins,'tied_games':self.ties,'mean_scores':[x/self.n for x in self.scores],
                'mean_ships':[x/self.n for x in self.ships],'blocks':self.blocks,
                'round_scores':[{'round':r,'bot':p,'games_reaching_round':v[0],'mean_gold':v[1]/v[0],
                     'mean_harbor':v[2]/v[0],'mean_additional':v[3]/v[0],'mean_ships_end':v[4]/v[0],
                     **self.hist_stats(self.round_hist[(r,p)])} for (r,p),v in sorted(self.rounds.items())],
                'last_10000_round_scores':[{'round':r,'bot':p,**self.hist_stats(h)} for (r,p),h in sorted(self.last_round_hist.items())],
                'last_10000_events':dict(self.last_events),'last_10000_choices':dict(self.last_choices),
                'last_10000_exits':{kind+'_'+metric:(dict(h) if metric=='reason' else self.hist_stats(h)) for (kind,metric),h in self.exits.items()},
                'seat_counts':{self.names[p]:[self.seats[(p,s)] for s in range(self.player_count)] for p in range(self.player_count)}}
    def close(self):
        for f in self.files:f.close()

def evaluate(frozen,adaptive,n,seed,strategy=None):
    c=Collector();
    for i in range(n):
        g=ExperimentGame(seed+i,frozen,adaptive,strategy,c,i+1)
        g.play()
    return c.summary()

def run(args):
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    frozen=FrozenGrant();adaptive=Adaptive()
    c=Collector(out,detail_start=max(1,args.games-9999))
    start=time.time()
    for i in range(args.games):
        stage=min(9,int(i*10/args.games));adaptive.epsilon=EPSILON[stage]
        g=ExperimentGame(10_000_000+i,frozen,adaptive,collector=c,game_id=i+1)
        r=g.play();adaptive.finish(r[0])
        if (i+1)%10000==0:
            row=dict(c.blocks[-1]);row['epsilon']=adaptive.epsilon;row['elapsed_seconds']=round(time.time()-start,1)
            print(json.dumps(row),flush=True)
            adaptive.save(out/'grant2_policy.json')
    c.close();adaptive.save(out/'grant2_policy.json')
    training=c.summary();training['elapsed_seconds']=round(time.time()-start,1)
    training['frozen_grant_sha256']=frozen.sha256
    training['training_games']=args.games;training['seed_start']=10000000;training['epsilon_schedule']=EPSILON
    (out/'training_results.json').write_text(json.dumps(training,indent=2))
    print('Training complete; running independent fixed-policy tests.',flush=True)
    adaptive.training=False
    final=evaluate(frozen,adaptive,args.eval_games,20_000_000)
    (out/'frozen_evaluation.json').write_text(json.dumps(final,indent=2))
    print('Frozen evaluation: '+json.dumps(final['win_rates']),flush=True)
    # Explicit tests of each requested rule, with unchanged Grant event choices.
    experiments={}
    for strategy in ['grant','surge_odds','escape_odds','both_odds','surge_echo','all_three']:
        result=evaluate(frozen,None,args.test_games,30_000_000,strategy)
        experiments[strategy]=result
        print('Hypothesis '+strategy+': '+json.dumps(result['win_rates']),flush=True)
    (out/'hypothesis_tests.json').write_text(json.dumps(experiments,indent=2))
    assert frozen.sha256==hashlib.sha256((OUT/'grant_frozen/policy.json').read_bytes()).hexdigest()
    print('DONE',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--games',type=int,default=100000)
    p.add_argument('--eval-games',type=int,default=10000);p.add_argument('--test-games',type=int,default=3000)
    p.add_argument('--output',default=str(OUT))
    run(p.parse_args())

"""Deterministic, thread-free browser adapter for the unchanged game engine."""
import copy
import json
from webgame.game import Session
from webgame.expansion import BrowserExpansionGame as InteractiveGame, load_current_bot, POWER_NAMES
from powers.engine import load_opponents

VERSION = 'tt-expansion-cannon-lock-2'
POLICIES = load_opponents()
CONFIGS = {p: load_current_bot(p)['config'] for p in POWER_NAMES}

class Pause(Exception):
    pass

class ReplaySession(Session):
    def __init__(self, document):
        self.document = document
        self.id = str(document['seed'])
        self.name = document['name'].strip()[:24] or document['powers'][0]
        self.seed = document['seed']
        self.powers = document['powers']
        self.records = document['actions']
        self.cursor = 0
        self.request = None
        self.revision = len(self.records) + 1
        self.events = []
        self.logs = []
        self.complete = False
        self.error = None
        self.skip_through = 0
        self.auto = False
        self.game = None

    def ask(self, kind, title, options, detail='', **extra):
        if kind == 'round-end':
            detail = 'All collected round cards return to the deck, including the Queen’s enchanted cards. Persistent power tokens remain.'
        if self.fast():
            return options[0]['value']
        prompt = {'id': f'{self.id}:{self.cursor}', 'kind': kind, 'title': title,
                  'detail': detail, 'options': options, **extra}
        if self.cursor == len(self.records):
            self.request = prompt
            raise Pause()
        record = self.records[self.cursor]
        if record['requestId'] != prompt['id']:
            raise ValueError('Saved voyage has an invalid choice sequence.')
        value = record['value']
        if record.get('skip'):
            self.skip_through = self.game.round
            value = options[0]['value']
        if value not in [o['value'] for o in options]:
            raise ValueError('Saved choice is no longer available.')
        self.cursor += 1
        return value

    def snapshot(self):
        return {'id': self.id, 'revision': self.revision, 'request': self.request,
                'game': self.game.public_state(), 'events': self.events[-40:],
                'log': [entry for entry in self.logs if entry['round']==self.game.round],
                'complete': self.complete, 'error': self.error}

    def replay(self):
        self.game = InteractiveGame(self, self.seed, self.powers, POLICIES,
                                    copy.deepcopy([CONFIGS[p] for p in self.powers]))
        try:
            credit = self.game.play()
            self.complete = True
            self.event('finish', winners=[i for i, r in enumerate(credit) if r > 0])
            self.log('The voyage is over. Ships, tokens, and final bonuses have been counted.', 'gold')
        except Pause:
            pass
        if self.cursor != len(self.records):
            raise ValueError('Saved voyage contains extra choices.')
        return self.snapshot()

DOCUMENT = None
STATE = None

def dispatch(message):
    global DOCUMENT, STATE
    kind = message['type']
    if kind == 'start':
        powers = message['powers']
        if not 3 <= len(powers) <= 6 or len(set(powers)) != len(powers) or any(p not in POWER_NAMES for p in powers):
            raise ValueError('Choose three to six different captain powers.')
        candidate = {'version': VERSION, 'seed': int(message['seed']),
                     'name': str(message['name']), 'powers': powers, 'actions': []}
    elif kind == 'resume':
        candidate = copy.deepcopy(message['document'])
        if candidate.get('version') != VERSION:
            raise ValueError('This saved voyage belongs to a different game version.')
    elif kind == 'action':
        if STATE is None or STATE['complete'] or not STATE['request'] or message['requestId'] != STATE['request']['id']:
            raise ValueError('That choice has already been resolved.')
        if not message.get('skip') and message['value'] not in [o['value'] for o in STATE['request']['options']]:
            raise ValueError('Choose one of the available actions.')
        candidate = copy.deepcopy(DOCUMENT)
        candidate['actions'].append({k: message[k] for k in ('requestId', 'value', 'skip') if k in message})
    else:
        raise ValueError('Unknown game action.')
    result = ReplaySession(candidate).replay()
    DOCUMENT, STATE = candidate, result
    return json.dumps({'state': STATE, 'document': DOCUMENT})

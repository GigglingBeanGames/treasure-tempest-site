"""Learnable Sea Witch harbor preferences; expansion rules remain unchanged."""
import collections
from powers.expansion_v3_20260926 import ExpansionGameV3
from powers.expansion_20260926 import CURSES,HAZARDS
from powers.engine import ExperimentGame
BASE={'mode':'baseline','risk':1.,'hex_value':20.,'token_cost':30.,'healthy':1.,'low':1.,'lead':.6,'trailing':1.,'alone':1.,'big_pot':1.,'poor_odds':.6,'last_life':True,'followup':1,'small_pot':1.}
SPACE={'mode':['aware'],'risk':[.4,.65,1.,1.5,2.3,3.5], 'hex_value':[0.,10.,20.,40.,70.], 'token_cost':[0.,10.,30.,60.], 'healthy':[.7,1.,1.5,2.], 'low':[.4,.7,1.,1.5], 'lead':[.25,.5,.8,1.2], 'trailing':[.8,1.,1.5,2.], 'alone':[.6,1.,1.5,2.], 'big_pot':[.4,.7,1.,1.4], 'poor_odds':[.3,.6,1.], 'last_life':[True,False], 'followup':[0,1,2], 'small_pot':[.7,1.,1.5,2.]}
class LearningWitchGame(ExpansionGameV3):
 def __init__(self,*a,strategy=None,**kw):
  self.witch_strategy=strategy or BASE;self.behavior=collections.Counter()
  super().__init__(*a,**kw)
 def should_harbor(self,p):
  c=self.witch_strategy
  if self.powers[p]!='Sea Witch' or c['mode']=='baseline':return super().should_harbor(p)
  if self.status[p]!='active' or self.safe() or self.blocks[p]:return False
  v=self.bot_human if p==0 else self.views[p]
  protection=bool(self.witch_hearts or 'heart' in self.held[p])
  if self.round==15 and not v.projected_lead():return False
  if self.chest<=0:return False
  if self.ships[p]==1 and not protection and self.round<15 and c['last_life']:
   self.behavior['unprotected_last_life_harbor']+=1;return True
  counts=collections.Counter(self.known[p][:1]) if self.known[p] else v.remaining
  n=sum(counts.values())
  if not n:return True
  gain=loss=shiprisk=hexchance=0.
  for card,count in counts.items():
   d,w,s=v.expected_card(card,0);effect=v.previous if card=='echo' else card
   if effect in CURSES:hexchance+=count/n
   gain+=count*d/n;loss+=count*w/n;shiprisk+=count*s/n
  # Reward is still wins. These are tunable decision estimates, not extra game gold.
  gain+=hexchance*c['hex_value']
  shipvalue=0 if self.round==15 else (30+22*(16-self.round)/max(1,self.ships[p]))*(1.55 if self.ships[p]<=3 else 1.)
  if self.witch_hearts:shipvalue=min(shipvalue,c['token_cost'])
  if 'heart' in self.held[p]:shipvalue=0.
  risk=loss*self.chest*(.5 if 'escape' in self.held[p] else 1.)+shiprisk*shipvalue
  mult=c['risk']*c['lead' if self.gold[p]>max(self.gold[j] for j in range(self.player_count) if j!=p) else 'trailing']
  if self.ships[p]>=4:mult*=c['healthy']
  elif self.ships[p]<=2 and not protection:mult*=c['low']
  if self.status.count('active')==1:mult*=c['alone']
  if self.chest>=300:mult*=c['big_pot']
  if self.chest<=50:mult*=c['small_pot']
  _,_,surge,whirlpool=ExperimentGame.odds(v,0)
  if whirlpool>max(.001,3*surge):mult*=c['poor_odds']
  leave=risk>max(4.,gain+8)*self.appetite[p]*mult
  if c['followup'] and self.last_surge==self.draws:leave=False
  elif c['followup']==2 and self.last_surge is not None and self.draws==self.last_surge+1 and 'escape' not in self.held[p] and whirlpool>surge:leave=True
  self.behavior['aware_decisions']+=1;self.behavior['aware_harbors']+=leave
  self.behavior['protected_decisions']+=protection;self.behavior['protected_harbors']+=protection and leave
  return leave
 def harbor(self,p,forced=False):
  before=self.status[p];result=super().harbor(p,forced)
  if self.powers[p]=='Sea Witch' and before=='active' and self.status[p]=='harbor':
   kind='forced' if forced else 'voluntary';self.behavior[kind+'_harbors']+=1
   self.behavior[kind+'_draws_total']+=self.draws;self.behavior[kind+'_pot_total']+=self.chest
   if self.draws==3:self.behavior[kind+'_immediate']+=1
  return result

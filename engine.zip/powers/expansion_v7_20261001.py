"""Risk-aware bot revision and October 2026 deck/rule adjustments."""
import collections,itertools
from powers.expansion_v6_20260926 import ExpansionGameV6
from powers.expansion_20260926 import BASE,TREASURE,CURSES,HAZARDS

# Seven Cursed Coins. The voyage begins with 68 cards, then the two red
# rounds add one Whirlpool each for 70 physical cards in the full voyage.
BASE['coin_curse']=7

GOOD={'heart','escape','cannon','trick','prophecy','spyglass','siren','key','chest','surge',*TREASURE}
BAD={'whirlpool','marooned','rudder',*CURSES}

class ExpansionGameV7(ExpansionGameV6):
 merchant_bonus=20
 starting_tokens={**ExpansionGameV6.starting_tokens,'Navigator':4,'Parrot Whisperer':3,'Undead Admiral':2}
 def __init__(self,*args,**kwargs):
  self.public_warning_draws=0;self.public_warning_kind=None
  self.prophecy_owner=None;self.prophecy_commit={};self.mechanic_sinkings=0
  self.tide_public_placement_at=None;self._tide_reacting=False
  super().__init__(*args,**kwargs)
  cannoneer=self.power_index.get('Cannoneer')
  if cannoneer is not None:self.states[cannoneer]['tokens']=0

 def setup_round(self):
  self.public_warning_draws=0;self.public_warning_kind=None;self.prophecy_owner=None
  self.prophecy_commit={};self.tide_public_placement_at=None
  return super().setup_round()

 def _view(self,p):return self.bot_human if p==0 else self.views[p]
 def _refuses_exit(self,p):
  # MultiPowerGame evaluates legacy strategy rules inside the player's focused view.
  with self.focus(p):return self.refuse_exit(p)
 def _remaining(self,p):
  view=self._view(p)
  return collections.Counter(self.known[p][:1]) if self.known[p] else view.remaining
 def _solo_bank_wins(self,p):
  if self.status.count('active')!=1 or self.status[p]!='active':return False
  rivals=max((self.gold[j] for j in range(self.player_count) if j!=p),default=0)
  return self.gold[p]+self.harbor_value(p)>=rivals+30

 def queen_collects_from(self,p):
  queen=self.power_index.get('Siren Queen')
  if queen is None:return False
  at=self.seating.index(queen)
  return p in (queen,self.seating[(at-1)%self.player_count],self.seating[(at+1)%self.player_count])

 def plunder_value(self,chest):return chest/2

 def should_harbor(self,p):
  if self.status[p]!='active' or self.safe() or self.blocks[p]:return False
  if self.powers[p]=='Tempest King' and self.states[p]['protection']:return False
  if self._refuses_exit(p):return False
  if self.prophecy_commit.get(p,0)>0:return False
  held=set(self.held[p])
  ghost=self.powers[p]=='Ghost Captain'
  if ghost and self.chest<=100:
   known_danger=bool(self.known[p] and self.dangerous_known_card(p,self.known[p][0],self.next_drawer()))
   if known_danger:return True
   if self.chest<=50:return False
  if self._solo_bank_wins(p) and not (ghost and self.chest<=100) and not ('escape' in held and self.chest<180):return True
  # Publicly fleeing after private information or a Tide placement is a danger signal.
  if self.public_warning_draws and self.chest>=60 and not (ghost and self.chest<=100):
   if self.powers[p]=='Navigator' and self.states[p]['protection']:return False
   if self.powers[p]=='Navigator' and self.states[p]['tokens'] and not self.states[p]['used_round']:
    # A public information tell is exactly the kind of danger Navigator saves tokens for.
    self.states[p]['tokens']-=1;self.states[p]['protection']=4;self.states[p]['used_round']=True
    self.states[p]['power_stats']['navigator_tokens']+=1
    return False
   if 'escape' not in held or self.chest>=220:return True
  if 'heart' in held and self.powers[p]!='Ghost Captain':
   limit=380 if 'escape' in held else 190
   if self.chest<limit and self.gold[p]<max(self.gold)+250:return False
  if ghost and self.chest<=100:
   # Preserve the restored Ghost policy but make ordinary 50–100 pots much
   # less attractive to bank. Explicitly known hazards were handled above.
   before=self.appetite[p];self.appetite[p]*=2.75
   try:return super().should_harbor(p)
   finally:self.appetite[p]=before
  return super().should_harbor(p)

 def _card_value(self,card,recipient,owner):
  effect=self.previous if card=='echo' else card;own=recipient==owner;power=self.powers[recipient]
  if effect in TREASURE:return TREASURE[effect]*(1 if own else -.7)
  if effect=='surge':return 180 if own else -100
  if effect=='heart':return (240 if power!='Ghost Captain' else 0) if own else -190
  if effect=='escape':return 280 if own else -230
  if effect in ('cannon','trick'):return 80 if own else -65
  if effect in ('prophecy','spyglass'):return 100 if own else -80
  if effect=='siren':return 90 if own and power=='Siren Queen' else -45
  if effect in ('key','chest'):return 120 if own and power=='Siren Queen' else 25 if own else -25
  if effect=='whirlpool':return -500 if own else 170
  if effect=='marooned':return -300 if own and power!='Marooned Monarch' else 100
  if effect=='rudder':return 0 if own and power=='Mechanic' else -90 if own else 40
  if effect in CURSES:return CURSES[effect] if own and power=='Cursed Captain' else -CURSES[effect]
  return 10

 def prophecy(self,p,token=False):
  # Human interactive ordering is supplied by BrowserExpansionBase; this path is bots/auto-play.
  length=len(self.deck);k=min(2,length)
  if not k:return
  cards=list(reversed(self.deck[-k:]));active=[j for j in self.seating if self.status[j]=='active'];at=active.index(p)
  leave=self.should_harbor(p)
  options=[]
  for bottom_index in [None,*range(k)]:
   rest=[c for i,c in enumerate(cards) if i!=bottom_index]
   # Keep equally scored prophecy choices stable across Python processes.  A
   # set's iteration order depends on the randomized hash seed, which used to
   # make an otherwise identical saved voyage branch differently after reload.
   for order in sorted(set(itertools.permutations(rest))):
    bottom=cards[bottom_index] if bottom_index is not None else None
    score=sum(self._card_value(card,active[(at+i+1)%len(active)],p)/(i+1) for i,card in enumerate(order))
    if bottom is not None:
     # Bury gifts an opponent would receive; also bury dangers when staying.
     next_recipient=active[(at+1)%len(active)]
     denied=self._card_value(bottom,next_recipient,p)
     score+=-denied*.9
    if leave and order:
     score+=max(0,-self._card_value(order[0],active[(at+1)%len(active)],p))*1.4
    options.append((score,list(order),bottom))
  _,order,bottom=max(options,key=lambda x:x[0])
  del self.deck[-k:]
  if bottom:self.deck.insert(0,bottom)
  self.deck.extend(reversed(order));self.known=[[] for _ in self.ships];self.known[p]=order.copy();self.wants=[False]*self.player_count;self.wants[p]=leave
  bottom_count=int(bottom is not None)
  if hasattr(self,'bottom_memory'):
   self.bottom_memory=[{i+bottom_count:c for i,c in memory.items() if i<length-k} for memory in self.bottom_memory]
   if bottom_count:self.bottom_memory[p][0]=self.deck[0]
  self.prophecy_owner=p
  if not leave and order and order[0] in CURSES:self.prophecy_commit[p]=1
  stats=self.states[p]['power_stats'];stats['prophecy_uses']+=1
  if token:stats['parrot_token_prophecies']+=1
  if order:stats['prophecy_top_'+order[0]]+=1
  if bottom:stats['prophecy_bottom_'+bottom]+=1

 def insert_tide(self,p):
  card=super().insert_tide(p);self.tide_public_placement_at=(p,self.draws)
  if self.session.fast():self._tide_reaction(p,False)
  return card

 def _tide_reaction(self,owner,urgent):
  if self._tide_reacting:return
  self._tide_reacting=True
  try:
   for p in list(self.seating):
    if p==owner or self.status[p]!='active' or self.safe() or self.blocks[p]:continue
    leave=self.should_harbor(p)
    if urgent and not leave and 'escape' not in self.held[p]:
     leave=self._view(p).risk_harbor(.72)
    if leave:self.harbor(p)
  finally:self._tide_reacting=False

 def harbor(self,p,forced=False):
  if not forced and self._refuses_exit(p):return
  before=self.status[p];known=len(self.known[p]) if p<len(self.known) else 0
  # Keep the already-approved decision stable through MultiPowerGame's focused
  # player view; projected-lead state can otherwise be evaluated in two frames.
  prior_known_exiting=getattr(self,'known_exiting',None)
  if not forced:self.known_exiting=p
  try:result=super().harbor(p,forced)
  finally:self.known_exiting=prior_known_exiting
  if before=='active' and self.status[p]=='harbor':
   if p==self.prophecy_owner and known:
    self.public_warning_draws=max(self.public_warning_draws,known);self.public_warning_kind='prophecy'
   if self.tide_public_placement_at==(p,self.draws):
    self.public_warning_draws=max(self.public_warning_draws,1);self.public_warning_kind='tide'
    if self.session.fast():self._tide_reaction(p,True)
  return result

 def cannon(self,p):
  if self.powers[p]=='Cannoneer':
   self.states[p]['tokens']+=1;self.states[p]['power_stats']['cannon_tokens_gained']+=1
  return super().cannon(p)

 def sink(self,p,maroon=False):
  mechanic=self.power_index.get('Mechanic');old_sales=self.repair_sales
  admiral=self.power_index.get('Undead Admiral');admiral_config=None
  if admiral is not None and self.states[admiral]['tokens']:
   c=self.configs[admiral];admiral_config=(c['plunder_min_gold'],c['plunder_late'])
   tokens=self.states[admiral]['tokens']
   c['plunder_min_gold']=450 if tokens==1 and self.round<12 else 350 if self.round<10 else 250
   c['plunder_late']=15
  old_limit=None
  if mechanic is not None and self.states[mechanic]['tokens']:
   if p==mechanic:
    old_limit=self.configs[mechanic]['repair_self_max_ships']
    others=max((self.ships[j] for j in range(self.player_count) if j!=mechanic),default=0)
    smooth=self.round>=14 and self.ships[mechanic]>others and self.ships[mechanic]-1<=others
    if smooth:self.configs[mechanic]['repair_self_max_ships']=99
   else:
    reserve=self.mechanic_sinkings>=2 and self.states[mechanic]['tokens']<=1 and self.round<13
    protect_leader=self.gold[p]>=max(self.gold[j] for j in range(self.player_count) if j!=p)+250 and self.ships[p]<=2
    if reserve or protect_leader:self.repair_sales=False
  before=self.ships[p];before_status=self.status[p];result=super().sink(p,maroon)
  if p==mechanic and before_status=='active' and self.status[p]=='sunk':self.mechanic_sinkings+=1
  self.repair_sales=old_sales
  if admiral_config is not None:
   self.configs[admiral]['plunder_min_gold'],self.configs[admiral]['plunder_late']=admiral_config
  if old_limit is not None:self.configs[mechanic]['repair_self_max_ships']=old_limit
  return result

 def award(self,p,amount,reason):
  if reason=='ghost_sinking_bonus':amount=50
  return super().award(p,amount,reason)

 def resolved_card(self,p,card,effect,safe):
  result=super().resolved_card(p,card,effect,safe)
  tide=self.power_index.get('Tide Watcher')
  if tide is not None and not safe and effect=='wave':
   self.states[tide]['tokens']+=1;self.states[tide]['power_stats']['tide_tokens_gained']+=1
  return result

 def draw(self,p):
  before_hexes=self.hexes;result=super().draw(p)
  gained=self.hexes-before_hexes;witch=self.power_index.get('Sea Witch')
  if gained and witch is not None:
   for j in range(self.player_count):
    change=5*gained if j==witch else -5*gained
    self.gold[j]+=change;self.states[j]['power_stats']['hex_immediate_gold']+=change
  if self.public_warning_draws:self.public_warning_draws-=1
  if not self.public_warning_draws:self.public_warning_kind=None
  for owner in list(self.prophecy_commit):
   self.prophecy_commit[owner]-=1
   if self.prophecy_commit[owner]<=0:del self.prophecy_commit[owner]
  return result

"""Searchable preferences. Defaults retain Grant 6's sailing policy."""
POWERS = {
    'Blood Sailor': 6, 'Cursed Captain': 6, 'Mechanic': 6, 'Merchant': 6,
    'Navigator': 6, 'Parrot Whisperer': 7, 'Siren Queen': 6,
    'Storm Swindler': 7, 'Storm Warden': 5, 'Tempest King': 6,
    'Tide Watcher': 6, 'Undead Admiral': 7,
}
COMMON = {
    'risk': [1., .4, .65, 1.5, 2.5, 4.],
    'lead': [1., .25, .6, 1.5],
    'mode': ['inherit', 'power_risk', 'patient', 'cautious'],
    'last_life': ['inherit', 'risk'],
    'prophecy': ['inherit', 'power', 'safe', 'surge', 'attack'],
    'cannon': ['leader', 'ships', 'fewest', 'power'],
}
SPECIFIC = {
    'Blood Sailor': {'target_risk': [1., .5, 2.]},
    'Cursed Captain': {'curse_appetite': [1., 1.5, 2.5]},
    'Mechanic': {'repair_self_max_ships': [3, 1, 2, 6], 'sell': ['balanced', 'always', 'reserve_two', 'never']},
    'Merchant': {'harbor_bonus_weight': [1., .5, 2., 4.]},
    'Navigator': {'nav_min_chest': [150, 0, 75, 300, 600], 'nav_max_ships': [3, 1, 2, 8], 'nav_risk': [.1, 0., .05, .2], 'protected_risk': [2., 1., 4., 8.]},
    'Parrot Whisperer': {'peek_min_chest': [150, 0, 75, 300], 'peek_max_ships': [3, 1, 2, 8], 'peek_reserve': [0, 1, 3]},
    'Siren Queen': {'pair_appetite': [1., .5, 2., 4.]},
    'Storm Swindler': {'trick_appetite': [1., 1.5, 2.5]},
    'Storm Warden': {'insured_risk': [1., 1.5, 2.5, 4.]},
    'Tempest King': {'alone_risk': [1., 1.5, 2.5, 4.]},
    'Tide Watcher': {'tide': ['useful', 'attack', 'immediate', 'hold'], 'tide_min_chest': [100, 0, 250, 500]},
    'Undead Admiral': {'plunder_min_gold': [300, 100, 200, 500, 1000], 'plunder_late': [12, 8, 15]},
}
def space(power):
    return {**COMMON, **SPECIFIC.get(power, {})}
def defaults(power):
    return {k: values[0] for k, values in space(power).items()}
def slug(power):
    return power.lower().replace(' ', '_')

"""Power-specific Grant 6 policy search and six-player simulation."""

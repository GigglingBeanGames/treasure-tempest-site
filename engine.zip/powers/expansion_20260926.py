"""Isolated expansion simulation. Import only in expansion evaluation processes."""
import collections,inspect,textwrap
import simulator
from simulator import BASE,TREASURE,CURSES,HAZARDS
from powers.config import POWERS,defaults
from powers.revision28 import Revision28Game,Revision28Actor,QueenGrant2Actor
from powers.multi import SeatContext
from powers.engine import ExperimentGame
from webgame.game import InteractiveGame,HumanView,CARD_NAMES

# Dictionaries are shared by the existing engine modules in this process only.
BASE.update(idol=2,spoils=1,escape=2,heart=1,spyglass=1,crown=1,fortune=1)
TREASURE['fortune']=200;CURSES['spoils']=100
POWERS.update({'Sea Witch':5,'Ghost Captain':1})
CARD_NAMES.update(spoils='Cursed Spoils',heart='Heart of the Sea',spyglass='Spyglass',fortune='Lost Fortune')

class KnowledgeMixin:
 @property
 def remaining(self):
  counts=super().remaining.copy();world=self.expansion_world;p=self.p
  memory=world.bottom_memory[p] if world.bottom_memory else {}
  # Only exclude cards this captain privately knows are below the unknown region.
  for index,card in memory.items():
   if index<len(world.deck):counts[card]-=1
  counts=+counts
  if not counts and memory and len(world.deck)-1 in memory:
   return collections.Counter([memory[len(world.deck)-1]])
  return counts
 def expected_card(self,card,p=0):
  d,w,s=super().expected_card(card,p)
  effect=self.previous if card=='echo' else card
  if effect in HAZARDS and ('heart' in self.held[p] or self.expansion_world.powers[self.ids[p]]=='Ghost Captain'):s=0.
  return d,w,s
 def should_harbor(self,p=0):
  if self.expansion_world.powers[self.p]=='Ghost Captain':return self.expansion_world.ghost_decision(self.p)
  return super().should_harbor(p)
class ExpansionActor(KnowledgeMixin,Revision28Actor):pass
class ExpansionQueenActor(KnowledgeMixin,QueenGrant2Actor):pass

class ExpansionRules(Revision28Game):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs)
  queen=self.power_index.get('Siren Queen')
  if queen is not None:self.ships[queen]=7
 def queen_collects_from(self,p):return 'Siren Queen' in self.power_index
 def captain_collects_from(self,p):return 'Cursed Captain' in self.power_index
 def curse_marginal(self,effect):return CURSES[effect] if len(self.captain_cards)<2 else 0
 def collect_curse(self,p,effect,physical):
  if len(self.captain_cards)>=2:
   self.states[p]['power_stats']['excess_curses_discarded']+=1;return False
  return super().collect_curse(p,effect,physical)
 def hazard_immune(self,p,maroon=False,forecast=False):
  if self.powers[p]=='Siren Queen':
   return self.lock_kind=='song' and self.lock_remaining>0 if forecast or not self.in_draw else self.song_protected_draw
  return super().hazard_immune(p,maroon,forecast)
 def finish_round_rewards(self):
  p=self.power_index.get('Siren Queen')
  if p is not None:
   pairs=min(self.queen_markers['key'],self.queen_markers['chest']);gain=min(pairs,max(0,8-self.ships[p]))
   self.ships[p]+=gain;s=self.states[p]['power_stats'];s['queen_pairs_cashed']+=pairs;s['queen_ship_gained']+=gain
   self.queen_markers.clear();self.queen_inventory.clear()
  return super().finish_round_rewards()
 def resolved_card(self,p,card,effect,safe):
  markers=self.queen_markers;self.queen_markers=collections.Counter()
  try:return super().resolved_card(p,card,effect,safe)
  finally:self.queen_markers=markers

# Keep the existing complete draw ordering, replacing only the specified rules.
source=textwrap.dedent(inspect.getsource(Revision28Game.draw))
source=source.replace("if effect == 'diamond' and self.queen_collects_from(p):", "if False: # Queen no longer collects necklaces")
a=source.index("            while self.queen_markers['key']");b=source.index("    elif effect == 'siren':",a);source=source[:a]+source[b:]
source=source.replace("    elif effect == 'trick':", "    elif effect == 'heart':\n        hold = 'heart' not in self.held[p]\n        self.states[p]['power_stats']['hearts_drawn'] += 1\n    elif effect == 'spyglass':\n        self.spyglass(p)\n    elif effect == 'trick':")
source=source.replace("    elif effect in CURSES:\n", "    elif effect in CURSES:\n        witch = self.power_index.get('Sea Witch')\n        if witch is not None and self.status[witch] == 'active':\n            self.hexes += 1\n            self.states[witch]['power_stats']['hexes_collected'] += 1\n")
source=source.replace("        self.deck = self.discard;", "        self.bottom_memory = [{} for _ in self.ships]\n        self.deck = self.discard;")
source=source.replace("    elif effect == 'wave':\n", "    elif effect == 'wave':\n        self.bottom_memory = [{} for _ in self.ships]\n")
source=source.replace("    card = self.deck.pop();", "    for memory in self.bottom_memory:\n        memory.pop(len(self.deck)-1, None)\n    card = self.deck.pop();")
namespace={};exec(source,globals(),namespace);ExpansionRules.draw=namespace['draw']

class ExpansionGame(InteractiveGame,ExpansionRules):
 def __init__(self,*args,**kwargs):
  self.bottom_memory=[];self.hexes=0;self.expansion_stats=collections.Counter()
  super().__init__(*args,**kwargs)
  self.bottom_memory=[{} for _ in self.ships]
  for p,power in enumerate(self.powers):
   actor=ExpansionQueenActor(self,p) if power=='Siren Queen' else ExpansionActor(SeatContext(self,p),p)
   actor.expansion_world=self;self.views[p]=actor
  self.bot_human=self.views[0];self.views[0]=HumanView(self.bot_human,self)
 def setup_round(self):
  self.bottom_memory=[{} for _ in self.ships]
  super().setup_round()
 def queen_safe(self,p):return self.powers[p]=='Siren Queen' and self.lock_kind=='song' and self.lock_remaining>0
 def should_harbor(self,p):
  if self.queen_safe(p):return False
  if self.powers[p]=='Ghost Captain':return self.ghost_decision(p)
  if self.bottom_memory[p] and self.status[p]=='active' and not self.safe():
   self.states[p]['power_stats']['spyglass_informed_decisions']+=1
  return super().should_harbor(p)
 def harbor_value(self,p):return super().harbor_value(p)+(10 if 'heart' in self.held[p] else 0)
 def harbor(self,p,forced=False):
  if not forced and self.queen_safe(p):return
  before=self.status[p];heart='heart' in self.held[p]
  result=super().harbor(p,forced)
  if before=='active' and self.status[p]=='harbor' and heart:
   self.states[p]['power_stats']['heart_harbor_gold']+=10
  return result
 def dangerous_known_card(self,p,card,drawer):
  if self.queen_safe(p):return False
  return super().dangerous_known_card(p,card,drawer)
 def ghost_decision(self,p):
  if self.status[p]!='active' or self.safe() or self.blocks[p]:return False
  view=self.bot_human if p==0 else self.views[p]
  if self.chest==0:return False
  if self.round==15 and not view.projected_lead():return False
  if self.known[p] and self.dangerous_known_card(p,self.known[p][0],self.next_drawer()):return True
  counts=collections.Counter(self.known[p][:1]) if self.known[p] else view.remaining
  n=max(1,sum(counts.values()));gain=loss=0.
  for card,count in counts.items():
   d,w,s=view.expected_card(card,0);gain+=count*d/n;loss+=count*w/n
  risk=loss*self.chest*(.5 if 'escape' in self.held[p] else 1.)
  appetite=self.appetite[p]*1.35
  if self.gold[p]>=max(self.gold):appetite*=.65
  elif self.desperate(p):appetite*=1.5
  self.states[p]['power_stats']['ghost_risk_decisions']+=1
  return risk>max(4,gain+8)*appetite
 def spyglass(self,p):
  k=min(10,len(self.deck));cards=self.deck[:k];del self.deck[:k]
  treasures=[c for c in cards if c in TREASURE]
  chosen=max(treasures,key=lambda c:TREASURE[c]) if treasures else None
  if chosen:cards.remove(chosen)
  # Draw order: remaining treasures/events first, curses and hazards deepest.
  def value(c):
   if c=='surge':return 1000
   if c in TREASURE:return TREASURE[c]+100
   if c in HAZARDS:return -1000
   if c in CURSES:return -CURSES[c]-100
   return 0
  cards.sort(key=value)
  self.deck[:0]=cards
  if chosen:self.deck.append(chosen)
  shift=k-len(cards)
  self.bottom_memory=[{i-shift:c for i,c in m.items() if i>=k} for m in self.bottom_memory]
  self.bottom_memory[p].update(dict(enumerate(cards)))
  self.known=[[] for _ in self.ships]
  if chosen:self.known[p]=[chosen]
  s=self.states[p]['power_stats'];s['spyglass_uses']+=1;s['spyglass_treasures_lifted']+=bool(chosen)
  s['spyglass_hazards_buried']+=sum(c in HAZARDS for c in cards);s['spyglass_surges_buried']+=cards.count('surge')
  if chosen:s['spyglass_lifted_'+chosen]+=1
 def bot_prophecy(self,p,token=False):
  length=len(self.deck);k=min(2,length)
  result=super().bot_prophecy(p,token)
  bottom=k-len(self.known[p])
  self.bottom_memory=[{i+bottom:c for i,c in m.items() if i<length-k} for m in self.bottom_memory]
  if bottom>0:self.bottom_memory[p].update({i:self.deck[i] for i in range(bottom)})
  return result
 def choose_echo(self,p):
  nav=self.power_index.get('Navigator')
  if nav is not None and self.status[nav]=='active' and p==nav:
   options=list(dict.fromkeys(reversed(self.history[-2:])))
   if 'surge' not in options and 'fortune' not in options and 'heart' in options and 'heart' not in self.held[nav] and self.ships[nav]<=2:return 'heart'
  return super().choose_echo(p)
 def resolved_card(self,p,card,effect,safe):
  self.expansion_stats['draw_'+card]+=1
  self.expansion_stats[('safe_' if safe else 'normal_')+effect]+=1
  for memory in self.bottom_memory:
   assert all(0<=i<len(self.deck) and self.deck[i]==c for i,c in memory.items()),'Spyglass memory corrupted'
  ghost=self.power_index.get('Ghost Captain')
  if ghost is not None:assert self.ships[ghost]==1
  return super().resolved_card(p,card,effect,safe)
 def play(self):
  super().play()
  witch=self.power_index.get('Sea Witch')
  if witch is not None:
   value=5*self.hexes
   for p in range(self.player_count):
    change=value if p==witch else -value
    self.gold[p]+=change;self.game_bonus[p]+=change
    self.states[p]['power_stats']['hex_endgame_gold']+=change
   self.power_gold[witch]+=value
  for p in range(self.player_count):
   assert abs(sum(r['round_gold'] for r in self.round_data if r['bot']==p)+self.game_bonus[p]+self.sell_gold[p]-self.gold[p])<1e-6
  high=max(self.gold);winners=[p for p,g in enumerate(self.gold) if g==high]
  return [1/len(winners) if p in winners else 0. for p in range(self.player_count)]

# Preserve all existing insurance/plunder/Blood Sailor hooks. Heart and Ghost
# restore the ship before any last-ship or game-end checks can observe a loss.
source=textwrap.dedent(inspect.getsource(InteractiveGame.sink))
source=source.replace("    repair=False;mechanic=", "    heart='heart' in self.held[p] and power!='Ghost Captain'\n    immortal=power=='Ghost Captain'\n    repair=False;mechanic=")
source=source.replace("if mechanic is not None and self.states[mechanic]['tokens']:","if mechanic is not None and self.states[mechanic]['tokens'] and not heart and not immortal:")
source=source.replace("    if repair:self.ships[p]=old", "    if repair or heart or immortal:self.ships[p]=old\n    if immortal:\n        state['power_stats']['ghost_ship_losses_prevented']+=1\n    if heart:\n        self.held[p].remove('heart')\n        state['power_stats']['heart_ship_saves']+=1\n        witch=self.power_index.get('Sea Witch')\n        if witch is not None and witch!=p:\n            self.ships[witch]+=1\n            self.states[witch]['power_stats']['witch_ships_gained']+=1")
namespace={};exec(source,globals(),namespace);ExpansionGame.sink=namespace['sink']

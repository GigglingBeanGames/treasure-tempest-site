"""Current rules and selected power bots, preserving historical experiment loaders."""
import hashlib,json
from pathlib import Path
from .revision28 import Revision28Game
from .engine import load_opponents,OUT6
from .config import POWERS,defaults,slug
ROOT=Path(__file__).resolve().parent.parent
BOT_DIRECTORY=ROOT/'experiments/power_bots_revision28'
POWER_NAMES=tuple('Cannoneer' if p=='Storm Swindler' else p for p in POWERS)

def load_current_bot(name):
    power=name.removesuffix(' bot')
    if power not in POWER_NAMES:raise ValueError(f'Unknown current power: {power}')
    bot=json.loads((BOT_DIRECTORY/slug(power)/(slug(power)+'_bot.json')).read_text())
    if hashlib.sha256(Path(bot['parent_policy']).read_bytes()).hexdigest()!=bot['parent_sha256']:
        raise ValueError('Parent policy no longer matches the selected bot')
    return bot

def make_current_game(seed,powers,opponents=None,versions=None,game_id=0):
    configs=[load_current_bot(p)['config'] if p else defaults(None) for p in powers]
    return Revision28Game(seed,powers,opponents or load_opponents(),configs,versions=versions,game_id=game_id)

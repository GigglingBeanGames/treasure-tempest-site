"""Second user-approved balance revision: limited insurance and replacement locks."""
import collections
from .balanced import BalancedGame, BalancedActor
from .multi import SeatContext
from .engine import Game, ExperimentGame, TournamentGame, TREASURE, CURSES, HAZARDS

class RevisionActor(BalancedActor):
    def preference_multiplier(self):
        value = super().preference_multiplier()
        if self.g.power == 'Storm Warden' and not self.g.world.use_warden_token(self.p):
            value /= self.g.config['insured_risk']
        return value

    def risk_harbor(self,boost=1.):
        # Same saved policy calculation with the revised rules represented.
        g = self.g; counts = collections.Counter(self.known[0][:1]) if self.known[0] else self.remaining
        n = sum(counts.values())
        if not n: return True
        gain = loss = shiprisk = 0.
        for card,count in counts.items():
            effect = g.world.choose_echo(self.p) if card == 'echo' and g.power == 'Navigator' else (self.previous if card == 'echo' else card)
            d,w,s = Game.expected_card(self,effect or 'echo',0)
            if g.power == 'Cursed Captain' and effect in CURSES: d += g.world.curse_marginal(effect)
            if g.power == 'Tempest King' and self.status.count('active') == 1 and effect in TREASURE: d *= 2
            if effect in HAZARDS and g.world.hazard_immune(self.p,effect == 'marooned',forecast=True): d,w,s = 0,0,0
            if g.power == 'Navigator' and g.protection and effect in HAZARDS: d,w,s = 0,0,0
            gain += count*d/n; loss += count*w/n; shiprisk += count*s/n
        ships = self.ships[0]
        value = 0. if self.round == 15 else (30+22*(16-self.round)/max(1,ships))*(1.55 if ships<=3 else 1)*(2 if ships==1 else 1)
        if g.power == 'Mechanic' and g.tokens: value *= .25
        lost_fraction = .5 if 'escape' in self.held[0] else 1.
        if g.power == 'Storm Warden' and g.world.use_warden_token(self.p): lost_fraction = 0. if 'escape' in self.held[0] else .5
        risk = loss*self.chest*lost_fraction+shiprisk*value
        if g.power == 'Merchant': risk += g.world.merchant_bonus*g.config['harbor_bonus_weight']*loss
        appetite = self.appetite[0]*(1.8 if self.desperate(0) else 1.)
        return risk > max(4,gain+8)*appetite*boost*self.preference_multiplier()

class RevisionGame(BalancedGame):
    repair_price = 100
    merchant_bonus = 25
    warden_maroon_penalty = 0
    starting_tokens = {'Mechanic':3,'Navigator':5,'Parrot Whisperer':5,'Undead Admiral':5,'Storm Warden':3}

    def __init__(self,*args,**kwargs):
        self.queen_markers = set()
        self.captain_cards = []
        self.lock_kind = None; self.lock_remaining = 0; self.cannon_blocks = []
        self.in_draw = False; self.song_protected_draw = False
        super().__init__(*args,**kwargs)
        self.cannon_blocks = [0]*self.player_count
        for p,power in enumerate(self.powers):
            if power == 'Storm Warden': self.ships[p] = 6
            if power: self.views[p] = RevisionActor(SeatContext(self,p),p)

    def setup_round(self):
        self.lock_kind = None; self.lock_remaining = 0
        self.cannon_blocks = [0]*self.player_count
        self.in_draw = False; self.song_protected_draw = False
        self.captain_cards = []
        for s in self.states: s['plunders_used'] = 0
        super().setup_round()
        queen = self.power_index.get('Siren Queen')
        if queen is not None and self.queen_markers:
            self.states[queen]['power_stats']['queen_rounds_with_carried_markers'] += 1

    def sync_blocks(self):
        admiral = self.power_index.get('Undead Admiral')
        self.blocks = [max(self.cannon_blocks[p],0 if self.lock_kind=='idol' and p==admiral else self.lock_remaining)
                       for p in range(self.player_count)]

    def replace_lock(self,kind,duration):
        self.lock_kind = kind; self.lock_remaining = duration
        self.sync_blocks()

    def hazard_immune(self,p,maroon=False,forecast=False):
        power = self.powers[p]
        if power == 'Navigator' and self.states[p]['protection']: return True
        if power in ('Storm Warden','Tempest King') and maroon: return True
        if power == 'Siren Queen':
            return (self.lock_kind=='song' and self.lock_remaining>0) if forecast or not self.in_draw else self.song_protected_draw
        return False

    def use_warden_token(self,p,ships_before=None):
        if not self.states[p]['tokens'] or self.chest <= 0: return False
        ships = self.ships[p] if ships_before is None else ships_before
        if self.round == 15 or ships <= 1: return True
        threshold = 200 if self.round >= 12 else 300
        if self.states[p]['tokens'] >= ships: threshold = 100
        return self.chest >= threshold

    def curse_marginal(self,effect):
        if len(self.captain_cards) < 4: return CURSES[effect]
        return max(0,CURSES[effect]-min(CURSES[e] for e,c in self.captain_cards))

    def collect_curse(self,p,effect,physical):
        stats = self.states[p]['power_stats']
        if len(self.captain_cards) < 4:
            self.captain_cards.append((effect,physical))
            self.award(p,CURSES[effect],'cursed_captain')
            return True
        old_effect,old_physical = min(self.captain_cards,key=lambda pair:CURSES[pair[0]])
        if CURSES[effect] > CURSES[old_effect]:
            self.captain_cards.remove((old_effect,old_physical))
            self.held[p].remove(old_effect); self.physical_held.remove(old_physical)
            self.discard.append(old_physical)
            self.captain_cards.append((effect,physical))
            self.award(p,CURSES[effect]-CURSES[old_effect],'captain_replacement')
            return True
        stats['captain_curses_rejected'] += 1
        return False

    def memory_reason(self,p):
        if self.status[p]=='active' and self.known[p]:
            effect = self.previous if self.known[p][0]=='echo' else self.known[p][0]
            if effect in HAZARDS and self.hazard_immune(p,effect=='marooned',forecast=True): return None
            if effect == 'rudder' and self.powers[p]=='Tempest King': return None
        return super().memory_reason(p)

    def harbor(self,p,forced=False):
        active = self.status[p]=='active'
        if active and self.powers[p]=='Siren Queen':
            if not forced: assert not self.safe() and not self.blocks[p]
            result = TournamentGame.harbor(self,p,forced)
        else: result = super().harbor(p,forced)
        return result

    def cannon(self,p):
        if self.powers[p]=='Tempest King':
            for j in list(self.seating):
                if j != p and self.status[j]=='active': self.harbor(j,True)
            self.cannon_blocks[p] = max(self.cannon_blocks[p],1)
            self.sync_blocks(); self.states[p]['power_stats']['king_cannon'] += 1
        else: super().cannon(p)

    def resolved_card(self,p,card,effect,safe):
        super().resolved_card(p,card,effect,safe)
        if self.powers[p]=='Siren Queen' and card in ('key','chest'):
            self.states[p]['power_stats']['queen_raw_'+card+('_calm' if safe else '_normal')] += 1
        assert len(self.captain_cards) <= 4
        assert all(s['plunders_used'] <= 2 for s in self.states)
        assert len(self.queen_markers) <= 2

    def sink(self,p,maroon=False):
        if self.status[p] != 'active': return
        power = self.powers[p]; state = self.states[p]
        if self.hazard_immune(p,maroon):
            state['power_stats']['hazards_ignored'] += 1
            if power == 'Siren Queen': state['power_stats']['queen_song_hazards_ignored'] += 1
            return
        repair = False; mechanic = self.power_index.get('Mechanic')
        if mechanic is not None and self.states[mechanic]['tokens']:
            s = self.states[mechanic]; c = self.configs[mechanic]
            if p == mechanic: repair = self.ships[p] <= c['repair_self_max_ships']
            elif self.repair_sales:
                mode = c['sell']
                offer = mode == 'always' or (mode == 'balanced' and (self.ships[mechanic] >= 3 or s['tokens'] > 1)) or (mode == 'reserve_two' and s['tokens'] > 2)
                value = 30+60*(15-self.round)/max(1,self.ships[p])
                repair = offer and self.gold[p] >= self.repair_price and value >= self.repair_price
                if offer: s['power_stats']['repair_offers'] += 1
                if repair: self.award(mechanic,self.repair_price,'repair_sale'); self.award(p,-self.repair_price,'repair_purchase')
            if repair:
                s['tokens'] -= 1; s['power_stats']['self_repairs' if p == mechanic else 'sold_repairs'] += 1
        old_ships = self.ships[p]
        ExperimentGame.sink(self,p,maroon)
        if repair: self.ships[p] = old_ships
        if power == 'Storm Warden' and self.use_warden_token(p,ships_before=old_ships):
            state['tokens'] -= 1
            self.award(p,self.chest/2,'warden_insurance')
            state['power_stats']['warden_insured_chest_total'] += self.chest
        elif power == 'Storm Warden':
            state['power_stats']['warden_uninsured_sinkings'] += 1
        blood = self.power_index.get('Blood Sailor')
        if blood is not None:
            s = self.states[blood]
            if p in s['targets']:
                self.award(blood,self.blood_payment,'blood_sink')
                if self.ships[p] == 0 and p not in s['rewarded_targets']:
                    s['rewarded_targets'].add(p)
                    self.ships[blood] += 1; s['power_stats']['blood_ship_gained'] += 1
        admiral = self.power_index.get('Undead Admiral')
        if admiral is not None:
            s = self.states[admiral]; c = self.configs[admiral]
            if s['tokens'] and s['plunders_used'] < 2 and (self.chest >= c['plunder_min_gold'] or (self.round >= c['plunder_late'] and self.chest > 100)):
                s['tokens'] -= 1; s['plunders_used'] += 1; self.award(admiral,self.chest*.1,'plunder')

    def draw(self,p):
        if not self.deck:
            if not self.discard: raise RuntimeError('No drawable cards')
            self.deck = self.discard; self.discard = []; self.rng.shuffle(self.deck)
            self.remaining = collections.Counter(self.deck+self.hidden_cards())
            self.known = [[] for _ in self.ships]
        safe = self.safe(); self.safe_next = False
        self.in_draw = True
        self.song_protected_draw = self.lock_kind == 'song' and self.lock_remaining > 0
        card = self.deck.pop(); self.remaining[card] -= 1
        for known in self.known:
            if known: known.pop(0)
        pending = list(self.pending)
        self.draws += 1; self.total_draws += 1; self.own_draws[p] += 1
        self.lock_remaining = max(0,self.lock_remaining-1)
        self.cannon_blocks = [max(0,x-1) for x in self.cannon_blocks]
        self.sync_blocks()
        effect = (self.echo_effect(p) if not safe else self.previous or 'echo') if card == 'echo' else card
        self.previous = effect; self.resolving = effect
        hold = False; holder = p; power = self.powers[p]
        swindler = self.power_index.get('Storm Swindler')
        captain = self.power_index.get('Cursed Captain')
        admiral = self.power_index.get('Undead Admiral')
        queen = self.power_index.get('Siren Queen')
        if safe:
            self.calm_cards[card] += 1
            self.chest += TREASURE.get(card,50 if card in HAZARDS else 0 if card in CURSES else 10)
        elif effect in TREASURE:
            if swindler is not None and not self.states[swindler]['stolen_treasure']:
                self.states[swindler]['stolen_treasure'] = True; hold = True; holder = swindler
                self.award(swindler,TREASURE[effect],'swindler_treasure')
            else: self.chest += TREASURE[effect]*(2 if power == 'Tempest King' and self.status.count('active') == 1 else 1)
        elif effect in CURSES:
            if captain is not None:
                hold = self.collect_curse(captain,effect,card); holder = captain
            if p != captain or not self.captain_immune: self.chest = max(0,self.chest-CURSES[effect])
            if admiral is not None and effect == 'idol':
                self.replace_lock('idol',3)
                self.states[admiral]['power_stats']['admiral_idol_blocks'] += 1
        elif effect == 'surge': self.chest = self.chest*2 if self.chest else 100
        elif effect in ('key','chest'):
            self.safe_next = True
            if p == queen:
                hold = True
                self.states[p]['power_stats']['queen_personal_'+effect+'_effects'] += 1
                if effect not in self.queen_markers:
                    self.queen_markers.add(effect)
                    self.states[p]['power_stats']['queen_collected_'+effect] += 1
                    if len(self.queen_markers) == 2:
                        self.queen_markers.clear()
                        self.states[p]['power_stats']['queen_pairs_cashed'] += 1
                        if self.ships[p] < 8:
                            self.ships[p] += 1
                            self.states[p]['power_stats']['queen_ship_gained'] += 1
                        else:
                            self.states[p]['power_stats']['queen_pairs_at_ship_cap'] += 1
        elif effect == 'siren':
            self.replace_lock('song',4)
        elif effect == 'whirlpool':
            # Whole card resolves before elimination/game-end checks.
            for j in range(self.player_count): self.sink(j)
        elif effect == 'marooned':
            immune = self.hazard_immune(p,True)
            self.sink(p,True); hold = not immune
            if not immune: self.marooned_players.add(p)
        elif effect == 'rudder':
            if power not in ('Mechanic','Tempest King'): self.harbor(p,True); self.gold[p] -= 30; hold = True
            else: self.states[p]['power_stats']['rudder_ignored'] += 1
        elif effect == 'escape': hold = 'escape' not in self.held[p]
        elif effect == 'trick':
            amount = 40 if power == 'Storm Swindler' else 20
            self.chest = max(0,self.chest-amount); self.gold[p] += amount; hold = True
            if amount == 40:
                self.power_gold[p] += 20; self.states[p]['power_stats']['swindler_extra_trick_gold'] += 20
        elif effect == 'wave':
            self.deck.extend(self.discard); self.discard = []; self.rng.shuffle(self.deck)
            self.remaining = collections.Counter(self.deck+self.hidden_cards())
            self.known = [[] for _ in self.ships]; self.wants = [False]*self.player_count
            self.safe_next = True; self.gold[p] += 10; hold = True
        elif effect == 'prophecy':
            parrot = self.power_index.get('Parrot Whisperer')
            if parrot is not None:
                s = self.states[parrot]; before = s['tokens']; s['tokens'] = min(10,s['tokens']+1)
                s['power_stats']['parrot_tokens_gained'] += s['tokens']-before
            self.prophecy(p)
        elif effect == 'cannon': self.cannon(p)
        if hold: self.held[holder].append(effect); self.physical_held.append(card)
        else: self.discard.append(card)
        if not safe and effect == 'surge': self.last_surge = self.draws; self.followup_exits = [False]*self.player_count
        for j,s in enumerate(self.states):
            if pending[j]: self.followup_exits[j] = not(card == 'echo' and not safe and effect == 'surge'); self.pending[j] = False
            if s['protection']: s['protection'] -= 1
        if self.chest >= 9999:
            self.chest = 9999
            for j in range(self.player_count): self.harbor(j,True)
        self.resolved_card(p,card,effect,safe)
        self.in_draw = False
        if not self.lock_remaining: self.lock_kind = None
        self.sync_blocks()
        self.check_end()


"""Expansion revision 2: +/-10 Hexes and 30 gold per Ghost sinking.
The prior evaluation module and its results remain unchanged.
"""
from powers.expansion_20260926 import ExpansionGame

class ExpansionGameV2(ExpansionGame):
    def sink(self, p, maroon=False):
        was_active = self.status[p] == 'active'
        result = super().sink(p, maroon)
        if was_active and self.status[p] == 'sunk' and self.powers[p] == 'Ghost Captain':
            self.award(p, 30, 'ghost_sinking_bonus')
        return result

    def play(self):
        super().play()  # Prior rules settle the first +/-5 per Hex.
        witch = self.power_index.get('Sea Witch')
        if witch is not None:
            additional = 5 * self.hexes
            for p in range(self.player_count):
                change = additional if p == witch else -additional
                self.gold[p] += change
                self.game_bonus[p] += change
                self.states[p]['power_stats']['hex_endgame_gold'] += change
            self.power_gold[witch] += additional
        for p in range(self.player_count):
            assert abs(sum(r['round_gold'] for r in self.round_data if r['bot'] == p) + self.game_bonus[p] + self.sell_gold[p] - self.gold[p]) < 1e-6
        best = max(self.gold)
        winners = [p for p,gold in enumerate(self.gold) if gold == best]
        return [1/len(winners) if p in winners else 0. for p in range(self.player_count)]

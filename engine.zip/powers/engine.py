"""One powered Grant 6 against two to five frozen Grants, with explicit rule hooks.

The learner only receives public counts and its own legally acquired knowledge.
Physical cards are conserved separately from Echo's copied effect identity.
"""
import collections
import itertools
from simulator import Game, TREASURE, CURSES, HAZARDS
from grant2 import ExperimentGame, FrozenGrant
from grant3 import FixedGrant2, revised_plan
from grant6 import Actor6, TUNING6, NeutralLifeView, OUT6
from tournament import TournamentGame, PATHS
from .config import POWERS, defaults


def load_opponents():
    return {**{v: FixedGrant2(p) for v, p in PATHS.items()},
            6: FixedGrant2(OUT6 / 'grant6_policy.json')}


class SixActor(Actor6):
    @property
    def settings(self):
        return self.g.actor_settings[self.p]


class PowerActor(SixActor):
    @property
    def block(self):
        return self.g.blocks[self.p]

    @property
    def remaining(self):
        counts = self.g.remaining.copy()
        # Other players know one card is withheld, but not its identity.
        if self.g.secret is not None:
            counts[self.g.secret] -= 1
        return counts

    def harbor_value(self, p=0):
        return self.g.harbor_value(self.ids[p])

    def preference_multiplier(self):
        g = self.g; c = g.config; power = g.power
        m = super().preference_multiplier() * c['risk']
        if self.leading(): m *= c['lead']
        if power == 'Blood Sailor' and any(g.status[j] == 'active' for j in g.targets): m *= c['target_risk']
        if power == 'Cursed Captain': m *= c['curse_appetite']
        if power == 'Storm Swindler': m *= c['trick_appetite']
        if power == 'Storm Warden': m *= c['insured_risk']
        if power == 'Tempest King' and self.status.count('active') == 1: m *= c['alone_risk']
        if power == 'Navigator' and g.protection: m *= c['protected_risk']
        if power == 'Siren Queen' and ('key' in self.held[0]) != ('chest' in self.held[0]): m *= c['pair_appetite']
        return m

    def risk_harbor(self, boost=1.):
        g = self.g; counts = collections.Counter(self.known[0][:1]) if self.known[0] else self.remaining
        n = sum(counts.values())
        if not n: return True
        gain = loss = shiprisk = 0.
        for card, count in counts.items():
            d, w, s = Game.expected_card(self, card, 0)
            effect = self.previous if card == 'echo' else card
            if g.power == 'Cursed Captain' and effect in CURSES: d = CURSES[effect]
            if g.power == 'Tempest King' and self.status.count('active') == 1 and effect in TREASURE: d *= 2
            if g.power == 'Storm Warden' and effect == 'marooned': s = 0
            if g.power == 'Navigator' and g.protection and effect in HAZARDS: w = s = 0
            gain += count * d / n; loss += count * w / n; shiprisk += count * s / n
        ships = self.ships[0]
        value = 0. if self.round == 15 else (30 + 22 * (16-self.round) / max(1, ships)) * (1.55 if ships <= 3 else 1) * (2 if ships == 1 else 1)
        if g.power == 'Mechanic' and g.tokens: value *= .25
        lost_fraction = .5 if 'escape' in self.held[0] else 1.
        if g.power == 'Storm Warden': lost_fraction = 0. if 'escape' in self.held[0] else .5
        risk = loss * self.chest * lost_fraction + shiprisk * value
        if g.power == 'Merchant': risk += 20 * g.config['harbor_bonus_weight'] * loss
        appetite = self.appetite[0] * (1.8 if self.desperate(0) else 1.)
        return risk > max(4, gain+8) * appetite * boost * self.preference_multiplier()

    def should_harbor(self, p=0):
        g = self.g
        if self.status[0] != 'active' or self.safe() or self.block: return False
        mode = g.config['mode']
        # Defaults preserve Grant 6's decision order and learned settings.
        if mode == 'inherit' and (g.config['last_life'] == 'inherit' or self.ships[0] != 1):
            return super().should_harbor(0)
        if self.chest == 0: return False
        if self.round == 15 and not self.projected_lead(): return False
        reason = self.memory_reason(0)
        if reason: return self.record_decision(True, reason)
        if self.ships[0] == 1 and self.round < 15 and g.config['last_life'] == 'inherit': return True
        boost = {'inherit': 1., 'power_risk': 1., 'patient': 1.8, 'cautious': .55}[mode]
        if self.leading() and self.others_harbored() and self.rng.random() < min(1., self.settings['alone_lead_harbor'] / g.config['lead']): return True
        return self.record_decision(self.risk_harbor(boost), 'power_risk')


class PowerGame(TournamentGame):
    def __init__(self, seed, power, opponents, config=None, game_id=0, repair_sales=True, revive_blood=True, opponent_versions=None):
        versions = list(opponent_versions) if opponent_versions is not None else [2,3,4,5,6]
        if not 2 <= len(versions) <= 5 or any(v not in (2,3,4,5,6) for v in versions):
            raise ValueError('Provide two to five opponent versions from Grants 2–6')
        versions.append(6)
        self.player_count = len(versions); self.owner = self.player_count-1
        self.six_players = tuple(p for p,v in enumerate(versions) if v == 6)
        self.power = power; self.config = config or defaults(power)
        self.blocks = [0]*self.player_count; self.secret = None
        self.actor_settings = {p: {k: v['original'] for k, v in TUNING6.items()} for p in self.six_players}
        super().__init__(seed, versions, [opponents[v] for v in versions], FrozenGrant(), game_id=game_id)
        for p in self.six_players: self.views[p] = SixActor(self,p)
        if power: self.views[self.owner] = PowerActor(self,self.owner)
        self.ships[self.owner] = POWERS.get(power,6)
        self.tokens = {'Mechanic':3,'Navigator':5,'Parrot Whisperer':2,'Undead Admiral':4}.get(power,0)
        self.power_stats = collections.Counter(); self.power_gold = [0.]*self.player_count
        self.targets = None; self.rewarded_targets = set()
        self.protection = 0; self.used_round = False; self.peek_at = None
        self.repair_sales = repair_sales; self.revive_blood = revive_blood

    @property
    def block(self): return self.blocks[0]
    @block.setter
    def block(self, value): self.blocks = [value]*self.player_count

    def setup_round(self):
        self.secret = None; self.protection = 0; self.used_round = False; self.peek_at = None
        self.stolen_treasure = False
        super().setup_round()
        if self.targets is None:
            at = self.seating.index(self.owner)
            self.targets = {self.seating[(at-1)%self.player_count], self.seating[(at+1)%self.player_count]}
        for p in self.six_players:
            if self.status[p] != 'active': continue
            view = NeutralLifeView(self.views[p]) if self.round == 15 else self.views[p]
            for name, choices in TUNING6.items():
                label = self.policies[p].choose('tune_'+name, view, ['original']+[k for k in choices if k != 'original'])
                self.actor_settings[p][name] = choices[label]
        if self.power == 'Tide Watcher':
            card = self.deck.pop()
            if card in TREASURE:
                self.remaining[card] -= 1; self.held[self.owner].append(card); self.physical_held.append(card)
                self.award(self.owner,TREASURE[card],'tide_treasure')
            else:
                self.secret = card
                self.power_stats['tide_hidden_cards'] += 1

    def award(self, p, amount, reason):
        self.gold[p] += amount; self.power_gold[p] += amount
        self.power_stats[reason+'_uses'] += 1; self.power_stats[reason+'_gold'] += amount

    def harbor_value(self,p):
        return Game.harbor_value(self,p) + (20 if p == self.owner and self.power == 'Merchant' else 0)

    def harbor(self,p,forced=False):
        if self.status[p] != 'active': return
        if not forced:
            assert not self.safe() and not self.blocks[p]
        super().harbor(p,forced)
        if p == self.owner and self.power == 'Merchant':
            self.power_gold[p] += 20; self.power_stats['merchant_harbor_uses'] += 1; self.power_stats['merchant_harbor_gold'] += 20
        if p == self.owner and self.power == 'Siren Queen' and 'key' in self.held[p] and 'chest' in self.held[p] and self.ships[p] < 8:
            self.ships[p] += 1; self.power_stats['queen_ship_gained'] += 1

    def memory_reason(self,p):
        if p != self.owner or not self.power: return super().memory_reason(p)
        if self.status[p] != 'active': return None
        known = self.known[p]
        if known:
            card = self.previous if known[0] == 'echo' else known[0]
            if self.power == 'Navigator' and self.protection and card in HAZARDS: return None
            if self.power == 'Storm Warden' and card == 'marooned': return None
            if self.power == 'Mechanic' and card == 'rudder': return None
        return super().memory_reason(p)

    def power_window(self):
        if self.status[self.owner] != 'active' or self.draws < 3: return
        c = self.config; v = self.views[self.owner]
        if self.power == 'Parrot Whisperer' and self.tokens > c['peek_reserve'] and not self.known[self.owner] and self.deck and self.peek_at != self.draws:
            if self.chest >= c['peek_min_chest'] or self.ships[self.owner] <= c['peek_max_ships'] or self.round == 15:
                self.tokens -= 1; self.known[self.owner] = [self.deck[-1]]; self.peek_at = self.draws
                self.power_stats['parrot_peeks'] += 1
        if self.power == 'Navigator' and self.tokens and not self.used_round and not self.safe():
            _,_,_,w = v.odds(); counts = v.remaining; n = max(1,sum(counts.values()))
            danger = w + counts['marooned']/n * (self.next_drawer() == self.owner)
            if self.known[self.owner]: danger = float(self.known[self.owner][0] == 'whirlpool' or (self.known[self.owner][0] == 'marooned' and self.next_drawer() == self.owner))
            if danger >= c['nav_risk'] and (self.chest >= c['nav_min_chest'] or self.ships[self.owner] <= c['nav_max_ships']):
                self.tokens -= 1; self.protection = 3; self.used_round = True; self.power_stats['navigator_tokens'] += 1
        if self.power == 'Tide Watcher' and self.secret and self.draws >= 3:
            card = self.secret; mode = c['tide']; use = mode == 'immediate'
            if mode in ('useful','attack'):
                if self.safe(): use = card in HAZARDS or card in CURSES
                elif card == 'whirlpool': use = (not self.blocks[self.owner] and self.chest >= c['tide_min_chest'] and not self.refuse_exit(self.owner))
                elif card in ('marooned','rudder'): use = self.next_drawer() != self.owner
                elif card in ('surge','key','chest','wave'): use = mode == 'useful' and self.chest >= c['tide_min_chest']
                elif card in ('escape','prophecy','trick','cannon'): use = self.next_drawer() == self.owner
                elif card in CURSES: use = mode == 'attack' and self.gold[self.owner] > max(x for j,x in enumerate(self.gold) if j != self.owner)
                elif card == 'siren': use = mode == 'attack' and self.chest <= c['tide_min_chest']
                elif card == 'echo': use = self.previous == 'surge'
            if use:
                self.deck.append(card); self.secret = None; self.known = [[] for _ in self.ships]; self.known[self.owner] = [card]; self.wants = [False]*self.player_count
                self.power_stats['tide_played_'+card] += 1

    def windows(self,current):
        self.power_window()
        before = {p:self.views[p].others_harbored() for p in self.six_players}
        self.window_id += 1; self.left_this_window = set(); self.leader_left = False
        self.window_leaders = {p for p in range(self.player_count) if self.gold[p] == max(self.gold)}
        Game.windows(self,current)
        for p in range(self.player_count):
            if self.memory_reason(p) and not self.safe() and not self.blocks[p] and not self.refuse_exit(p): self.harbor(p)
        for p in self.six_players:
            v = self.views[p]
            if not before[p] and v.others_harbored() and v.leading() and self.status[p] == 'active' and not self.safe() and not self.blocks[p]:
                if v.should_harbor(): self.harbor(p)

    def sink(self,p,maroon=False):
        if self.status[p] != 'active': return
        if p == self.owner and ((self.power == 'Navigator' and self.protection) or (self.power == 'Storm Warden' and maroon)):
            self.power_stats['hazards_ignored'] += 1; return
        repair = False
        if self.power == 'Mechanic' and self.tokens:
            if p == self.owner:
                repair = self.ships[p] <= self.config['repair_self_max_ships']
            elif self.repair_sales:
                mode = self.config['sell']
                offer = mode == 'always' or (mode == 'balanced' and (self.ships[self.owner] >= 3 or self.tokens > 1)) or (mode == 'reserve_two' and self.tokens > 2)
                # New purchase decision only; opponent sailing policies stay fixed.
                value = 30 + 60*(15-self.round)/max(1,self.ships[p])
                accept = self.gold[p] >= 150 and value >= 150
                repair = offer and accept
                if offer: self.power_stats['repair_offers'] += 1
                if repair: self.award(self.owner,150,'repair_sale'); self.award(p,-150,'repair_purchase')
            if repair:
                self.tokens -= 1; self.power_stats['self_repairs' if p == self.owner else 'sold_repairs'] += 1
        old_ships = self.ships[p]
        # A repaired sinking is still a sinking: no harbor gold, and sink powers fire.
        super().sink(p,maroon)
        if repair: self.ships[p] = old_ships
        if p == self.owner and self.power == 'Storm Warden': self.award(p,self.chest/2,'warden_insurance')
        if self.power == 'Blood Sailor' and p in self.targets:
            self.award(self.owner,40,'blood_sink')
            if self.ships[p] == 0 and p not in self.rewarded_targets:
                self.rewarded_targets.add(p)
                if self.ships[self.owner] or self.revive_blood:
                    self.ships[self.owner] += 1; self.power_stats['blood_ship_gained'] += 1
        if self.power == 'Undead Admiral' and self.tokens and not self.used_round:
            if self.chest >= self.config['plunder_min_gold'] or (self.round >= self.config['plunder_late'] and self.chest > 100):
                self.tokens -= 1; self.used_round = True; self.award(self.owner,self.chest*.1,'plunder')

    def cannon(self,p):
        if p != self.owner or not self.power: return super().cannon(p)
        eligible = [j for j in self.seating if j != p and self.status[j] == 'active']
        if self.power == 'Tempest King':
            for j in eligible: self.harbor(j,True)
            self.blocks[p] += 1; self.power_stats['king_cannon'] += 1; return
        if not eligible: return
        mode = self.config['cannon']
        if mode == 'ships': target = max(eligible,key=lambda j:self.ships[j])
        elif mode == 'fewest': target = min(eligible,key=lambda j:self.ships[j])
        elif mode == 'power' and self.power == 'Blood Sailor': target = max(eligible,key=lambda j:(j not in self.targets,self.gold[j]))
        else: target = max(eligible,key=lambda j:self.gold[j])
        self.harbor(target,True)

    def prophecy(self,p):
        if p != self.owner or not self.power: return super().prophecy(p)
        k = min(3 if self.power == 'Parrot Whisperer' else 2,len(self.deck))
        if not k: return
        cards = list(reversed(self.deck[-k:])); mode = self.config['prophecy']
        if mode == 'inherit' and k <= 2:
            order,bottom,leave = revised_plan(cards,self.status.count('active'),bool(self.blocks[p]))
        else:
            options = [(list(x),None) for x in sorted(set(itertools.permutations(cards)))]
            for i in range(k):
                rest = cards[:i]+cards[i+1:]
                if rest: options += [(list(x),cards[i]) for x in sorted(set(itertools.permutations(rest)))]
            def value(card, recipient):
                own = recipient == self.owner
                if card == 'whirlpool': return -1000 if self.blocks[self.owner] else -200
                if card in ('marooned','rudder'):
                    immune = own and ((card == 'marooned' and self.power == 'Storm Warden') or (card == 'rudder' and self.power == 'Mechanic'))
                    return 0 if immune else (-500 if own else 100 if mode != 'safe' else -20)
                if card in CURSES: return CURSES[card] if self.power == 'Cursed Captain' else -CURSES[card]
                if card == 'siren': return 30 if self.power == 'Siren Queen' else -80
                if card == 'surge': return 300 if mode == 'surge' else 100
                if card in TREASURE: return TREASURE[card]
                if card in ('escape','trick','prophecy','cannon'): return 90 if own else -20
                if card in ('key','chest'): return 150 if own and self.power == 'Siren Queen' else 35
                return 20
            active = [j for j in self.seating if self.status[j] == 'active']; at = active.index(p)
            def score(option):
                order,bottom = option
                return sum(value(card,active[(at+i+1)%len(active)])/(i+1) for i,card in enumerate(order))
            order,bottom = max(options,key=score); leave = False
        del self.deck[-k:]
        if bottom: self.deck.insert(0,bottom)
        self.deck.extend(reversed(order)); self.known = [[] for _ in self.ships]; self.known[p] = order.copy(); self.wants = [False]*self.player_count; self.wants[p] = leave
        self.power_stats['prophecy_uses'] += 1
        self.power_stats['prophecy_top_'+order[0]] += 1
        if bottom: self.power_stats['prophecy_bottom_'+bottom] += 1

    def draw(self,p):
        if not self.deck:
            if not self.discard: raise RuntimeError('No drawable cards')
            self.deck = self.discard; self.discard = []; self.rng.shuffle(self.deck)
            self.remaining = collections.Counter(self.deck)
            if self.secret: self.remaining[self.secret] += 1
            self.known = [[] for _ in self.ships]
        safe = self.safe(); self.safe_next = False
        card = self.deck.pop(); self.remaining[card] -= 1
        for known in self.known:
            if known: known.pop(0)
        pending = list(self.pending)
        self.draws += 1; self.total_draws += 1; self.own_draws[p] += 1
        self.blocks = [max(0,x-1) for x in self.blocks]
        effect = (self.previous or 'echo') if card == 'echo' else card
        self.previous = effect; self.resolving = effect
        hold = False; holder = p
        if safe:
            self.calm_cards[card] += 1
            self.chest += TREASURE.get(card,50 if card in HAZARDS else 0 if card in CURSES else 10)
        elif effect in TREASURE:
            if self.power == 'Storm Swindler' and not self.stolen_treasure:
                self.stolen_treasure = True; hold = True; holder = self.owner; self.award(self.owner,TREASURE[effect],'swindler_treasure')
            else: self.chest += TREASURE[effect] * (2 if self.power == 'Tempest King' and p == self.owner and self.status.count('active') == 1 else 1)
        elif effect in CURSES:
            if self.power == 'Cursed Captain':
                hold = True; holder = self.owner; self.award(self.owner,CURSES[effect],'cursed_captain')
            if not (self.power == 'Cursed Captain' and p == self.owner): self.chest = max(0,self.chest-CURSES[effect])
            if self.power == 'Undead Admiral' and effect == 'idol':
                self.blocks = [x+3 if j != self.owner else x for j,x in enumerate(self.blocks)]
                self.power_stats['admiral_idol_blocks'] += 1
        elif effect == 'surge': self.chest = self.chest*2 if self.chest else 100
        elif effect in ('key','chest'):
            self.safe_next = True
            if self.power == 'Siren Queen' and p == self.owner: hold = True
        elif effect == 'siren':
            duration = 8 if self.power == 'Siren Queen' and p == self.owner else 4
            self.blocks = [x if j == self.owner and self.power == 'Siren Queen' else x+duration for j,x in enumerate(self.blocks)]
        elif effect == 'whirlpool':
            for j in range(self.player_count): self.sink(j)
        elif effect == 'marooned':
            immune = p == self.owner and ((self.power == 'Navigator' and self.protection) or self.power == 'Storm Warden')
            self.sink(p,True); hold = not immune
            if not immune: self.marooned_players.add(p)
        elif effect == 'rudder':
            if not (p == self.owner and self.power == 'Mechanic'):
                self.harbor(p,True); self.gold[p] -= 30; hold = True
            else: self.power_stats['rudder_ignored'] += 1
        elif effect == 'escape': hold = 'escape' not in self.held[p]
        elif effect == 'trick':
            amount = 40 if p == self.owner and self.power == 'Storm Swindler' else 20
            self.chest = max(0,self.chest-amount); self.gold[p] += amount; hold = True
            if amount == 40: self.power_gold[p] += 20; self.power_stats['swindler_extra_trick_gold'] += 20
        elif effect == 'wave':
            self.deck.extend(self.discard); self.discard = []; self.rng.shuffle(self.deck)
            self.remaining = collections.Counter(self.deck)
            if self.secret: self.remaining[self.secret] += 1
            self.known = [[] for _ in self.ships]; self.wants = [False]*self.player_count
            self.safe_next = True; self.gold[p] += 10; hold = True
        elif effect == 'prophecy':
            if self.power == 'Parrot Whisperer':
                before = self.tokens; self.tokens = min(10,self.tokens+1); self.power_stats['parrot_tokens_gained'] += self.tokens-before
            self.prophecy(p)
        elif effect == 'cannon': self.cannon(p)
        if hold: self.held[holder].append(effect); self.physical_held.append(card)
        else: self.discard.append(card)
        if not safe and effect == 'surge': self.last_surge = self.draws; self.followup_exits = [False]*self.player_count
        for j in range(self.player_count):
            if pending[j]: self.followup_exits[j] = not(card == 'echo' and not safe and effect == 'surge'); self.pending[j] = False
        if self.protection: self.protection -= 1
        if self.chest >= 9999:
            self.chest = 9999
            for j in range(self.player_count): self.harbor(j,True)
        self.check_end()

    def play(self):
        while self.round < 15 and not self.ended:
            self.setup_round(); cursor = 0
            while 'active' in self.status and not self.ended:
                while self.status[self.seating[cursor]] != 'active': cursor = (cursor+1)%self.player_count
                self.current = self.seating[cursor]; self.windows(self.current)
                if 'active' not in self.status: break
                if self.status[self.current] == 'active': self.draw(self.current)
                cursor = (cursor+1)%self.player_count
                if self.draws > 10000: raise RuntimeError('Round safety bound')
            assert collections.Counter(self.deck+self.discard+self.physical_held+([self.secret] if self.secret else [])) == self.initial_counts
            for p in range(self.player_count):
                self.round_data.append({'game':self.game_id,'round':self.round,'bot':p,'seat':self.seating.index(p),
                    'round_gold':self.gold[p]-self.round_begin[p]-self.round_bonus[p], 'harbor_gold':self.harbor_gold[p],
                    'additional_gold':self.gold[p]-self.round_begin[p]-self.round_bonus[p]-self.harbor_gold[p],
                    'ships_start':self.round_ships[p], 'ships_end':self.ships[p], 'status':self.status[p],
                    'round_draws':self.draws,'own_draws':self.own_draws[p]})
        if not self.ended:
            most = max(self.ships)
            if self.ships.count(most) == 1:
                p = self.ships.index(most); self.gold[p] += 100; self.game_bonus[p] += 100
        for p in range(self.player_count):
            self.sell_gold[p] = self.ships[p]*(50 if p == self.owner and self.power == 'Merchant' else 30)
            self.gold[p] += self.sell_gold[p]
        if self.power == 'Merchant':
            premium = self.ships[self.owner]*20
            self.power_gold[self.owner] += premium; self.power_stats['merchant_ship_premium_gold'] += premium
        token_value = {'Mechanic':30,'Parrot Whisperer':10,'Undead Admiral':10}.get(self.power,0)
        if token_value:
            amount = self.tokens*token_value; self.gold[self.owner] += amount; self.game_bonus[self.owner] += amount
            self.power_gold[self.owner] += amount; self.power_stats['token_sale_gold'] += amount
        for p in range(self.player_count):
            assert abs(sum(r['round_gold'] for r in self.round_data if r['bot'] == p)+self.game_bonus[p]+self.sell_gold[p]-self.gold[p]) < 1e-6
        best = max(self.gold); winners = [p for p,x in enumerate(self.gold) if abs(x-best) < 1e-8]
        return [1/len(winners) if p in winners else 0. for p in range(self.player_count)]

"""Mixed-roster expansion: Witch Heart tokens replace her old life-gain passive."""
import inspect,textwrap
from powers.expansion_v2_20260926 import ExpansionGameV2
from powers.expansion_20260926 import InteractiveGame,ExperimentGame

class ExpansionGameV3(ExpansionGameV2):
 def __init__(self,*args,**kwargs):
  self.witch_hearts=0
  super().__init__(*args,**kwargs)
 def resolved_card(self,p,card,effect,safe):
  witch=self.power_index.get('Sea Witch')
  if witch is not None and effect=='heart' and not safe:
   stats=self.states[witch]['power_stats'];stats['heart_token_triggers']+=1
   if self.witch_hearts<3:
    self.witch_hearts+=1;stats['heart_tokens_gained']+=1
   else:stats['heart_tokens_overflow']+=1
  assert 0<=self.witch_hearts<=3
  return super().resolved_card(p,card,effect,safe)
 def play(self):
  super().play()
  witch=self.power_index.get('Sea Witch')
  if witch is not None:
   value=10*self.witch_hearts
   self.gold[witch]+=value;self.game_bonus[witch]+=value;self.power_gold[witch]+=value
   self.states[witch]['power_stats']['heart_tokens_remaining']=self.witch_hearts
   self.states[witch]['power_stats']['heart_token_endgame_gold']=value
  for p in range(self.player_count):
   assert abs(sum(r['round_gold'] for r in self.round_data if r['bot']==p)+self.game_bonus[p]+self.sell_gold[p]-self.gold[p])<1e-6
  best=max(self.gold);n=sum(g==best for g in self.gold)
  return [1/n if g==best else 0. for g in self.gold]

# Restore ships before elimination and Blood Sailor hooks; use an expiring held
# Heart first, otherwise spend a persistent token on every real sinking.
source=textwrap.dedent(inspect.getsource(InteractiveGame.sink))
source=source.replace('    repair=False;mechanic=',"    heart='heart' in self.held[p] and power!='Ghost Captain'\n    immortal=power=='Ghost Captain'\n    heart_token=power=='Sea Witch' and self.witch_hearts>0 and not heart\n    repair=False;mechanic=")
source=source.replace("if mechanic is not None and self.states[mechanic]['tokens']:","if mechanic is not None and self.states[mechanic]['tokens'] and not heart and not immortal and not heart_token:")
source=source.replace('    if repair:self.ships[p]=old',"    if repair or heart or immortal or heart_token:self.ships[p]=old\n    if immortal:\n        state['power_stats']['ghost_ship_losses_prevented']+=1\n        self.award(p,30,'ghost_sinking_bonus')\n    if heart:\n        self.held[p].remove('heart')\n        state['power_stats']['heart_ship_saves']+=1\n    if heart_token:\n        self.witch_hearts-=1\n        state['power_stats']['heart_tokens_spent']+=1\n        state['power_stats']['heart_token_ship_saves']+=1")
namespace={};exec(source,globals(),namespace);ExpansionGameV3.sink=namespace['sink']

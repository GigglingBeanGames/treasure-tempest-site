"""User-agreed balance revision, preserving original saved policies and ruleset."""
import collections
import copy
import itertools
from .multi import MultiPowerGame, SeatContext
from .engine import PowerActor, PowerGame, Game, TREASURE, CURSES, HAZARDS

class BalancedActor(PowerActor):
    def preference_multiplier(self):
        value = super().preference_multiplier()
        if self.g.power == 'Tempest King':
            alone = self.status.count('active') == 1
            value *= 2.0 if alone else 1.4
            # Solo King should pursue his power rather than immediately cash out
            # because the inherited Grant 6 policy is protecting a lead.
            if alone and self.leading(): value /= self.settings['lead_risk']*self.g.config['lead']
        return value

    def risk_harbor(self,boost=1.):
        # Same saved policy calculation with the revised rules represented.
        g = self.g; counts = collections.Counter(self.known[0][:1]) if self.known[0] else self.remaining
        n = sum(counts.values())
        if not n: return True
        gain = loss = shiprisk = 0.
        for card,count in counts.items():
            effect = g.world.choose_echo(self.p) if card == 'echo' and g.power == 'Navigator' else (self.previous if card == 'echo' else card)
            d,w,s = Game.expected_card(self,effect or 'echo',0)
            if g.power == 'Cursed Captain' and effect in CURSES: d += CURSES[effect]
            if g.power == 'Tempest King' and self.status.count('active') == 1 and effect in TREASURE: d *= 2
            if g.power == 'Storm Warden' and effect == 'marooned':
                # Personal 50-gold loss, no ship loss and no Maroon payout.
                d,w,s = -50,0,0
            if g.power == 'Navigator' and g.protection and effect in HAZARDS: d,w,s = 0,0,0
            gain += count*d/n; loss += count*w/n; shiprisk += count*s/n
        ships = self.ships[0]
        value = 0. if self.round == 15 else (30+22*(16-self.round)/max(1,ships))*(1.55 if ships<=3 else 1)*(2 if ships==1 else 1)
        if g.power == 'Mechanic' and g.tokens: value *= .25
        lost_fraction = .5 if 'escape' in self.held[0] else 1.
        if g.power == 'Storm Warden': lost_fraction = 0. if 'escape' in self.held[0] else .5
        risk = loss*self.chest*lost_fraction+shiprisk*value
        if g.power == 'Merchant': risk += 30*g.config['harbor_bonus_weight']*loss
        appetite = self.appetite[0]*(1.8 if self.desperate(0) else 1.)
        return risk > max(4,gain+8)*appetite*boost*self.preference_multiplier()

    def should_harbor(self,p=0):
        g = self.g; world = g.world
        if g.power == 'Tide Watcher':
            if g.secret == 'surge' or world.tide_self_card:
                return False
        if g.power != 'Tempest King': return super().should_harbor(p)
        if self.status[0] != 'active' or self.safe() or self.block: return False
        if self.chest == 0 or (self.round == 15 and not self.projected_lead()): return False
        if self.memory_reason(0): return True
        if self.ships[0] == 1 and self.round < 15: return True
        return self.record_decision(self.risk_harbor(),'king_seek_solo' if self.status.count('active')>1 else 'king_solo_risk')

class BalancedGame(MultiPowerGame):
    repair_price = 120
    blood_payment = 35
    merchant_bonus = 30
    captain_immune = False
    queen_collects_others = True
    warden_maroon_penalty = 50
    starting_tokens = {'Mechanic':3,'Navigator':5,'Parrot Whisperer':3,'Undead Admiral':5}

    def __init__(self,*args,**kwargs):
        self.history = []; self.tide_self_card = False; self.tide_surge_checked = None
        super().__init__(*args,**kwargs)
        self.configs = copy.deepcopy(self.configs)
        for p,power in enumerate(self.powers):
            if power:
                if power == 'Siren Queen': self.configs[p]['last_life'] = 'inherit'
                self.views[p] = BalancedActor(SeatContext(self,p),p)

    def setup_round(self):
        self.history = []; self.tide_self_card = False; self.tide_surge_checked = None
        super().setup_round()
        self.round_active_count = self.status.count('active')

    def memory_reason(self,p):
        if self.powers[p] == 'Tide Watcher' and (self.states[p]['secret'] == 'surge' or self.tide_self_card): return None
        return super().memory_reason(p)

    def insert_tide(self,p):
        card = self.states[p]['secret']
        self.deck.append(card); self.states[p]['secret'] = None
        self.known = [[] for _ in self.ships]; self.known[p] = [card]; self.wants = [False]*self.player_count
        self.states[p]['power_stats']['tide_played_'+card] += 1
        return card

    def harbor(self,p,forced=False):
        if self.status[p] == 'active' and self.powers[p] == 'Tide Watcher' and not forced:
            card = self.states[p]['secret']
            if card == 'surge' or self.tide_self_card: return
            if card in ('whirlpool','coin_curse','idol','siren') and self.status.count('active') > 1:
                self.insert_tide(p)
                self.states[p]['power_stats']['tide_departure_drop'] += 1
            elif card in ('marooned','rudder') and self.status.count('active') > 1:
                # Leaving now makes the next drawer another player.
                self.insert_tide(p)
        return super().harbor(p,forced)

    def tide_window(self,p):
        s = self.states[p]; card = s['secret']
        if self.status[p] != 'active' or not card or self.safe(): return
        drawer = self.next_drawer(); active = [j for j in self.seating if self.status[j] == 'active']
        use = False; give_self = False
        if card in ('escape','prophecy','trick','cannon','wave'):
            use = give_self = drawer == p
        elif card in ('marooned','rudder'):
            others = [j for j in active if j != p]
            leaders = [j for j in others if self.gold[j] == max(self.gold)]
            use = drawer in leaders if leaders else drawer != p
        elif card in ('key','chest'):
            before = active[(active.index(p)-1)%len(active)]
            use = drawer == before or len(active)==1
            # Soft fallback when waiting is costly, rather than an absolute seat rule.
            if not use and self.chest >= 300: use = self.rng.random() < .25
        elif card == 'surge':
            departed = self.round_active_count-len(active)
            if departed >= 1 and self.tide_surge_checked != self.draws:
                self.tide_surge_checked = self.draws
                use = departed >= 2 or len(active)==1 or self.chest >= 300 or self.rng.random() < .25
        elif card == 'echo':
            use = self.previous == 'surge'
            if len(active)>1 and drawer == p and self.previous in ('escape','trick'): use = give_self = True
        # Whirlpool/curses/Siren are inserted by harbor(), only on actual departure.
        if use:
            self.insert_tide(p); self.tide_self_card = give_self
            if give_self: s['power_stats']['tide_reserved_for_self'] += 1
            if card == 'surge':
                assert self.round_active_count > len(active)
                s['power_stats']['tide_surge_departures_total'] += self.round_active_count-len(active)
                s['power_stats']['tide_surge_uses'] += 1

    def windows(self,current):
        self.window_id += 1; self.left_this_window = set(); self.leader_left = False
        self.window_leaders = {p for p in range(self.player_count) if self.gold[p] == max(self.gold)}
        for p in self.seating:
            if self.powers[p] and self.powers[p] != 'Tide Watcher':
                with self.focus(p): self.power_window()
        before = {p:self.views[p].others_harbored() for p in self.six_players}
        # Reserve personal cards before decisions only if Tide is the next drawer;
        # other placements happen after departures so their recipient is current.
        tide = self.power_index.get('Tide Watcher')
        if tide is not None and self.next_drawer()==tide:
            card = self.states[tide]['secret']
            if card in ('escape','prophecy','trick','cannon','wave') or (card == 'echo' and self.previous in ('escape','trick') and self.status.count('active')>1):
                self.tide_window(tide)
        Game.windows(self,current)
        for p in range(self.player_count):
            if self.memory_reason(p) and not self.safe() and not self.blocks[p] and not self.refuse_exit(p): self.harbor(p)
        for p in self.six_players:
            v = self.views[p]
            if not before[p] and v.others_harbored() and v.leading() and self.status[p]=='active' and not self.safe() and not self.blocks[p]:
                if v.should_harbor(): self.harbor(p)
        if tide is not None: self.tide_window(tide)

    def cannon(self,p):
        with self.focus(p):
            if self.power == 'Tempest King': return PowerGame.cannon(self,p)
            eligible = [j for j in self.seating if j != p and self.status[j]=='active']
            if not eligible: return
            vulnerable = [j for j in eligible if self.powers[j] != 'Tempest King']
            if not vulnerable:
                self.states[eligible[0]]['power_stats']['king_cannon_immunity'] += 1
                return
            mode = self.config['cannon']
            if mode == 'ships': target = max(vulnerable,key=lambda j:self.ships[j])
            elif mode == 'fewest': target = min(vulnerable,key=lambda j:self.ships[j])
            elif mode == 'power' and self.power == 'Blood Sailor': target = max(vulnerable,key=lambda j:(j not in self.targets,self.gold[j]))
            else: target = max(vulnerable,key=lambda j:self.gold[j])
            self.harbor(target,True)

    def choose_echo(self,p):
        choices = list(dict.fromkeys(reversed(self.history[-2:])))
        if not choices: return self.previous or 'echo'
        v = self.views[p]
        def value(effect):
            if effect in HAZARDS and self.states[p]['protection']: return 0
            if effect == 'whirlpool': return -self.chest*(.5 if 'escape' in self.held[p] else 1)-100-40*(16-self.round)/max(1,self.ships[p])
            if effect == 'marooned': return -100-40*(16-self.round)/max(1,self.ships[p])
            if effect == 'rudder': return -30
            if effect == 'escape': return 0 if 'escape' in self.held[p] else 20+self.chest*.15
            if effect == 'trick': return 20
            if effect == 'prophecy': return 35
            if effect == 'wave': return 20
            if effect == 'cannon': return 30 if self.status.count('active')>1 else 0
            if effect == 'siren': return -80
            if effect in ('key','chest'): return 25
            if effect in CURSES: return -min(self.chest,CURSES[effect])
            if effect == 'surge': return self.chest or 100
            return TREASURE.get(effect,0)
        return max(choices,key=value)

    def echo_effect(self,p):
        if self.powers[p] != 'Navigator': return super().echo_effect(p)
        choice = self.choose_echo(p)
        stats = self.states[p]['power_stats']; stats['navigator_echo_choices'] += 1
        stats['navigator_echo_'+choice] += 1
        if self.history and choice != self.history[-1]: stats['navigator_echo_second_previous'] += 1
        return choice

    def resolved_card(self,p,card,effect,safe):
        self.history.append(effect)
        tide = self.power_index.get('Tide Watcher')
        if self.tide_self_card:
            assert p == tide and not safe, 'Tide personal card must resolve for its owner outside calm waters'
            self.states[tide]['power_stats']['tide_self_card_received'] += 1
            self.tide_self_card = False
        king = self.power_index.get('Tempest King')
        if king is not None and p == king and self.status.count('active') == 1 and self.status[p]=='active':
            self.states[p]['power_stats']['king_solo_draws_survived'] += 1

    def prophecy(self,p):
        if self.powers[p] != 'Parrot Whisperer': return super().prophecy(p)
        k = min(4,len(self.deck))
        if not k: return
        cards = list(reversed(self.deck[-k:])); mode = self.configs[p]['prophecy']
        active = [j for j in self.seating if self.status[j]=='active']; at = active.index(p)
        def value(card,recipient):
            own = recipient == p
            if card == 'whirlpool': return -1000 if self.blocks[p] else -200
            if card in ('marooned','rudder'): return -500 if own else 100 if mode != 'safe' else -20
            if card in CURSES: return -CURSES[card]
            if card == 'siren': return -80
            if card == 'surge': return 300 if mode == 'surge' else 100
            if card in TREASURE: return TREASURE[card]
            if card in ('escape','trick','prophecy','cannon'): return 90 if own else -20
            if card in ('key','chest'): return 35
            return 20
        options = []
        for n in range(min(2,k)+1):
            for indices in itertools.combinations(range(k),n):
                bottom = [cards[i] for i in indices]; rest = [cards[i] for i in range(k) if i not in indices]
                options.extend((list(order),bottom) for order in sorted(set(itertools.permutations(rest))))
        order,bottom = max(options,key=lambda option:sum(value(card,active[(at+i+1)%len(active)])/(i+1) for i,card in enumerate(option[0])))
        del self.deck[-k:]; self.deck[0:0] = list(reversed(bottom)); self.deck.extend(reversed(order))
        self.known = [[] for _ in self.ships]; self.known[p] = order.copy(); self.wants = [False]*self.player_count
        stats = self.states[p]['power_stats']; stats['prophecy_uses'] += 1
        if order: stats['prophecy_top_'+order[0]] += 1
        stats['prophecy_bottom_count_'+str(len(bottom))] += 1
        for card in bottom: stats['prophecy_bottom_'+card] += 1

"""Current rules: restored Mechanic policy; no Navigator Wild Wave ability."""
import collections
from .engine import TREASURE, CURSES, HAZARDS
from .revision4 import Revision4Game
from .revision3 import Revision3Game


class Revision5Game(Revision4Game):
    # Revision 3 sinking has the same current hazard, insurance and plunder
    # rules, with the original Mechanic selling/self-repair decisions.
    sink = Revision3Game.sink

    def draw(self,p):
        if not self.deck:
            if not self.discard: raise RuntimeError('No drawable cards')
            self.deck = self.discard; self.discard = []; self.rng.shuffle(self.deck)
            self.remaining = collections.Counter(self.deck+self.hidden_cards())
            self.known = [[] for _ in self.ships]
        safe = self.safe(); self.safe_next = False
        self.in_draw = True
        self.song_protected_draw = self.lock_kind == 'song' and self.lock_remaining > 0
        card = self.deck.pop(); self.remaining[card] -= 1
        for known in self.known:
            if known: known.pop(0)
        pending = list(self.pending)
        self.draws += 1; self.total_draws += 1; self.own_draws[p] += 1
        self.lock_remaining = max(0,self.lock_remaining-1)
        self.cannon_blocks = [max(0,x-1) for x in self.cannon_blocks]
        self.sync_blocks()
        effect = (self.echo_effect(p) if not safe else self.previous or 'echo') if card == 'echo' else card
        self.previous = effect; self.resolving = effect
        hold = False; holder = p; power = self.powers[p]
        swindler = self.power_index.get('Storm Swindler')
        captain = self.power_index.get('Cursed Captain')
        admiral = self.power_index.get('Undead Admiral')
        queen = self.power_index.get('Siren Queen')
        if safe:
            self.calm_cards[card] += 1
            self.chest += TREASURE.get(card,50 if card in HAZARDS else 0 if card in CURSES else 10)
        elif effect in TREASURE:
            if swindler is not None and not self.states[swindler]['stolen_treasure']:
                self.states[swindler]['stolen_treasure'] = True; hold = True; holder = swindler
                self.award(swindler,TREASURE[effect],'swindler_treasure')
            else: self.chest += TREASURE[effect]*(2 if power == 'Tempest King' and self.status.count('active') == 1 else 1)
            if p == queen and effect == 'diamond':
                hold = True; holder = p; self.queen_necklaces += 1
                self.states[p]['power_stats']['queen_necklaces_collected'] += 1
        elif effect in CURSES:
            if captain is not None:
                hold = self.collect_curse(captain,effect,card); holder = captain
            if p != captain or not self.captain_immune: self.chest = max(0,self.chest-CURSES[effect])
            if admiral is not None and effect == 'idol':
                self.replace_lock('idol',2)
                self.states[admiral]['power_stats']['admiral_idol_blocks'] += 1
        elif effect == 'surge': self.chest = self.chest*2 if self.chest else 100
        elif effect in ('key','chest'):
            self.safe_next = True
            if p == queen:
                hold = True
                self.states[p]['power_stats']['queen_personal_'+effect+'_effects'] += 1
                self.queen_markers[effect] += 1
                self.states[p]['power_stats']['queen_collected_'+effect] += 1
                while self.queen_markers['key'] and self.queen_markers['chest']:
                    self.queen_markers['key'] -= 1; self.queen_markers['chest'] -= 1
                    self.queen_markers += collections.Counter()  # discard zero-count keys
                    self.states[p]['power_stats']['queen_pairs_cashed'] += 1
                    if self.ships[p] < 8:
                        self.ships[p] += 1
                        self.states[p]['power_stats']['queen_ship_gained'] += 1
                    else:
                        self.states[p]['power_stats']['queen_pairs_at_ship_cap'] += 1
        elif effect == 'siren':
            self.replace_lock('song',4)
        elif effect == 'whirlpool':
            # Whole card resolves before elimination/game-end checks.
            for j in range(self.player_count): self.sink(j)
        elif effect == 'marooned':
            immune = self.hazard_immune(p,True)
            self.sink(p,True); hold = not immune
            if not immune: self.marooned_players.add(p)
        elif effect == 'rudder':
            if power not in ('Mechanic','Tempest King'): self.harbor(p,True); self.gold[p] -= 30; hold = True
            else: self.states[p]['power_stats']['rudder_ignored'] += 1
        elif effect == 'escape': hold = 'escape' not in self.held[p]
        elif effect == 'trick':
            amount = 50 if power == 'Storm Swindler' else 20
            self.chest = max(0,self.chest-amount); self.gold[p] += amount; hold = True
            if amount == 50:
                self.power_gold[p] += 30; self.states[p]['power_stats']['swindler_extra_trick_gold'] += 30
                self.states[p]['power_stats']['swindler_trick_uses'] += 1
        elif effect == 'wave':
            self.deck.extend(self.discard); self.discard = []; self.rng.shuffle(self.deck)
            self.remaining = collections.Counter(self.deck+self.hidden_cards())
            self.known = [[] for _ in self.ships]; self.wants = [False]*self.player_count
            self.safe_next = True; self.gold[p] += 10; hold = True
        elif effect == 'prophecy':
            parrot = self.power_index.get('Parrot Whisperer')
            if parrot is not None:
                s = self.states[parrot]; before = s['tokens']; s['tokens'] = min(10,s['tokens']+1)
                s['power_stats']['parrot_tokens_gained'] += s['tokens']-before
            self.prophecy(p)
        elif effect == 'cannon': self.cannon(p)
        if hold: self.held[holder].append(effect); self.physical_held.append(card)
        else: self.discard.append(card)
        if not safe and effect == 'surge': self.last_surge = self.draws; self.followup_exits = [False]*self.player_count
        for j,s in enumerate(self.states):
            if pending[j]: self.followup_exits[j] = not(card == 'echo' and not safe and effect == 'surge'); self.pending[j] = False
            if s['protection']: s['protection'] -= 1
        if self.chest >= 9999:
            self.chest = 9999
            for j in range(self.player_count): self.harbor(j,True)
        self.resolved_card(p,card,effect,safe)
        self.in_draw = False
        if not self.lock_remaining: self.lock_kind = None
        self.sync_blocks()
        self.check_end()



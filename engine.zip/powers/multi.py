"""Simultaneous unique powers, reusing each saved bot's frozen decision policy.

Local power state is isolated per identity; passive hooks resolve globally.
Tide Watcher's setup treasure is separate from Swindler's first normal treasure.
"""
import collections
from contextlib import contextmanager
from .engine import (PowerGame, PowerActor, SixActor, FrozenGrant, Game,
                     ExperimentGame, TournamentGame, TUNING6, NeutralLifeView,
                     TREASURE, CURSES, HAZARDS, POWERS, defaults)

LOCAL = ('tokens', 'protection', 'used_round', 'secret', 'peek_at', 'targets',
         'rewarded_targets', 'stolen_treasure', 'power_stats')

class SeatContext:
    """Expose only this actor's power and private Tide information."""
    def __init__(self, game, p): self.world = game; self.p = p
    def __getattr__(self, name):
        g = self.world; p = self.p
        if name == 'owner': return p
        if name == 'power': return g.powers[p]
        if name == 'config': return g.configs[p]
        if name in LOCAL: return g.states[p][name]
        return getattr(g, name)

class MultiPowerGame(PowerGame):
    repair_price = 150
    blood_payment = 40
    merchant_bonus = 20
    captain_immune = True
    queen_collects_others = False
    warden_maroon_penalty = 0
    starting_tokens = {'Mechanic':3,'Navigator':5,'Parrot Whisperer':2,'Undead Admiral':4}
    def __init__(self, seed, powers, opponents, configs=None, game_id=0, versions=None):
        if not 3 <= len(powers) <= 6: raise ValueError('Three to six players required')
        named = [p for p in powers if p is not None]
        if len(set(named)) != len(named) or any(p not in POWERS for p in named):
            raise ValueError('Powers must be known and unique')
        self.powers = list(powers); self.player_count = len(powers); self._focus = 0
        self.configs = configs or [defaults(p) for p in powers]
        self.states = [dict(tokens=self.starting_tokens.get(p,0),
                            protection=0, used_round=False, secret=None, peek_at=None,
                            targets=None, rewarded_targets=set(), stolen_treasure=False,
                            power_stats=collections.Counter()) for p in powers]
        self.power_index = {name:p for p,name in enumerate(powers) if name}
        self.blocks = [0]*self.player_count
        versions = versions or [6]*self.player_count
        self.six_players = tuple(p for p,v in enumerate(versions) if v == 6)
        self.actor_settings = {p:{k:v['original'] for k,v in TUNING6.items()} for p in self.six_players}
        TournamentGame.__init__(self, seed, versions, [opponents[v] for v in versions], FrozenGrant(), game_id=game_id)
        for p in self.six_players: self.views[p] = SixActor(self,p)
        for p,power in enumerate(powers):
            if power:
                if versions[p] != 6: raise ValueError('Power bots require Grant 6 parent')
                self.views[p] = PowerActor(SeatContext(self,p),p)
                self.ships[p] = POWERS[power]
        self.power_gold = [0.]*self.player_count
        self.repair_sales = True; self.revive_blood = True

    @property
    def owner(self): return self._focus
    @property
    def power(self): return self.powers[self._focus]
    @property
    def config(self): return self.configs[self._focus]

    @contextmanager
    def focus(self,p):
        old = self._focus; self._focus = p
        try: yield
        finally: self._focus = old

    def setup_round(self):
        for s in self.states:
            s.update(secret=None,protection=0,used_round=False,peek_at=None,stolen_treasure=False)
        TournamentGame.setup_round(self)
        for p in self.six_players:
            if self.states[p]['targets'] is None:
                at = self.seating.index(p)
                self.states[p]['targets'] = {self.seating[(at-1)%self.player_count],self.seating[(at+1)%self.player_count]}
            if self.status[p] != 'active': continue
            view = NeutralLifeView(self.views[p]) if self.round == 15 else self.views[p]
            for name,choices in TUNING6.items():
                label = self.policies[p].choose('tune_'+name,view,['original']+[k for k in choices if k != 'original'])
                self.actor_settings[p][name] = choices[label]
        p = self.power_index.get('Tide Watcher')
        if p is not None:
            card = self.deck.pop()
            if card in TREASURE:
                self.remaining[card] -= 1; self.held[p].append(card); self.physical_held.append(card)
                self.award(p,TREASURE[card],'tide_treasure')
            else:
                self.states[p]['secret'] = card
                self.states[p]['power_stats']['tide_hidden_cards'] += 1

    def award(self,p,amount,reason):
        self.gold[p] += amount; self.power_gold[p] += amount
        stats = self.states[p]['power_stats']
        stats[reason+'_uses'] += 1; stats[reason+'_gold'] += amount

    def harbor_value(self,p):
        return Game.harbor_value(self,p)+(self.merchant_bonus if self.powers[p] == 'Merchant' else 0)

    def harbor(self,p,forced=False):
        was_active = self.status[p] == 'active'
        with self.focus(p): result = PowerGame.harbor(self,p,forced)
        if was_active and self.powers[p] == 'Merchant':
            extra = self.merchant_bonus-20
            self.power_gold[p] += extra
            self.states[p]['power_stats']['merchant_harbor_gold'] += extra
        return result

    def memory_reason(self,p):
        with self.focus(p): return PowerGame.memory_reason(self,p)

    def prophecy(self,p):
        with self.focus(p): return PowerGame.prophecy(self,p)

    def cannon(self,p):
        with self.focus(p): return PowerGame.cannon(self,p)

    def windows(self,current):
        # Round seating randomizes simultaneous optional power activation order.
        for p in self.seating:
            if self.powers[p]:
                with self.focus(p): self.power_window()
        before = {p:self.views[p].others_harbored() for p in self.six_players}
        self.window_id += 1; self.left_this_window = set(); self.leader_left = False
        self.window_leaders = {p for p in range(self.player_count) if self.gold[p] == max(self.gold)}
        Game.windows(self,current)
        for p in range(self.player_count):
            if self.memory_reason(p) and not self.safe() and not self.blocks[p] and not self.refuse_exit(p): self.harbor(p)
        for p in self.six_players:
            v = self.views[p]
            if not before[p] and v.others_harbored() and v.leading() and self.status[p] == 'active' and not self.safe() and not self.blocks[p]:
                if v.should_harbor(): self.harbor(p)

    def sink(self,p,maroon=False):
        if self.status[p] != 'active': return
        power = self.powers[p]; state = self.states[p]
        if (power == 'Navigator' and state['protection']) or (power == 'Storm Warden' and maroon):
            state['power_stats']['hazards_ignored'] += 1
            if power == 'Storm Warden' and maroon and self.warden_maroon_penalty:
                self.award(p,-self.warden_maroon_penalty,'warden_maroon_penalty')
            return
        repair = False; mechanic = self.power_index.get('Mechanic')
        if mechanic is not None and self.states[mechanic]['tokens']:
            s = self.states[mechanic]; c = self.configs[mechanic]
            if p == mechanic: repair = self.ships[p] <= c['repair_self_max_ships']
            elif self.repair_sales:
                mode = c['sell']
                offer = mode == 'always' or (mode == 'balanced' and (self.ships[mechanic] >= 3 or s['tokens'] > 1)) or (mode == 'reserve_two' and s['tokens'] > 2)
                value = 30+60*(15-self.round)/max(1,self.ships[p])
                repair = offer and self.gold[p] >= self.repair_price and value >= self.repair_price
                if offer: s['power_stats']['repair_offers'] += 1
                if repair: self.award(mechanic,self.repair_price,'repair_sale'); self.award(p,-self.repair_price,'repair_purchase')
            if repair:
                s['tokens'] -= 1; s['power_stats']['self_repairs' if p == mechanic else 'sold_repairs'] += 1
        old_ships = self.ships[p]
        ExperimentGame.sink(self,p,maroon)
        if repair: self.ships[p] = old_ships
        if power == 'Storm Warden': self.award(p,self.chest/2,'warden_insurance')
        blood = self.power_index.get('Blood Sailor')
        if blood is not None:
            s = self.states[blood]
            if p in s['targets']:
                self.award(blood,self.blood_payment,'blood_sink')
                if self.ships[p] == 0 and p not in s['rewarded_targets']:
                    s['rewarded_targets'].add(p)
                    self.ships[blood] += 1; s['power_stats']['blood_ship_gained'] += 1
        admiral = self.power_index.get('Undead Admiral')
        if admiral is not None:
            s = self.states[admiral]; c = self.configs[admiral]
            if s['tokens'] and not s['used_round'] and (self.chest >= c['plunder_min_gold'] or (self.round >= c['plunder_late'] and self.chest > 100)):
                s['tokens'] -= 1; s['used_round'] = True; self.award(admiral,self.chest*.1,'plunder')

    def hidden_cards(self): return [s['secret'] for s in self.states if s['secret']]

    def echo_effect(self,p): return self.previous or 'echo'

    def resolved_card(self,p,card,effect,safe): pass

    def draw(self,p):
        if not self.deck:
            if not self.discard: raise RuntimeError('No drawable cards')
            self.deck = self.discard; self.discard = []; self.rng.shuffle(self.deck)
            self.remaining = collections.Counter(self.deck+self.hidden_cards())
            self.known = [[] for _ in self.ships]
        safe = self.safe(); self.safe_next = False
        card = self.deck.pop(); self.remaining[card] -= 1
        for known in self.known:
            if known: known.pop(0)
        pending = list(self.pending)
        self.draws += 1; self.total_draws += 1; self.own_draws[p] += 1
        self.blocks = [max(0,x-1) for x in self.blocks]
        effect = (self.echo_effect(p) if not safe else self.previous or 'echo') if card == 'echo' else card
        self.previous = effect; self.resolving = effect
        hold = False; holder = p; power = self.powers[p]
        swindler = self.power_index.get('Storm Swindler')
        captain = self.power_index.get('Cursed Captain')
        admiral = self.power_index.get('Undead Admiral')
        queen = self.power_index.get('Siren Queen')
        if safe:
            self.calm_cards[card] += 1
            self.chest += TREASURE.get(card,50 if card in HAZARDS else 0 if card in CURSES else 10)
        elif effect in TREASURE:
            if swindler is not None and not self.states[swindler]['stolen_treasure']:
                self.states[swindler]['stolen_treasure'] = True; hold = True; holder = swindler
                self.award(swindler,TREASURE[effect],'swindler_treasure')
            else: self.chest += TREASURE[effect]*(2 if power == 'Tempest King' and self.status.count('active') == 1 else 1)
        elif effect in CURSES:
            if captain is not None:
                hold = True; holder = captain; self.award(captain,CURSES[effect],'cursed_captain')
            if p != captain or not self.captain_immune: self.chest = max(0,self.chest-CURSES[effect])
            if admiral is not None and effect == 'idol':
                self.blocks = [x+3 if j != admiral else x for j,x in enumerate(self.blocks)]
                self.states[admiral]['power_stats']['admiral_idol_blocks'] += 1
        elif effect == 'surge': self.chest = self.chest*2 if self.chest else 100
        elif effect in ('key','chest'):
            self.safe_next = True
            if self.queen_collects_others:
                if queen is not None and self.status[queen] == 'active' and effect not in self.held[queen]:
                    hold = True; holder = queen
                    self.states[queen]['power_stats']['queen_collected_'+effect] += 1
            elif p == queen: hold = True
        elif effect == 'siren':
            duration = 8 if p == queen else 4
            self.blocks = [x if j == queen else x+duration for j,x in enumerate(self.blocks)]
        elif effect == 'whirlpool':
            # Whole card resolves before elimination/game-end checks.
            for j in range(self.player_count): self.sink(j)
        elif effect == 'marooned':
            immune = (power == 'Navigator' and self.states[p]['protection']) or power == 'Storm Warden'
            self.sink(p,True); hold = not immune
            if not immune: self.marooned_players.add(p)
        elif effect == 'rudder':
            if power != 'Mechanic': self.harbor(p,True); self.gold[p] -= 30; hold = True
            else: self.states[p]['power_stats']['rudder_ignored'] += 1
        elif effect == 'escape': hold = 'escape' not in self.held[p]
        elif effect == 'trick':
            amount = 40 if power == 'Storm Swindler' else 20
            self.chest = max(0,self.chest-amount); self.gold[p] += amount; hold = True
            if amount == 40:
                self.power_gold[p] += 20; self.states[p]['power_stats']['swindler_extra_trick_gold'] += 20
        elif effect == 'wave':
            self.deck.extend(self.discard); self.discard = []; self.rng.shuffle(self.deck)
            self.remaining = collections.Counter(self.deck+self.hidden_cards())
            self.known = [[] for _ in self.ships]; self.wants = [False]*self.player_count
            self.safe_next = True; self.gold[p] += 10; hold = True
        elif effect == 'prophecy':
            parrot = self.power_index.get('Parrot Whisperer')
            if parrot is not None:
                s = self.states[parrot]; before = s['tokens']; s['tokens'] = min(10,s['tokens']+1)
                s['power_stats']['parrot_tokens_gained'] += s['tokens']-before
            self.prophecy(p)
        elif effect == 'cannon': self.cannon(p)
        if hold: self.held[holder].append(effect); self.physical_held.append(card)
        else: self.discard.append(card)
        if not safe and effect == 'surge': self.last_surge = self.draws; self.followup_exits = [False]*self.player_count
        for j,s in enumerate(self.states):
            if pending[j]: self.followup_exits[j] = not(card == 'echo' and not safe and effect == 'surge'); self.pending[j] = False
            if s['protection']: s['protection'] -= 1
        if self.chest >= 9999:
            self.chest = 9999
            for j in range(self.player_count): self.harbor(j,True)
        self.resolved_card(p,card,effect,safe)
        self.check_end()

    def play(self):
        while self.round < 15 and not self.ended:
            self.setup_round(); cursor = 0
            while 'active' in self.status and not self.ended:
                while self.status[self.seating[cursor]] != 'active': cursor = (cursor+1)%self.player_count
                self.current = self.seating[cursor]; self.windows(self.current)
                if 'active' not in self.status: break
                if self.status[self.current] == 'active': self.draw(self.current)
                cursor = (cursor+1)%self.player_count
                if self.draws > 10000: raise RuntimeError('Round safety bound')
            assert collections.Counter(self.deck+self.discard+self.physical_held+self.hidden_cards()) == self.initial_counts
            for p in range(self.player_count):
                self.round_data.append({'game':self.game_id,'round':self.round,'bot':p,'seat':self.seating.index(p),
                    'round_gold':self.gold[p]-self.round_begin[p]-self.round_bonus[p], 'harbor_gold':self.harbor_gold[p],
                    'additional_gold':self.gold[p]-self.round_begin[p]-self.round_bonus[p]-self.harbor_gold[p],
                    'ships_start':self.round_ships[p], 'ships_end':self.ships[p], 'status':self.status[p],
                    'round_draws':self.draws,'own_draws':self.own_draws[p]})
        if not self.ended:
            most = max(self.ships)
            if self.ships.count(most) == 1:
                p = self.ships.index(most); self.gold[p] += 100; self.game_bonus[p] += 100
        for p,power in enumerate(self.powers):
            self.sell_gold[p] = self.ships[p]*(50 if power == 'Merchant' else 30)
            self.gold[p] += self.sell_gold[p]
            if power == 'Merchant':
                premium = self.ships[p]*20
                self.power_gold[p] += premium; self.states[p]['power_stats']['merchant_ship_premium_gold'] += premium
            token_value = {'Mechanic':30,'Parrot Whisperer':10,'Undead Admiral':10}.get(power,0)
            if token_value:
                amount = self.states[p]['tokens']*token_value; self.gold[p] += amount; self.game_bonus[p] += amount
                self.power_gold[p] += amount; self.states[p]['power_stats']['token_sale_gold'] += amount
            assert abs(sum(r['round_gold'] for r in self.round_data if r['bot'] == p)+self.game_bonus[p]+self.sell_gold[p]-self.gold[p]) < 1e-6
        best = max(self.gold); winners = [p for p,x in enumerate(self.gold) if abs(x-best) < 1e-8]
        return [1/len(winners) if p in winners else 0. for p in range(self.player_count)]


def local_property(name):
    return property(lambda self:self.states[self._focus][name],lambda self,value:self.states[self._focus].__setitem__(name,value))
for _name in LOCAL: setattr(MultiPowerGame,_name,local_property(_name))

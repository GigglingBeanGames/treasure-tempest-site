"""Revision 28 power balance rules (unrelated to the retired Grant 7 learner)."""
import collections
from .revision6 import Revision6Game
from .revision2 import RevisionActor
from .balanced import BalancedGame
from .multi import SeatContext
from tournament import Actor
from .engine import SixActor
from .engine import Game, ExperimentGame, PowerActor, PowerGame, TREASURE, CURSES, HAZARDS

def current_expected_card(view,card,p=0):
    effect = view.previous if card == 'echo' else card
    if effect == 'marooned':
        return 0., (0. if 'escape' in view.held[p] else .5), 1.
    return Game.expected_card(view,card,p)

class OpponentActor(Actor):
    def expected_card(self,card,p=0): return current_expected_card(self,card,p)

    @property
    def block(self): return self.g.blocks[self.p]

class OpponentSixActor(SixActor):
    def expected_card(self,card,p=0): return current_expected_card(self,card,p)

    @property
    def block(self): return self.g.blocks[self.p]

class QueenGrant2Actor(OpponentActor):
    def should_harbor(self,p=0):
        if self.status[0] != 'active' or self.safe() or self.block: return False
        if self.g.lock_kind == 'song' and self.g.lock_remaining == 4 and self.chest > 0:
            _,_,surge,whirlpool = ExperimentGame.odds(self,0)
            if not (surge > 0 and surge >= whirlpool):
                self.g.states[self.p]['power_stats']['queen_song_exit'] += 1
                return True
        return ExperimentGame.should_harbor(self,0)

class Revision28Actor(RevisionActor):
    def expected_card(self,card,p=0): return current_expected_card(self,card,p)

    def preference_multiplier(self):
        if self.g.power == 'Siren Queen':
            value = super().preference_multiplier()
            factor = self.g.config['pair_appetite']
            if ('key' in self.held[0]) != ('chest' in self.held[0]): value /= factor
            marks = self.g.world.queen_markers
            if bool(marks['key']) != bool(marks['chest']): value *= factor
            return value
        if self.g.power == 'Tempest King':
            value = PowerActor.preference_multiplier(self)
            c = self.g.config
            if self.ships[0] >= 6: value *= c.get('spare_lives_risk',1.)
            elif self.ships[0] >= 3: value *= c.get('middle_lives_risk',1.)
            if self.gold[0] < max(self.gold[1:]): value *= c.get('trailing_risk',1.)
            return value
        value = super().preference_multiplier()
        if self.g.power == 'Navigator' and not self.g.protection:
            _,_,surge,whirlpool = ExperimentGame.odds(self,0)
            if whirlpool > 2*surge: value *= .5
        return value

    def should_harbor(self,p=0):
        g = self.g
        if g.power == 'Tempest King' and self.status[0] == 'active' and g.protection:
            return False
        if g.power == 'Cannoneer' and self.status.count('active') == 1:
            if self.status[0] != 'active' or self.safe() or self.block: return False
            if self.chest == 0 or (self.round == 15 and not self.projected_lead()): return False
            if self.memory_reason(0) or (self.ships[0] == 1 and self.round < 15): return True
            return self.risk_harbor(1.3)
        if g.power == 'Parrot Whisperer' and self.status[0]=='active' and g.world.parrot_reserved:
            if self.known[0] and self.known[0][0] in ('escape','prophecy','trick','cannon','wave'):
                return False
        if g.power == 'Tempest King': return PowerActor.should_harbor(self,p)
        return super().should_harbor(p)

    def risk_harbor(self,boost=1.):
        # Same saved policy calculation with the revised rules represented.
        g = self.g; counts = collections.Counter(self.known[0][:1]) if self.known[0] else self.remaining
        n = sum(counts.values())
        if not n: return True
        gain = loss = shiprisk = 0.
        for card,count in counts.items():
            effect = g.world.choose_echo(self.p) if card == 'echo' and g.power == 'Navigator' else (self.previous if card == 'echo' else card)
            d,w,s = current_expected_card(self,effect or 'echo',0)
            if g.power == 'Storm Swindler' and effect == 'trick': d = 100-min(self.chest,100)
            if g.power == 'Cursed Captain' and effect in CURSES: d += g.world.curse_marginal(effect)
            if g.power == 'Storm Warden' and effect == 'marooned' and g.world.use_warden_token(self.p): w = 0.
            if g.power == 'Cannoneer' and effect in TREASURE and self.status.count('active') == 1: d *= 2
            if effect in CURSES and g.world.admiral_curse_active(): d = -min(self.chest,CURSES[effect]+10) + (g.world.curse_marginal(effect) if g.power == 'Cursed Captain' else 0)
            if g.power == 'Cursed Captain' and effect in CURSES: d = g.world.curse_marginal(effect)
            if effect in HAZARDS and g.world.hazard_immune(self.p,effect == 'marooned',forecast=True): d,w,s = 0,0,0
            gain += count*d/n; loss += count*w/n; shiprisk += count*s/n
        ships = self.ships[0]
        value = 0. if self.round == 15 else (30+22*(16-self.round)/max(1,ships))*(1.55 if ships<=3 else 1)*(2 if ships==1 else 1)
        if g.power == 'Mechanic' and g.tokens: value *= .25
        lost_fraction = .5 if 'escape' in self.held[0] else 1.
        if g.power == 'Storm Warden' and g.world.use_warden_token(self.p): lost_fraction = 0. if 'escape' in self.held[0] else .5
        risk = loss*self.chest*lost_fraction+shiprisk*value
        if g.power == 'Merchant': risk += g.world.merchant_bonus*g.config['harbor_bonus_weight']*loss
        appetite = self.appetite[0]*(1.8 if self.desperate(0) else 1.)
        return risk > max(4,gain+8)*appetite*boost*self.preference_multiplier()

class Revision28Game(Revision6Game):
    repair_price = 100
    merchant_bonus = 20
    captain_immune = True
    starting_tokens = dict(Revision6Game.starting_tokens, **{'Navigator':5,'Parrot Whisperer':2,'Storm Warden':3})

    def __init__(self,seed,powers,opponents,configs=None,**kwargs):
        if 'Storm Swindler' in powers: raise ValueError('Storm Swindler is replaced by Cannoneer')
        self.queen_necklace_total = 0
        self.swindler_trick_pending = 0
        mapped = ['Storm Swindler' if p == 'Cannoneer' else p for p in powers]
        super().__init__(seed,mapped,opponents,configs,**kwargs)
        self.powers = list(powers)
        self.power_index = {name:p for p,name in enumerate(powers) if name}
        for p,power in enumerate(self.powers):
            if power in ('Cannoneer','Siren Queen'): self.ships[p] = 7
            if power == 'Cannoneer': self.states[p]['tokens'] = 1
            if power == 'Parrot Whisperer': self.ships[p] = 6
            if power == 'Storm Warden': self.ships[p] = 6
            if power == 'Cursed Captain': self.ships[p] = 6
            if power == 'Mechanic': self.ships[p] = 6
            if power == 'Undead Admiral': self.ships[p] = 6
            if power == 'Tempest King':
                self.ships[p] = 8
            if power: self.views[p] = Revision28Actor(SeatContext(self,p),p)
            else: self.views[p] = (OpponentSixActor if self.versions[p] == 6 else OpponentActor)(self,p)
        queen = self.power_index.get('Siren Queen')
        if queen is not None:
            self.versions = list(self.versions); self.versions[queen] = 2
            self.policies = list(self.policies); self.policies[queen] = opponents[2]
            self.six_players = tuple(p for p in self.six_players if p != queen)
            self.views[queen] = QueenGrant2Actor(self,queen)

    def captain_collects_from(self,p):
        captain = self.power_index.get('Cursed Captain')
        if captain is None: return False
        at = self.seating.index(captain)
        return p in (captain,self.seating[(at-1)%self.player_count],self.seating[(at+1)%self.player_count])

    def choose_echo(self,p):
        nav = self.power_index.get('Navigator')
        if nav is None or self.status[nav] != 'active': return self.previous or 'echo'
        choices = list(dict.fromkeys(reversed(self.history[-2:])))
        if not choices: return self.previous or 'echo'
        def score(effect):
            if effect == 'surge': return 10000
            if effect in TREASURE: return 500+4*TREASURE[effect]
            if effect == 'marooned': return 800 if p != nav else -50000
            if effect == 'rudder': return 750 if p != nav else -40000
            if effect == 'whirlpool': return -50 if self.states[nav]['protection'] else -100000
            if effect == 'escape': return 650 if p == nav and 'escape' not in self.held[nav] else -200
            if effect == 'trick': return 600 if p == nav else -200
            if effect in CURSES: return -500-CURSES[effect]
            if effect == 'siren': return -300
            if effect == 'prophecy': return 450 if p == nav else 20
            if effect == 'cannon': return 350 if p == nav else -100
            if effect in ('key','chest'): return 300
            if effect == 'wave': return 100
            return 0
        return max(choices,key=score)

    def echo_effect(self,p):
        nav = self.power_index.get('Navigator')
        if nav is None or self.status[nav] != 'active': return self.previous or 'echo'
        choice = self.choose_echo(p)
        stats = self.states[nav]['power_stats']
        stats['navigator_echo_choices'] += 1
        stats['navigator_echo_'+choice] += 1
        stats['navigator_echo_own_draw' if p == nav else 'navigator_echo_other_draw'] += 1
        if self.history and choice != self.history[-1]: stats['navigator_echo_second_previous'] += 1
        if (p == nav and choice in ('marooned','rudder')) or (choice == 'whirlpool' and not self.states[nav]['protection']):
            stats['navigator_echo_unavoidable_bad_choice'] += 1
        return choice

    def curse_marginal(self,effect): return CURSES[effect]

    def collect_curse(self,p,effect,physical):
        self.captain_cards.append((effect,physical))
        self.award(p,CURSES[effect],'cursed_captain')
        return True

    def power_window(self):
        if self.power == 'Cannoneer': return self.cannon_token_window()
        if self.power != 'Navigator': return super().power_window()
        p = self.owner; state = self.states[p]
        if self.status[p] != 'active' or self.safe() or not state['tokens'] or state['used_round']: return
        view = self.views[p]
        # Decide without token protection; preserve random choice if later rechecked.
        rng_state = self.rng.getstate()
        leave = view.should_harbor()
        self.rng.setstate(rng_state)
        if leave:
            state['power_stats']['navigator_left_instead_of_token'] += 1
            self.harbor(p)
            return
        if not any(self.remaining[c] > 0 for c in HAZARDS): return
        _,_,surge,whirlpool = ExperimentGame.odds(view,0)
        locked = self.blocks[p] > 0
        song = self.lock_kind == 'song' and self.lock_remaining > 0
        low = self.ships[p] <= 2
        urgent = state['tokens'] >= 16-self.round
        threshold = 200
        if song: threshold = min(threshold,100)
        if low: threshold = min(threshold,75)
        if urgent: threshold = min(threshold,25)
        if self.chest < threshold: return
        # Don't buy protection for an unattractive gamble when freely able to leave.
        if whirlpool > 2*surge and not locked and not low and not urgent: return
        state['tokens'] -= 1; state['protection'] = 4; state['used_round'] = True
        stats = state['power_stats']; stats['navigator_tokens'] += 1
        stats['navigator_token_pot_total'] += self.chest
        stats['navigator_token_round_total'] += self.round
        stats['navigator_token_during_song'] += song
        stats['navigator_token_low_lives'] += low
        stats['navigator_token_endgame_urgency'] += urgent

    def setup_round(self):
        self.swindler_trick_pending = 0
        super().setup_round()

    def sync_blocks(self):
        queen = self.power_index.get('Siren Queen')
        self.blocks = [max(self.cannon_blocks[p],0 if self.lock_kind == 'song' and p == queen
                       else self.lock_remaining) for p in range(self.player_count)]

    def admiral_curse_active(self):
        admiral = self.power_index.get('Undead Admiral')
        return admiral is not None and self.status[admiral] == 'harbor'

    def hazard_immune(self,p,maroon=False,forecast=False):
        if self.powers[p] == 'Tempest King': return self.states[p]['protection'] > 0
        if self.powers[p] in ('Siren Queen','Storm Warden'): return False
        return super().hazard_immune(p,maroon,forecast)

    def queen_collects_from(self,p):
        queen = self.power_index.get('Siren Queen')
        if queen is None: return False
        at = self.seating.index(queen)
        return p in (queen,self.seating[(at-1)%self.player_count],self.seating[(at+1)%self.player_count])

    def memory_reason(self,p):
        if self.powers[p] == 'Tempest King' and self.states[p]['protection']:
            return None
        if self.powers[p] == 'Storm Warden':
            from tournament import TournamentGame
            return TournamentGame.memory_reason(self,p)
        if self.powers[p] == 'Tempest King':
            with self.focus(p): return PowerGame.memory_reason(self,p)
        return super().memory_reason(p)

    def prophecy(self,p):
        if self.powers[p] == 'Siren Queen': return ExperimentGame.prophecy(self.views[p],0)
        return super().prophecy(p)

    def harbor(self,p,forced=False):
        if not forced and self.powers[p] == 'Tempest King' and self.status[p] == 'active':
            assert not self.states[p]['protection'], 'King voluntarily left before protected draw'
        if forced and self.status[p] == 'active' and self.powers[p] == 'Tide Watcher' and self.tide_self_card:
            self.tide_self_card = False
            self.states[p]['power_stats']['tide_personal_interrupted_by_forced_harbor'] += 1
        return super().harbor(p,forced)

    def fire_cannon_token(self,p,target):
        if self.powers[p] != 'Cannoneer' or self.safe() or not self.states[p]['tokens']: return False
        if target == p or self.status[target] != 'active': return False
        self.states[p]['tokens'] -= 1
        self.states[p]['power_stats']['cannon_tokens_spent'] += 1
        self.states[p]['power_stats']['cannoneer_targets_shot'] += 1
        self.harbor(target,True)
        return True

    def cannon_token_window(self):
        p = self.power_index.get('Cannoneer')
        if p is None or self.status[p] != 'active' or self.safe(): return
        others = [j for j in self.seating if j != p and self.status[j]=='active']
        if not others or len(others) > self.states[p]['tokens']: return
        # Save shots until others voluntarily depart, except late with ample pot.
        voluntary = any(rd==self.round and j!=p and not forced for rd,j,d,forced,chest,ships in self.departures)
        if not voluntary and not (self.round>=13 and self.chest>=300): return
        if self.chest < 100 or (self.ships[p]==1 and self.round<15): return
        if self.memory_reason(p): return
        for target in sorted(others,key=lambda j:self.gold[j],reverse=True):
            self.fire_cannon_token(p,target)
        self.states[p]['power_stats']['cannon_token_solo_opportunities'] += 1

    def windows(self,current):
        super().windows(current)
        self.cannon_token_window()

    def cannon(self,p):
        eligible = [j for j in self.seating if j != p and self.status[j]=='active' and self.powers[j] != 'Cannoneer']
        if not eligible: return
        if self.powers[p] == 'Cannoneer':
            for j in eligible: self.harbor(j,True)
            self.states[p]['power_stats']['cannoneer_targets_shot'] += len(eligible)
            self.states[p]['power_stats']['cannoneer_all_shots'] += 1
            return
        if self.powers[p] == 'Siren Queen':
            view = self.views[p]
            action = view.adaptive.choose('cannon',view,['grant_target','score_leader','fewest_ships','most_ships','random_target'])
            if action == 'random_target': target = self.rng.choice(eligible)
            elif action == 'fewest_ships': target = min(eligible,key=lambda j:self.ships[j])
            elif action == 'most_ships': target = max(eligible,key=lambda j:self.ships[j])
            elif action == 'score_leader': target = max(eligible,key=lambda j:self.gold[j])
            else: target = max(eligible,key=lambda j:self.gold[j]+30*self.ships[j])
            self.harbor(target,True)
            return
        mode = self.configs[p]['cannon']
        if mode == 'ships': target = max(eligible,key=lambda j:self.ships[j])
        elif mode == 'fewest': target = min(eligible,key=lambda j:self.ships[j])
        elif mode == 'power' and self.powers[p] == 'Blood Sailor':
            target = max(eligible,key=lambda j:(j not in self.states[p]['targets'],self.gold[j]))
        else: target = max(eligible,key=lambda j:self.gold[j])
        self.harbor(target,True)

    def finish_round_rewards(self):
        super().finish_round_rewards()
        swindler = self.power_index.get('Storm Swindler')
        if swindler is not None and self.swindler_trick_pending:
            self.award(swindler,self.swindler_trick_pending,'swindler_trick_payout')
            self.swindler_trick_pending = 0

    def sink(self,p,maroon=False):
        if self.status[p] != 'active': return
        power = self.powers[p]; state = self.states[p]
        if self.hazard_immune(p,maroon):
            state['power_stats']['hazards_ignored'] += 1
            if power == 'Siren Queen': state['power_stats']['queen_song_hazards_ignored'] += 1
            return
        repair = False; mechanic = self.power_index.get('Mechanic')
        if mechanic is not None and self.states[mechanic]['tokens']:
            s = self.states[mechanic]; c = self.configs[mechanic]
            if p == mechanic: repair = self.ships[p] <= c['repair_self_max_ships']
            elif self.repair_sales:
                mode = c['sell']
                offer = mode == 'always' or (mode == 'balanced' and (self.ships[mechanic] >= 3 or s['tokens'] > 1)) or (mode == 'reserve_two' and s['tokens'] > 2)
                value = 30+60*(15-self.round)/max(1,self.ships[p])
                repair = offer and self.gold[p] >= self.repair_price and value >= self.repair_price
                if offer: s['power_stats']['repair_offers'] += 1
                if repair: self.award(mechanic,self.repair_price,'repair_sale'); self.award(p,-self.repair_price,'repair_purchase')
            if repair:
                s['tokens'] -= 1; s['power_stats']['self_repairs' if p == mechanic else 'sold_repairs'] += 1
        old_ships = self.ships[p]
        ExperimentGame.sink(self,p,maroon)
        if maroon: self.gold[p] -= self.chest/2  # replace old full-pot Marooned payout
        if repair: self.ships[p] = old_ships
        if power == 'Storm Warden' and not (maroon and 'escape' in self.held[p]) and self.use_warden_token(p,ships_before=old_ships):
            state['tokens'] -= 1
            self.award(p,self.chest/2,'warden_insurance')
            state['power_stats']['warden_insured_chest_total'] += self.chest
        elif power == 'Storm Warden':
            state['power_stats']['warden_uninsured_sinkings'] += 1
        blood = self.power_index.get('Blood Sailor')
        if blood is not None:
            s = self.states[blood]
            if p in s['targets']:
                self.award(blood,self.blood_payment,'blood_sink')
                if self.ships[p] == 0 and p not in s['rewarded_targets']:
                    s['rewarded_targets'].add(p)
                    self.ships[blood] += 1; s['power_stats']['blood_ship_gained'] += 1
        admiral = self.power_index.get('Undead Admiral')
        if admiral is not None and p != admiral:
            s = self.states[admiral]; c = self.configs[admiral]
            if s['tokens'] and s['plunders_used'] < 1 and (self.chest >= c['plunder_min_gold'] or (self.round >= c['plunder_late'] and self.chest > 100)):
                s['tokens'] -= 1; s['plunders_used'] += 1; self.award(admiral,self.plunder_value(self.chest),'plunder')


    def draw(self,p):
        if not self.deck:
            if not self.discard: raise RuntimeError('No drawable cards')
            self.deck = self.discard; self.discard = []; self.rng.shuffle(self.deck)
            self.remaining = collections.Counter(self.deck+self.hidden_cards())
            self.known = [[] for _ in self.ships]
        safe = self.safe(); self.safe_next = False
        self.in_draw = True
        self.song_protected_draw = self.lock_kind == 'song' and self.lock_remaining > 0
        card = self.deck.pop(); self.remaining[card] -= 1
        for known in self.known:
            if known: known.pop(0)
        pending = list(self.pending)
        self.draws += 1; self.total_draws += 1; self.own_draws[p] += 1
        self.lock_remaining = max(0,self.lock_remaining-1)
        self.cannon_blocks = [max(0,x-1) for x in self.cannon_blocks]
        self.sync_blocks()
        effect = (self.echo_effect(p) if not safe else self.previous or 'echo') if card == 'echo' else card
        self.previous = effect; self.resolving = effect
        hold = False; holder = p; power = self.powers[p]
        swindler = self.power_index.get('Storm Swindler')
        captain = self.power_index.get('Cursed Captain')
        admiral = self.power_index.get('Undead Admiral')
        queen = self.power_index.get('Siren Queen')
        if safe:
            self.calm_cards[card] += 1
            self.chest += TREASURE.get(card,50 if card in HAZARDS else 0 if card in CURSES else 10)
        elif effect in TREASURE:
            if swindler is not None and self.states[swindler]['stolen_treasure'] < 1:
                self.states[swindler]['stolen_treasure'] += 1; hold = True; holder = swindler
                self.award(swindler,TREASURE[effect],'swindler_treasure')
            else:
                self.chest += TREASURE[effect]*(2 if power == 'Cannoneer' and self.status.count('active') == 1 else 1)
                if power == 'Cannoneer' and self.status.count('active') == 1: self.states[p]['power_stats']['cannoneer_extra_pot_gold'] += TREASURE[effect]
            if effect == 'diamond' and self.queen_collects_from(p):
                hold = True; holder = queen; self.queen_necklace_total += 1
                self.states[queen]['power_stats']['queen_necklaces_collected'] += 1
        elif effect in CURSES:
            if self.captain_collects_from(p):
                hold = self.collect_curse(captain,effect,card); holder = captain
            penalty = CURSES[effect] + (10 if self.admiral_curse_active() else 0)
            if p != captain or not self.captain_immune: self.chest = max(0,self.chest-penalty)
            if self.admiral_curse_active(): self.states[admiral]['power_stats']['admiral_extra_curse_uses'] += 1
        elif effect == 'surge':
            self.chest = self.chest*2 if self.chest else 100
            king = self.power_index.get('Tempest King')
            if king is not None and self.status[king] == 'active':
                # End-of-draw decrement leaves two subsequent table-wide draws.
                self.states[king]['protection'] = 3
                self.states[king]['power_stats']['king_surge_protection_triggers'] += 1
        elif effect in ('key','chest'):
            self.safe_next = True
            if self.queen_collects_from(p):
                hold = True; holder = queen
                self.states[queen]['power_stats']['queen_personal_'+effect+'_effects'] += 1
                self.queen_markers[effect] += 1
                self.states[queen]['power_stats']['queen_collected_'+effect] += 1
                while self.queen_markers['key'] and self.queen_markers['chest']:
                    self.queen_markers['key'] -= 1; self.queen_markers['chest'] -= 1
                    self.queen_markers += collections.Counter()  # discard zero-count keys
                    self.states[queen]['power_stats']['queen_pairs_cashed'] += 1
                    if self.ships[queen] < 8:
                        self.ships[queen] += 1
                        self.states[queen]['power_stats']['queen_ship_gained'] += 1
                    else:
                        self.states[queen]['power_stats']['queen_pairs_at_ship_cap'] += 1
        elif effect == 'siren':
            self.replace_lock('song',4)
        elif effect == 'whirlpool':
            # Whole card resolves before elimination/game-end checks.
            for j in range(self.player_count): self.sink(j)
        elif effect == 'marooned':
            immune = self.hazard_immune(p,True)
            self.sink(p,True); hold = not immune
            if not immune: self.marooned_players.add(p)
        elif effect == 'rudder':
            if power != 'Mechanic': self.harbor(p,True); self.gold[p] -= 30; hold = True
            else: self.states[p]['power_stats']['rudder_ignored'] += 1
        elif effect == 'escape': hold = 'escape' not in self.held[p]
        elif effect == 'trick':
            amount = 100 if power == 'Storm Swindler' else 20
            self.chest = max(0,self.chest-amount); hold = True
            if power == 'Storm Swindler':
                self.swindler_trick_pending += 100
                self.states[p]['power_stats']['swindler_trick_uses'] += 1
            else: self.gold[p] += amount
        elif effect == 'wave':
            self.deck.extend(self.discard); self.discard = []; self.rng.shuffle(self.deck)
            self.remaining = collections.Counter(self.deck+self.hidden_cards())
            self.known = [[] for _ in self.ships]; self.wants = [False]*self.player_count
            self.safe_next = True; self.gold[p] += 10; hold = True
        elif effect == 'prophecy':
            parrot = self.power_index.get('Parrot Whisperer')
            if parrot is not None:
                s = self.states[parrot]; before = s['tokens']; s['tokens'] = min(10,s['tokens']+1)
                s['power_stats']['parrot_tokens_gained'] += s['tokens']-before
            self.prophecy(p)
        elif effect == 'cannon':
            cannoneer = self.power_index.get('Cannoneer')
            if cannoneer is not None and p != cannoneer:
                self.states[cannoneer]['tokens'] += 1
                self.states[cannoneer]['power_stats']['cannon_tokens_gained'] += 1
            self.cannon(p)
        if hold: self.held[holder].append(effect); self.physical_held.append(card)
        else: self.discard.append(card)
        if not safe and effect == 'surge': self.last_surge = self.draws; self.followup_exits = [False]*self.player_count
        for j,s in enumerate(self.states):
            if pending[j]: self.followup_exits[j] = not(card == 'echo' and not safe and effect == 'surge'); self.pending[j] = False
            if s['protection']: s['protection'] -= 1
        if self.chest >= 9999:
            self.chest = 9999
            for j in range(self.player_count): self.harbor(j,True)
        self.resolved_card(p,card,effect,safe)
        self.in_draw = False
        if not self.lock_remaining: self.lock_kind = None
        self.sync_blocks()
        self.check_end()



    def play(self):
        while self.round < 15 and not self.ended:
            self.setup_round(); cursor = 0
            while 'active' in self.status and not self.ended:
                while self.status[self.seating[cursor]] != 'active': cursor = (cursor+1)%self.player_count
                self.current = self.seating[cursor]; self.windows(self.current)
                if 'active' not in self.status: break
                if self.status[self.current] == 'active': self.draw(self.current)
                cursor = (cursor+1)%self.player_count
                if self.draws > 10000: raise RuntimeError('Round safety bound')
            self.finish_round_rewards()
            assert collections.Counter(self.deck+self.discard+self.physical_held+self.hidden_cards()) == self.initial_counts
            for p in range(self.player_count):
                self.round_data.append({'game':self.game_id,'round':self.round,'bot':p,'seat':self.seating.index(p),
                    'round_gold':self.gold[p]-self.round_begin[p]-self.round_bonus[p], 'harbor_gold':self.harbor_gold[p],
                    'additional_gold':self.gold[p]-self.round_begin[p]-self.round_bonus[p]-self.harbor_gold[p],
                    'ships_start':self.round_ships[p], 'ships_end':self.ships[p], 'status':self.status[p],
                    'round_draws':self.draws,'own_draws':self.own_draws[p]})
        if not self.ended:
            most = max(self.ships)
            if self.ships.count(most) == 1:
                p = self.ships.index(most); self.gold[p] += 100; self.game_bonus[p] += 100
        for p,power in enumerate(self.powers):
            self.sell_gold[p] = self.ships[p]*(60 if power == 'Merchant' else 30)
            self.gold[p] += self.sell_gold[p]
            if power == 'Merchant':
                premium = self.ships[p]*30
                self.power_gold[p] += premium; self.states[p]['power_stats']['merchant_ship_premium_gold'] += premium
            token_value = {'Mechanic':30,'Parrot Whisperer':10,'Undead Admiral':10,'Navigator':10,'Cannoneer':10}.get(power,0)
            if token_value:
                amount = self.states[p]['tokens']*token_value; self.gold[p] += amount; self.game_bonus[p] += amount
                self.power_gold[p] += amount; self.states[p]['power_stats']['token_sale_gold'] += amount
            if power == 'Siren Queen':
                amount = 30*self.queen_necklace_total
                self.gold[p] += amount; self.game_bonus[p] += amount; self.power_gold[p] += amount
                self.states[p]['power_stats']['queen_necklace_gold'] += amount
            assert abs(sum(r['round_gold'] for r in self.round_data if r['bot'] == p)+self.game_bonus[p]+self.sell_gold[p]-self.gold[p]) < 1e-6
        best = max(self.gold); winners = [p for p,x in enumerate(self.gold) if abs(x-best) < 1e-8]
        return [1/len(winners) if p in winners else 0. for p in range(self.player_count)]

    def resolved_card(self,p,card,effect,safe):
        # Revision2's set-size assertion does not apply to duplicate inventory.
        BalancedGame.resolved_card(self,p,card,effect,safe)
        if self.powers[p]=='Siren Queen' and card in ('key','chest'):
            self.states[p]['power_stats']['queen_raw_'+card+('_calm' if safe else '_normal')] += 1
        if self.parrot_reserved:
            parrot=self.power_index.get('Parrot Whisperer')
            if p==parrot and not safe and effect in ('escape','prophecy','trick','cannon','wave'):
                self.states[p]['power_stats']['parrot_personal_received'] += 1
            self.parrot_reserved=False
        assert all(s['plunders_used']<=1 for s in self.states)
        assert all(n>=0 for n in self.queen_markers.values())
        assert not (self.queen_markers['key'] and self.queen_markers['chest'])


"""Six-ship trained Sea Witch and 25-gold Merchant harbor bonus."""
import json
from pathlib import Path
from powers.witch_strategy_20260926 import LearningWitchGame
STRATEGY_PATH=Path(__file__).resolve().parent/'locked'/'sea_witch_bot.json'
class ExpansionGameV4(LearningWitchGame):
 merchant_bonus=25
 def __init__(self,*args,**kwargs):
  kwargs.setdefault('strategy',json.loads(STRATEGY_PATH.read_text())['strategy'])
  super().__init__(*args,**kwargs)
  witch=self.power_index.get('Sea Witch')
  if witch is not None:self.ships[witch]=6

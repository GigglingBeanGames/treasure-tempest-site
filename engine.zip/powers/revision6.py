"""Revision 6: selective Parrot tokens, Navigator block income, other-player plunder."""
from .revision5 import Revision5Game
from .engine import ExperimentGame


class Revision6Game(Revision5Game):
    def setup_round(self):
        self.parrot_attempt_at = None
        super().setup_round()

    def parrot_use_chance(self,p):
        starters = sum(n > 0 for n in self.round_ships)
        departed = sum(self.round_ships[j] > 0 and self.status[j] != 'active'
                       for j in range(self.player_count) if j != p)
        fraction = departed/max(1,starters-1)
        return min(1., .1 + .45*fraction + .65*max(0,self.chest)/500)

    def parrot_window(self,p):
        if self.status[p] != 'active' or self.safe() or self.next_drawer() != p: return
        if 'harbor' not in self.status: return
        if not self.states[p]['tokens'] or not self.deck: return
        if self.parrot_token_at == self.draws or self.parrot_attempt_at == self.draws: return
        known = self.known[p]
        if known and (len(known)>=2 or known[0] not in ('whirlpool','marooned','rudder')): return
        self.parrot_attempt_at = self.draws
        chance = self.parrot_use_chance(p)
        self.states[p]['power_stats']['parrot_eligible_opportunities'] += 1
        if self.rng.random() >= chance: return
        # Existing rearrangement policy; no per-round spending limit.
        super().parrot_window(p)

    def sink(self,p,maroon=False):
        if self.status[p] != 'active': return
        power = self.powers[p]; state = self.states[p]
        if self.hazard_immune(p,maroon):
            state['power_stats']['hazards_ignored'] += 1
            if power == 'Navigator': self.award(p,30,'navigator_block')
            if power == 'Siren Queen': state['power_stats']['queen_song_hazards_ignored'] += 1
            return
        repair = False; mechanic = self.power_index.get('Mechanic')
        if mechanic is not None and self.states[mechanic]['tokens']:
            s = self.states[mechanic]; c = self.configs[mechanic]
            if p == mechanic: repair = self.ships[p] <= c['repair_self_max_ships']
            elif self.repair_sales:
                mode = c['sell']
                offer = mode == 'always' or (mode == 'balanced' and (self.ships[mechanic] >= 3 or s['tokens'] > 1)) or (mode == 'reserve_two' and s['tokens'] > 2)
                value = 30+60*(15-self.round)/max(1,self.ships[p])
                repair = offer and self.gold[p] >= self.repair_price and value >= self.repair_price
                if offer: s['power_stats']['repair_offers'] += 1
                if repair: self.award(mechanic,self.repair_price,'repair_sale'); self.award(p,-self.repair_price,'repair_purchase')
            if repair:
                s['tokens'] -= 1; s['power_stats']['self_repairs' if p == mechanic else 'sold_repairs'] += 1
        old_ships = self.ships[p]
        ExperimentGame.sink(self,p,maroon)
        if repair: self.ships[p] = old_ships
        if power == 'Storm Warden' and self.use_warden_token(p,ships_before=old_ships):
            state['tokens'] -= 1
            self.award(p,self.chest/2,'warden_insurance')
            state['power_stats']['warden_insured_chest_total'] += self.chest
        elif power == 'Storm Warden':
            state['power_stats']['warden_uninsured_sinkings'] += 1
        blood = self.power_index.get('Blood Sailor')
        if blood is not None:
            s = self.states[blood]
            if p in s['targets']:
                self.award(blood,self.blood_payment,'blood_sink')
                if self.ships[p] == 0 and p not in s['rewarded_targets']:
                    s['rewarded_targets'].add(p)
                    self.ships[blood] += 1; s['power_stats']['blood_ship_gained'] += 1
        admiral = self.power_index.get('Undead Admiral')
        if admiral is not None and p != admiral:
            s = self.states[admiral]; c = self.configs[admiral]
            if s['tokens'] and s['plunders_used'] < 1 and (self.chest >= c['plunder_min_gold'] or (self.round >= c['plunder_late'] and self.chest > 100)):
                s['tokens'] -= 1; s['plunders_used'] += 1; self.award(admiral,self.plunder_value(self.chest),'plunder')


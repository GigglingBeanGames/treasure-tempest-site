"""Sixteen powers: Marooned Monarch and reintroduced Storm Swindler."""
import inspect,textwrap
from pathlib import Path
import powers.expansion_20260926 as old
from powers.expansion_v4_20260926 import ExpansionGameV4
from powers.revision28 import Revision28Actor
from powers.config import POWERS
POWERS.update({'Marooned Monarch':6,'New Storm Swindler':6})
class NewRules(old.ExpansionRules):pass
# Reuse the audited expansion draw ordering, changing only treasure interception
# and removing all legacy Swindler Tempest Trick bonuses.
text=Path(old.__file__).read_text();snippet=text[text.index('# Keep the existing complete draw ordering'):text.index('\nclass ExpansionGame(')]
namespace=dict(vars(old));exec(snippet,namespace)
source=namespace['source']
source=source.replace("self.award(swindler,TREASURE[effect],'swindler_treasure')", "self.swindler_treasure_pending += 2*TREASURE[effect]\n            self.states[swindler]['power_stats']['treasure_collected_'+effect] += 1")
a=source.index("        amount = 100 if power == 'Storm Swindler' else 20")
b=source.index("    elif effect == 'wave':",a)
source=source[:a]+"        amount = 20\n        self.chest = max(0,self.chest-amount); hold = True\n        self.gold[p] += amount\n"+source[b:]
ns={};exec(source,vars(old),ns);NewRules.draw=ns['draw']
class NewActor(old.ExpansionActor):pass
# The legacy Swindler estimate assumed a 100-gold Trick; it is normal now.
import powers.revision28 as rev
source=textwrap.dedent(inspect.getsource(Revision28Actor.risk_harbor)).replace("if g.power == 'Storm Swindler' and effect == 'trick': d = 100-min(self.chest,100)","if g.power == 'Storm Swindler' and effect == 'trick': d = 20-min(self.chest,20)")
ns={};exec(source,vars(rev),ns);NewActor.risk_harbor=ns['risk_harbor']
class ExpansionGameV5(ExpansionGameV4,NewRules):
 def __init__(self,session,seed,powers,opponents,configs=None,**kwargs):
  self.swindler_treasure_pending=0
  mapped=['New Storm Swindler' if p=='Storm Swindler' else p for p in powers]
  super().__init__(session,seed,mapped,opponents,configs,**kwargs)
  self.powers=list(powers);self.power_index={name:p for p,name in enumerate(powers)}
  for p,name in enumerate(powers):
   if name=='Storm Swindler':
    self.ships[p]=6;actor=NewActor(old.SeatContext(self,p),p);actor.expansion_world=self
    if p==0:self.bot_human=actor;self.views[p]=old.HumanView(actor,self)
    else:self.views[p]=actor
 def setup_round(self):
  self.swindler_treasure_pending=0
  return super().setup_round()
 def finish_round_rewards(self):
  p=self.power_index.get('Storm Swindler')
  if p is not None and self.swindler_treasure_pending:
   self.award(p,self.swindler_treasure_pending,'swindler_treasure');self.swindler_treasure_pending=0
  return super().finish_round_rewards()
 def hazard_immune(self,p,maroon=False,forecast=False):
  if self.powers[p]=='Marooned Monarch' and maroon:return True
  return super().hazard_immune(p,maroon,forecast)
 def sink(self,p,maroon=False):
  before=self.status[p];result=super().sink(p,maroon)
  monarch=self.power_index.get('Marooned Monarch')
  if monarch is not None and before=='active' and self.status[p]=='sunk' and maroon:
   self.award(monarch,50,'monarch_marooned')
  return result

"""Revision 4: repair reserves, two-card Idol locks, Navigator treasure and Queen necklaces."""
import collections
import itertools
import math
from .revision2 import RevisionGame, RevisionActor
from .balanced import BalancedGame
from .multi import SeatContext
from .engine import Game, ExperimentGame, TREASURE, CURSES, HAZARDS

class Revision4Actor(RevisionActor):
    def should_harbor(self,p=0):
        g = self.g
        if g.power == 'Parrot Whisperer' and self.status[0]=='active' and g.world.parrot_reserved:
            if self.known[0] and self.known[0][0] in ('escape','prophecy','trick','cannon','wave'):
                return False
        return super().should_harbor(p)

    def risk_harbor(self,boost=1.):
        # Same saved policy calculation with the revised rules represented.
        g = self.g; counts = collections.Counter(self.known[0][:1]) if self.known[0] else self.remaining
        n = sum(counts.values())
        if not n: return True
        gain = loss = shiprisk = 0.
        for card,count in counts.items():
            effect = g.world.choose_echo(self.p) if card == 'echo' and g.power == 'Navigator' else (self.previous if card == 'echo' else card)
            d,w,s = Game.expected_card(self,effect or 'echo',0)
            if g.power == 'Storm Swindler' and effect == 'trick': d = 50-min(self.chest,50)
            if g.power == 'Cursed Captain' and effect in CURSES: d += g.world.curse_marginal(effect)
            if g.power == 'Tempest King' and self.status.count('active') == 1 and effect in TREASURE: d *= 2
            if effect in HAZARDS and g.world.hazard_immune(self.p,effect == 'marooned',forecast=True): d,w,s = 0,0,0
            if g.power == 'Navigator' and g.protection and effect in HAZARDS: d,w,s = 0,0,0
            gain += count*d/n; loss += count*w/n; shiprisk += count*s/n
        ships = self.ships[0]
        value = 0. if self.round == 15 else (30+22*(16-self.round)/max(1,ships))*(1.55 if ships<=3 else 1)*(2 if ships==1 else 1)
        if g.power == 'Mechanic' and g.tokens: value *= .25
        lost_fraction = .5 if 'escape' in self.held[0] else 1.
        if g.power == 'Storm Warden' and g.world.use_warden_token(self.p): lost_fraction = 0. if 'escape' in self.held[0] else .5
        risk = loss*self.chest*lost_fraction+shiprisk*value
        if g.power == 'Merchant': risk += g.world.merchant_bonus*g.config['harbor_bonus_weight']*loss
        appetite = self.appetite[0]*(1.8 if self.desperate(0) else 1.)
        return risk > max(4,gain+8)*appetite*boost*self.preference_multiplier()

class Revision4Game(RevisionGame):
    starting_tokens = {'Mechanic':3,'Navigator':5,'Parrot Whisperer':2,'Undead Admiral':3,'Storm Warden':3}

    def __init__(self,*args,**kwargs):
        self.parrot_token_at = None; self.parrot_reserved = False; self.queen_necklaces = 0
        super().__init__(*args,**kwargs)
        self.queen_markers = collections.Counter()
        for p,power in enumerate(self.powers):
            if power == 'Storm Warden': self.ships[p] = 5
            if power: self.views[p] = Revision4Actor(SeatContext(self,p),p)

    def setup_round(self):
        self.parrot_token_at = None; self.parrot_reserved = False; self.queen_necklaces = 0
        super().setup_round()

    @staticmethod
    def plunder_value(chest):
        # 20% rounded up to a multiple of five; binary fractions remain exact.
        return 5*math.ceil(chest/25)

    def choose_echo(self,p): return self.previous or 'echo'
    def echo_effect(self,p): return self.previous or 'echo'

    def mechanic_offer(self,p):
        # A sunk/harbored mechanic cannot lose another ship this round.
        exposures = 15-self.round + (self.status[p] == 'active')
        reserve = max(0, exposures-self.ships[p])
        return self.states[p]['tokens'] > reserve

    def mechanic_smooth_sailor_repair(self,p):
        if self.round != 15: return False
        others = []
        for j in range(self.player_count):
            if j == p: continue
            ships = self.ships[j]
            # During a Whirlpool, later seats still have their sinking pending.
            if self.resolving == 'whirlpool' and self.status[j] == 'active' and not self.hazard_immune(j,False):
                ships = max(0,ships-1)
            others.append(ships)
        most = max(others,default=0)
        return self.ships[p] > most and self.ships[p]-1 <= most

    def finish_round_rewards(self):
        queen = self.power_index.get('Siren Queen')
        if queen is not None and self.queen_necklaces:
            self.award(queen,30*self.queen_necklaces,'queen_necklace')
            self.queen_necklaces = 0

    def power_window(self):
        if self.power == 'Parrot Whisperer': self.parrot_window(self.owner)
        else: super().power_window()

    def parrot_window(self,p):
        if self.status[p]!='active' or self.safe() or self.next_drawer()!=p: return
        if not self.states[p]['tokens'] or not self.deck or self.parrot_token_at == self.draws: return
        known = self.known[p]
        # Known safe cards need no further token; allow reconsidering a known
        # hazard if the unseen second card could be better.
        if known and (len(known)>=2 or known[0] not in ('whirlpool','marooned','rudder')): return
        self.states[p]['tokens'] -= 1; self.parrot_token_at = self.draws
        self.states[p]['power_stats']['parrot_token_prophecies'] += 1
        self.parrot_rearrange(p,token=True)
        self.parrot_reserved = bool(self.known[p] and self.known[p][0] in ('escape','prophecy','trick','cannon','wave'))
        if self.parrot_reserved: self.states[p]['power_stats']['parrot_personal_reserved'] += 1

    def windows(self,current):
        super().windows(current)
        p = self.power_index.get('Parrot Whisperer')
        if p is not None:
            self.parrot_window(p)
            if not self.known[p]: self.parrot_reserved = False
            if self.status[p]=='active' and self.memory_reason(p) and not self.safe() and not self.blocks[p] and not self.refuse_exit(p):
                self.harbor(p)

    def prophecy(self,p):
        if self.powers[p] == 'Parrot Whisperer': return self.parrot_rearrange(p,token=False)
        return super().prophecy(p)

    def parrot_rearrange(self,p,token=False):
        k = min(2,len(self.deck))
        if not k: return
        cards = list(reversed(self.deck[-k:])); mode = self.configs[p]['prophecy']
        active = [j for j in self.seating if self.status[j]=='active']; at = active.index(p)
        offset = 0 if token else 1
        def value(card,recipient):
            own = recipient == p
            if card == 'whirlpool': return -1000 if self.blocks[p] else -200
            if card in ('marooned','rudder'): return -500 if own else 100 if mode!='safe' else -20
            if card in CURSES: return -CURSES[card]
            if card == 'siren': return -80
            if card == 'surge': return 300 if mode=='surge' else 100
            if card in TREASURE: return TREASURE[card]
            if card in ('escape','trick','prophecy','cannon'): return 90 if own else -20
            if card == 'wave': return 40 if own else 20
            if card in ('key','chest'): return 35
            return 20
        options = [(list(order),[]) for order in sorted(set(itertools.permutations(cards)))]
        if k==2:
            options += [([cards[1]],[cards[0]]),([cards[0]],[cards[1]])]
        order,bottom = max(options,key=lambda option:sum(value(card,active[(at+i+offset)%len(active)])/(i+1) for i,card in enumerate(option[0])))
        del self.deck[-k:]; self.deck[0:0]=bottom; self.deck.extend(reversed(order))
        self.known=[[] for _ in self.ships];self.known[p]=order.copy();self.wants=[False]*self.player_count
        prefix = 'parrot_token' if token else 'prophecy'
        stats=self.states[p]['power_stats']
        if not token: stats['prophecy_uses'] += 1
        stats[prefix+'_top_'+order[0]] += 1
        for card in bottom: stats[prefix+'_bottom_'+card] += 1

    def resolved_card(self,p,card,effect,safe):
        # Revision2's set-size assertion does not apply to duplicate inventory.
        BalancedGame.resolved_card(self,p,card,effect,safe)
        if self.powers[p]=='Siren Queen' and card in ('key','chest'):
            self.states[p]['power_stats']['queen_raw_'+card+('_calm' if safe else '_normal')] += 1
        if self.parrot_reserved:
            parrot=self.power_index.get('Parrot Whisperer')
            if p==parrot and not safe and effect in ('escape','prophecy','trick','cannon','wave'):
                self.states[p]['power_stats']['parrot_personal_received'] += 1
            self.parrot_reserved=False
        assert len(self.captain_cards)<=3
        assert all(s['plunders_used']<=1 for s in self.states)
        assert all(n>=0 for n in self.queen_markers.values())
        assert not (self.queen_markers['key'] and self.queen_markers['chest'])

    def curse_marginal(self,effect):
        if len(self.captain_cards) < 3: return CURSES[effect]
        return max(0,CURSES[effect]-min(CURSES[e] for e,c in self.captain_cards))

    def collect_curse(self,p,effect,physical):
        stats = self.states[p]['power_stats']
        if len(self.captain_cards) < 3:
            self.captain_cards.append((effect,physical))
            self.award(p,CURSES[effect],'cursed_captain')
            return True
        old_effect,old_physical = min(self.captain_cards,key=lambda pair:CURSES[pair[0]])
        if CURSES[effect] > CURSES[old_effect]:
            self.captain_cards.remove((old_effect,old_physical))
            self.held[p].remove(old_effect); self.physical_held.remove(old_physical)
            self.discard.append(old_physical)
            self.captain_cards.append((effect,physical))
            self.award(p,CURSES[effect]-CURSES[old_effect],'captain_replacement')
            return True
        stats['captain_curses_rejected'] += 1
        return False

    def sink(self,p,maroon=False):
        if self.status[p] != 'active': return
        power = self.powers[p]; state = self.states[p]
        if self.hazard_immune(p,maroon):
            state['power_stats']['hazards_ignored'] += 1
            if power == 'Siren Queen': state['power_stats']['queen_song_hazards_ignored'] += 1
            return
        repair = False; mechanic = self.power_index.get('Mechanic')
        if mechanic is not None and self.states[mechanic]['tokens']:
            s = self.states[mechanic]; c = self.configs[mechanic]
            if p == mechanic:
                bonus_repair = self.mechanic_smooth_sailor_repair(p)
                repair = bonus_repair or self.ships[p] <= c['repair_self_max_ships']
                if bonus_repair: s['power_stats']['smooth_sailor_repairs'] += 1
            elif self.repair_sales:
                mode = c['sell']
                offer = self.mechanic_offer(mechanic)
                value = 30+60*(15-self.round)/max(1,self.ships[p])
                repair = offer and self.gold[p] >= self.repair_price and value >= self.repair_price
                if offer: s['power_stats']['repair_offers'] += 1
                if repair: self.award(mechanic,self.repair_price,'repair_sale'); self.award(p,-self.repair_price,'repair_purchase')
            if repair:
                s['tokens'] -= 1; s['power_stats']['self_repairs' if p == mechanic else 'sold_repairs'] += 1
        old_ships = self.ships[p]
        ExperimentGame.sink(self,p,maroon)
        if repair: self.ships[p] = old_ships
        if power == 'Storm Warden' and self.use_warden_token(p,ships_before=old_ships):
            state['tokens'] -= 1
            self.award(p,self.chest/2,'warden_insurance')
            state['power_stats']['warden_insured_chest_total'] += self.chest
        elif power == 'Storm Warden':
            state['power_stats']['warden_uninsured_sinkings'] += 1
        blood = self.power_index.get('Blood Sailor')
        if blood is not None:
            s = self.states[blood]
            if p in s['targets']:
                self.award(blood,self.blood_payment,'blood_sink')
                if self.ships[p] == 0 and p not in s['rewarded_targets']:
                    s['rewarded_targets'].add(p)
                    self.ships[blood] += 1; s['power_stats']['blood_ship_gained'] += 1
        admiral = self.power_index.get('Undead Admiral')
        if admiral is not None:
            s = self.states[admiral]; c = self.configs[admiral]
            if s['tokens'] and s['plunders_used'] < 1 and (self.chest >= c['plunder_min_gold'] or (self.round >= c['plunder_late'] and self.chest > 100)):
                s['tokens'] -= 1; s['plunders_used'] += 1; self.award(admiral,self.plunder_value(self.chest),'plunder')

    def draw(self,p):
        if not self.deck:
            if not self.discard: raise RuntimeError('No drawable cards')
            self.deck = self.discard; self.discard = []; self.rng.shuffle(self.deck)
            self.remaining = collections.Counter(self.deck+self.hidden_cards())
            self.known = [[] for _ in self.ships]
        safe = self.safe(); self.safe_next = False
        self.in_draw = True
        self.song_protected_draw = self.lock_kind == 'song' and self.lock_remaining > 0
        card = self.deck.pop(); self.remaining[card] -= 1
        for known in self.known:
            if known: known.pop(0)
        pending = list(self.pending)
        self.draws += 1; self.total_draws += 1; self.own_draws[p] += 1
        self.lock_remaining = max(0,self.lock_remaining-1)
        self.cannon_blocks = [max(0,x-1) for x in self.cannon_blocks]
        self.sync_blocks()
        effect = (self.echo_effect(p) if not safe else self.previous or 'echo') if card == 'echo' else card
        self.previous = effect; self.resolving = effect
        hold = False; holder = p; power = self.powers[p]
        swindler = self.power_index.get('Storm Swindler')
        captain = self.power_index.get('Cursed Captain')
        admiral = self.power_index.get('Undead Admiral')
        queen = self.power_index.get('Siren Queen')
        if safe:
            self.calm_cards[card] += 1
            self.chest += TREASURE.get(card,50 if card in HAZARDS else 0 if card in CURSES else 10)
        elif effect in TREASURE:
            if swindler is not None and not self.states[swindler]['stolen_treasure']:
                self.states[swindler]['stolen_treasure'] = True; hold = True; holder = swindler
                self.award(swindler,TREASURE[effect],'swindler_treasure')
            else: self.chest += TREASURE[effect]*(2 if power == 'Tempest King' and self.status.count('active') == 1 else 1)
            if p == queen and effect == 'diamond':
                hold = True; holder = p; self.queen_necklaces += 1
                self.states[p]['power_stats']['queen_necklaces_collected'] += 1
        elif effect in CURSES:
            if captain is not None:
                hold = self.collect_curse(captain,effect,card); holder = captain
            if p != captain or not self.captain_immune: self.chest = max(0,self.chest-CURSES[effect])
            if admiral is not None and effect == 'idol':
                self.replace_lock('idol',2)
                self.states[admiral]['power_stats']['admiral_idol_blocks'] += 1
        elif effect == 'surge': self.chest = self.chest*2 if self.chest else 100
        elif effect in ('key','chest'):
            self.safe_next = True
            if p == queen:
                hold = True
                self.states[p]['power_stats']['queen_personal_'+effect+'_effects'] += 1
                self.queen_markers[effect] += 1
                self.states[p]['power_stats']['queen_collected_'+effect] += 1
                while self.queen_markers['key'] and self.queen_markers['chest']:
                    self.queen_markers['key'] -= 1; self.queen_markers['chest'] -= 1
                    self.queen_markers += collections.Counter()  # discard zero-count keys
                    self.states[p]['power_stats']['queen_pairs_cashed'] += 1
                    if self.ships[p] < 8:
                        self.ships[p] += 1
                        self.states[p]['power_stats']['queen_ship_gained'] += 1
                    else:
                        self.states[p]['power_stats']['queen_pairs_at_ship_cap'] += 1
        elif effect == 'siren':
            self.replace_lock('song',4)
        elif effect == 'whirlpool':
            # Whole card resolves before elimination/game-end checks.
            for j in range(self.player_count): self.sink(j)
        elif effect == 'marooned':
            immune = self.hazard_immune(p,True)
            self.sink(p,True); hold = not immune
            if not immune: self.marooned_players.add(p)
        elif effect == 'rudder':
            if power not in ('Mechanic','Tempest King'): self.harbor(p,True); self.gold[p] -= 30; hold = True
            else: self.states[p]['power_stats']['rudder_ignored'] += 1
        elif effect == 'escape': hold = 'escape' not in self.held[p]
        elif effect == 'trick':
            amount = 50 if power == 'Storm Swindler' else 20
            self.chest = max(0,self.chest-amount); self.gold[p] += amount; hold = True
            if amount == 50:
                self.power_gold[p] += 30; self.states[p]['power_stats']['swindler_extra_trick_gold'] += 30
                self.states[p]['power_stats']['swindler_trick_uses'] += 1
        elif effect == 'wave':
            treasure = max((c for c in self.discard if c in TREASURE),key=TREASURE.get,default=None) if power == 'Navigator' else None
            if treasure is not None: self.discard.remove(treasure)
            self.deck.extend(self.discard); self.discard = []; self.rng.shuffle(self.deck)
            if treasure is not None:
                self.deck.append(treasure)
                self.states[p]['power_stats']['navigator_wave_top_'+treasure] += 1
            self.remaining = collections.Counter(self.deck+self.hidden_cards())
            self.known = [[] for _ in self.ships]; self.wants = [False]*self.player_count
            if treasure is not None: self.known = [[treasure] for _ in self.ships]
            self.safe_next = True; self.gold[p] += 10; hold = True
        elif effect == 'prophecy':
            parrot = self.power_index.get('Parrot Whisperer')
            if parrot is not None:
                s = self.states[parrot]; before = s['tokens']; s['tokens'] = min(10,s['tokens']+1)
                s['power_stats']['parrot_tokens_gained'] += s['tokens']-before
            self.prophecy(p)
        elif effect == 'cannon': self.cannon(p)
        if hold: self.held[holder].append(effect); self.physical_held.append(card)
        else: self.discard.append(card)
        if not safe and effect == 'surge': self.last_surge = self.draws; self.followup_exits = [False]*self.player_count
        for j,s in enumerate(self.states):
            if pending[j]: self.followup_exits[j] = not(card == 'echo' and not safe and effect == 'surge'); self.pending[j] = False
            if s['protection']: s['protection'] -= 1
        if self.chest >= 9999:
            self.chest = 9999
            for j in range(self.player_count): self.harbor(j,True)
        self.resolved_card(p,card,effect,safe)
        self.in_draw = False
        if not self.lock_remaining: self.lock_kind = None
        self.sync_blocks()
        self.check_end()


    def play(self):
        while self.round < 15 and not self.ended:
            self.setup_round(); cursor = 0
            while 'active' in self.status and not self.ended:
                while self.status[self.seating[cursor]] != 'active': cursor = (cursor+1)%self.player_count
                self.current = self.seating[cursor]; self.windows(self.current)
                if 'active' not in self.status: break
                if self.status[self.current] == 'active': self.draw(self.current)
                cursor = (cursor+1)%self.player_count
                if self.draws > 10000: raise RuntimeError('Round safety bound')
            self.finish_round_rewards()
            assert collections.Counter(self.deck+self.discard+self.physical_held+self.hidden_cards()) == self.initial_counts
            for p in range(self.player_count):
                self.round_data.append({'game':self.game_id,'round':self.round,'bot':p,'seat':self.seating.index(p),
                    'round_gold':self.gold[p]-self.round_begin[p]-self.round_bonus[p], 'harbor_gold':self.harbor_gold[p],
                    'additional_gold':self.gold[p]-self.round_begin[p]-self.round_bonus[p]-self.harbor_gold[p],
                    'ships_start':self.round_ships[p], 'ships_end':self.ships[p], 'status':self.status[p],
                    'round_draws':self.draws,'own_draws':self.own_draws[p]})
        if not self.ended:
            most = max(self.ships)
            if self.ships.count(most) == 1:
                p = self.ships.index(most); self.gold[p] += 100; self.game_bonus[p] += 100
        for p,power in enumerate(self.powers):
            self.sell_gold[p] = self.ships[p]*(50 if power == 'Merchant' else 30)
            self.gold[p] += self.sell_gold[p]
            if power == 'Merchant':
                premium = self.ships[p]*20
                self.power_gold[p] += premium; self.states[p]['power_stats']['merchant_ship_premium_gold'] += premium
            token_value = {'Mechanic':30,'Parrot Whisperer':10,'Undead Admiral':10}.get(power,0)
            if token_value:
                amount = self.states[p]['tokens']*token_value; self.gold[p] += amount; self.game_bonus[p] += amount
                self.power_gold[p] += amount; self.states[p]['power_stats']['token_sale_gold'] += amount
            assert abs(sum(r['round_gold'] for r in self.round_data if r['bot'] == p)+self.game_bonus[p]+self.sell_gold[p]-self.gold[p]) < 1e-6
        best = max(self.gold); winners = [p for p,x in enumerate(self.gold) if abs(x-best) < 1e-8]
        return [1/len(winners) if p in winners else 0. for p in range(self.player_count)]

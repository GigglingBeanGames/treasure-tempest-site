"""Monarch earns 60 per Marooned; Swindler treasure pays printed value."""
from powers.expansion_v5_20260926 import ExpansionGameV5
class ExpansionGameV6(ExpansionGameV5):
 def draw(self,p):
  before=self.hexes
  result=super().draw(p)
  gained=self.hexes-before
  witch=self.power_index.get('Sea Witch')
  if gained and witch is not None:
   value=10*gained
   for j in range(self.player_count):
    change=value if j==witch else -value
    self.gold[j]+=change
    self.states[j]['power_stats']['hex_immediate_gold']+=change
  return result
 def sink(self,p,maroon=False):
  blood=self.power_index.get('Blood Sailor')
  state=self.states[blood] if blood is not None else None
  target=state is not None and p in state['targets'] and p not in state['rewarded_targets']
  before=self.ships[p]
  # Suppress the inherited last-ship trigger. The current rule rewards the
  # first real transition to one ship instead.
  if target:state['rewarded_targets'].add(p)
  result=super().sink(p,maroon)
  if target:
   state['rewarded_targets'].remove(p)
   if before>1 and self.ships[p]==1:
    state['rewarded_targets'].add(p);self.ships[blood]+=1
    state['power_stats']['blood_ship_gained']+=1
  return result
 def award(self,p,amount,reason):
  if reason=='monarch_marooned':amount=75
  elif reason=='swindler_treasure':amount/=2
  return super().award(p,amount,reason)
 def play(self):
  super().play()
  # Older expansion layers settle Hexes at game end. Remove that legacy
  # settlement because V6 applies every Hex immediately when collected.
  witch=self.power_index.get('Sea Witch')
  for p in range(self.player_count):
   settled=self.states[p]['power_stats']['hex_endgame_gold']
   if settled:
    self.gold[p]-=settled;self.game_bonus[p]-=settled
    self.states[p]['power_stats']['hex_endgame_gold']=0
    if p==witch:self.power_gold[p]-=settled
  for p in range(self.player_count):
   assert abs(sum(r['round_gold'] for r in self.round_data if r['bot']==p)+self.game_bonus[p]+self.sell_gold[p]-self.gold[p])<1e-6
  high=max(self.gold);winners=[p for p,gold in enumerate(self.gold) if gold==high]
  return [1/len(winners) if p in winners else 0. for p in range(self.player_count)]

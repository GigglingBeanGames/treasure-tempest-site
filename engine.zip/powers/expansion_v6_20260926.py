"""Monarch earns 60 per Marooned; Swindler treasure pays printed value."""
from powers.expansion_v5_20260926 import ExpansionGameV5
class ExpansionGameV6(ExpansionGameV5):
 def award(self,p,amount,reason):
  if reason=='monarch_marooned':amount=60
  elif reason=='swindler_treasure':amount/=2
  return super().award(p,amount,reason)

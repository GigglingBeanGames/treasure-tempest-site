"""Authoritative Treasure Tempest balance rules locked on 2026-10-02.

These values are the exact configuration independently confirmed by the
50,000-game ``warden_seven_50000`` simulation.  Unlike the balance-lab class,
this module contains no tuning switches: browser, pass-and-play, and online
games all import this one ruleset.
"""

from powers.expansion_v7_20261001 import ExpansionGameV7
from powers.multi import MultiPowerGame


class FinalExpansionGame(ExpansionGameV7):
    merchant_bonus = 20
    blood_payment = 40
    starting_tokens = {
        **ExpansionGameV7.starting_tokens,
        'Navigator': 5,
        'Parrot Whisperer': 4,
        'Undead Admiral': 0,
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        starts = {
            'Cannoneer': 0,
            'Navigator': 5,
            'Parrot Whisperer': 4,
            'Storm Warden': 3,
            'Undead Admiral': 0,
        }
        for power, tokens in starts.items():
            player = self.power_index.get(power)
            if player is not None:
                self.states[player]['tokens'] = tokens
        for power, ships in {
            'Storm Swindler': 7,
            'Storm Warden': 7,
            'Undead Admiral': 6,
        }.items():
            player = self.power_index.get(power)
            if player is not None:
                self.ships[player] = ships

    def setup_round(self):
        result = super().setup_round()
        admiral = self.power_index.get('Undead Admiral')
        if admiral is not None and self.round in (6, 11):
            self.states[admiral]['tokens'] += 1
            self.states[admiral]['power_stats']['red_round_tokens_gained'] += 1
        return result

    def should_harbor(self, player):
        before_tokens = self.states[player]['tokens']
        leave = super().should_harbor(player)
        if (self.powers[player] == 'Navigator'
                and self.states[player]['tokens'] < before_tokens
                and self.states[player]['protection'] > 3):
            self.states[player]['protection'] = 3
        if (leave and self.player_count == 3
                and self.powers[player] != 'Cannoneer'
                and self.status.count('active') == 2):
            cannoneer = self.power_index.get('Cannoneer')
            known_danger = bool(
                self.known[player]
                and self.dangerous_known_card(
                    player, self.known[player][0], self.next_drawer()
                )
            )
            if (cannoneer is not None
                    and self.status[cannoneer] == 'active'
                    and not known_danger
                    and not self._view(player).risk_harbor(1.35)):
                return False
        return leave

    def windows(self, current):
        result = super().windows(current)
        navigator = self.power_index.get('Navigator')
        if navigator is not None:
            self.states[navigator]['protection'] = min(
                3, self.states[navigator]['protection']
            )
        return result

    def hazard_immune(self, player, maroon=False, forecast=False):
        if maroon and self.powers[player] == 'Storm Warden':
            return False
        return super().hazard_immune(player, maroon, forecast)

    def plunder_value(self, chest):
        return chest / 2

    def award(self, player, amount, reason):
        if reason == 'monarch_marooned':
            return MultiPowerGame.award(self, player, 100, reason)
        if reason == 'ghost_sinking_bonus':
            return MultiPowerGame.award(self, player, 50, reason)
        if reason == 'warden_insurance':
            return MultiPowerGame.award(self, player, self.chest / 2, reason)
        return super().award(player, amount, reason)

    def draw(self, player):
        before_hexes = self.hexes
        result = super().draw(player)
        gained = self.hexes - before_hexes
        witch = self.power_index.get('Sea Witch')
        if gained and witch is not None:
            # V7 reaches +15/-15.  This correction produces the locked
            # +25 to the Witch and -10 to every rival.
            for other in range(self.player_count):
                change = (10 if other == witch else 5) * gained
                self.gold[other] += change
                self.states[other]['power_stats']['hex_immediate_gold'] += change
        return result

    def play(self):
        result = super().play()
        token_values = {
            'Parrot Whisperer': (10, 15),
            'Tide Watcher': (5, 15),
            'Storm Warden': (0, 10),
        }
        for power, (base_value, final_value) in token_values.items():
            player = self.power_index.get(power)
            if player is None:
                continue
            extra = self.states[player]['tokens'] * (final_value - base_value)
            if not extra:
                continue
            self.gold[player] += extra
            self.game_bonus[player] += extra
            self.power_gold[player] += extra
            self.states[player]['power_stats']['token_sale_gold'] += extra
        best = max(self.gold)
        winners = [
            player for player, value in enumerate(self.gold)
            if abs(value - best) < 1e-8
        ]
        return [
            1 / len(winners) if player in winners else 0
            for player in range(self.player_count)
        ]
